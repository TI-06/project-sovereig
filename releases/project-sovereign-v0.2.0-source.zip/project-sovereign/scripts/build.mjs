import { cpSync, mkdirSync, readdirSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { spawnSync } from 'node:child_process';

rmSync('dist', { recursive: true, force: true });
mkdirSync('dist', { recursive: true });
const tsc = spawnSync('tsc', ['-p', 'tsconfig.build.json'], { stdio: 'inherit' });
if (tsc.status !== 0) process.exit(tsc.status ?? 1);
for (const entry of readdirSync('public')) cpSync(join('public', entry), join('dist', entry), { recursive: true });
console.log('Built static application in dist/');
