import type { ActiveCrisis, CrisisDefinitionId, DomainEvent, NationId, PlayerCommand, RegionId, WorldState } from '../domain/types.js';
import { createRng, deriveSeed } from '../simulation/rng.js';
import { clamp, round } from '../simulation/utils.js';
import { crisisCatalog, getCrisisDefinition } from './catalog.js';

export function createCrisis(world: WorldState, nationId: NationId, definitionId: CrisisDefinitionId, severity: number, regionId?: RegionId): ActiveCrisis {
  const definition = getCrisisDefinition(definitionId);
  const eligibleRegions = Object.values(world.regions).filter((region) => region.nationId === nationId);
  const selectedRegion = definition.regional ? regionId ?? eligibleRegions[0]?.id ?? null : null;
  const id = `crisis:${nationId.slice(7)}:${definitionId}:${world.turn}:${Object.keys(world.activeCrises).length + 1}`;
  const crisis: ActiveCrisis = {
    id, definitionId, nationId, regionId: selectedRegion, severity: round(clamp(severity, 0.2, 1), 4),
    impact: round(clamp(severity, 0.2, 1), 4), remainingMonths: Math.max(2, Math.ceil(definition.baseDuration * (0.65 + severity))),
    startedTurn: world.turn, responded: false,
  };
  world.activeCrises[id] = crisis;
  return crisis;
}

export function triggerCrises(world: WorldState, events: DomainEvent[]): void {
  for (const nation of Object.values(world.nations)) {
    const activeCount = Object.values(world.activeCrises).filter((crisis) => crisis.nationId === nation.id).length;
    if (activeCount >= 2) continue;
    const rng = createRng(deriveSeed(world.seed, world.turn, 'crisis-trigger', nation.id));
    const roll = rng.next();
    let cursor = 0;
    for (const definition of crisisCatalog) {
      cursor += definition.monthlyChance;
      if (roll >= cursor) continue;
      const duplicate = Object.values(world.activeCrises).some((crisis) => crisis.nationId === nation.id && crisis.definitionId === definition.id);
      if (duplicate) break;
      const regions = Object.values(world.regions).filter((region) => region.nationId === nation.id);
      const region = definition.regional ? regions[Math.floor(rng.next() * Math.max(1, regions.length))]?.id : undefined;
      const crisis = createCrisis(world, nation.id, definition.id, rng.between(0.35, 0.92), region);
      if (nation.id === world.playerNationId) events.push({ id: `crisis-start:${crisis.id}`, type: 'crisis', title: `国家危機：${definition.name}`, description: definition.description, nationId: nation.id, entityId: crisis.id });
      break;
    }
  }
}

function spend(world: WorldState, nationId: NationId, amount: number): void {
  const nation = world.nations[nationId];
  nation.treasury = round(nation.treasury - amount, 4);
  if (nation.treasury < 0) {
    nation.debt = round(nation.debt + Math.abs(nation.treasury), 4);
    nation.treasury = 0;
  }
}

export function applyCrisisCommand(world: WorldState, command: PlayerCommand, events: DomainEvent[]): boolean {
  if (command.type !== 'respond-to-crisis') return false;
  const crisis = world.activeCrises[command.crisisId];
  if (!crisis || crisis.nationId !== world.playerNationId) throw new Error('対応対象の危機が存在しません。');
  const nation = world.nations[crisis.nationId];
  const settings = {
    emergency: { cost: 0.012, severity: 0.58, months: 2, label: '国家緊急対応' },
    measured: { cost: 0.006, severity: 0.76, months: 1, label: '重点対応' },
    local: { cost: 0.0025, severity: 0.9, months: 0, label: '地方対応' },
  } as const;
  const setting = settings[command.response];
  spend(world, crisis.nationId, nation.gdp * setting.cost * crisis.severity);
  crisis.severity = round(clamp(crisis.severity * setting.severity, 0.05, 1), 4);
  crisis.impact = round(clamp(crisis.impact * setting.severity, 0.05, 1), 4);
  crisis.remainingMonths = Math.max(1, crisis.remainingMonths - setting.months);
  crisis.responded = true;
  events.push({ id: `crisis-response:${world.turn}:${crisis.id}`, type: 'info', title: `緊急対応：${setting.label}`, description: `${getCrisisDefinition(crisis.definitionId).name}への対策を実施しました。`, nationId: crisis.nationId, entityId: crisis.id });
  return true;
}

function applyCrisisImpact(world: WorldState, crisis: ActiveCrisis): void {
  const nation = world.nations[crisis.nationId];
  const severity = crisis.severity;
  switch (crisis.definitionId) {
    case 'flood':
    case 'earthquake': {
      const region = crisis.regionId ? world.regions[crisis.regionId] : undefined;
      if (region) {
        const multiplier = crisis.definitionId === 'earthquake' ? 1.3 : 0.8;
        region.infrastructure = round(clamp(region.infrastructure - severity * multiplier, 5, 100), 3);
        region.stability = round(clamp(region.stability - severity * 0.7, 5, 100), 3);
      }
      nation.businessConfidence = round(clamp(nation.businessConfidence - severity * 0.9, 5, 100), 3);
      spend(world, nation.id, nation.gdp * severity * 0.0008);
      break;
    }
    case 'epidemic':
      for (const cohort of world.populationCohorts.filter((item) => item.nationId === nation.id)) {
        cohort.size = round(Math.max(0, cohort.size * (1 - severity * 0.00008)), 2);
        cohort.employed = round(Math.min(cohort.employed, cohort.size), 2);
        cohort.happiness = round(clamp(cohort.happiness - severity * 0.5, 2, 100), 3);
      }
      nation.consumerConfidence = round(clamp(nation.consumerConfidence - severity * 0.8, 5, 100), 3);
      spend(world, nation.id, nation.gdp * severity * 0.0006);
      break;
    case 'energy-shock': {
      const energy = world.commodities['commodity:energy'];
      energy.prices[nation.id] = round(energy.prices[nation.id] * (1 + severity * 0.025), 4);
      nation.inflation = round(clamp(nation.inflation + severity * 0.006, -0.2, 1.2), 6);
      nation.businessConfidence = round(clamp(nation.businessConfidence - severity * 0.7, 5, 100), 3);
      break;
    }
    case 'financial-panic':
      nation.businessConfidence = round(clamp(nation.businessConfidence - severity * 1.2, 5, 100), 3);
      nation.consumerConfidence = round(clamp(nation.consumerConfidence - severity, 5, 100), 3);
      nation.foreignReserves = round(Math.max(0, nation.foreignReserves - nation.gdp * severity * 0.001), 4);
      break;
  }
}

export function updateCrises(world: WorldState, events: DomainEvent[]): void {
  triggerCrises(world, events);
  for (const crisis of Object.values(world.activeCrises)) {
    applyCrisisImpact(world, crisis);
    crisis.remainingMonths = Math.max(0, crisis.remainingMonths - 1);
    crisis.severity = round(clamp(crisis.severity * (crisis.responded ? 0.9 : 0.97), 0.03, 1), 4);
    crisis.impact = round(clamp(crisis.impact * 0.96, 0.03, 1), 4);
    crisis.responded = false;
    if (crisis.remainingMonths > 0 || crisis.severity > 0.12) continue;
    delete world.activeCrises[crisis.id];
    if (crisis.nationId === world.playerNationId) events.push({ id: `crisis-end:${world.turn}:${crisis.id}`, type: 'info', title: '国家危機が収束', description: `${getCrisisDefinition(crisis.definitionId).name}は管理可能な状態まで収束しました。`, nationId: crisis.nationId });
  }
}

export function getCrisisStopReason(world: WorldState): string | null {
  const crisis = Object.values(world.activeCrises).find((item) => item.nationId === world.playerNationId && item.severity >= 0.72);
  return crisis ? `${getCrisisDefinition(crisis.definitionId).name}による国家危機への対応が必要です。` : null;
}
