import type { CrisisDefinitionId } from '../domain/types.js';

export interface CrisisDefinition {
  id: CrisisDefinitionId;
  name: string;
  description: string;
  baseDuration: number;
  monthlyChance: number;
  regional: boolean;
}

export const crisisCatalog: readonly CrisisDefinition[] = [
  { id: 'flood', name: '大規模洪水', description: '交通・生産・居住基盤に被害が発生しています。', baseDuration: 4, monthlyChance: 0.005, regional: true },
  { id: 'earthquake', name: '大地震', description: '都市基盤と企業設備に深刻な被害が発生しています。', baseDuration: 6, monthlyChance: 0.0035, regional: true },
  { id: 'epidemic', name: '感染症流行', description: '医療負荷と労働供給への影響が拡大しています。', baseDuration: 8, monthlyChance: 0.0045, regional: false },
  { id: 'energy-shock', name: 'エネルギー危機', description: '供給不足により物価と企業活動が圧迫されています。', baseDuration: 7, monthlyChance: 0.004, regional: false },
  { id: 'financial-panic', name: '金融不安', description: '信用収縮と資金流出が経済を不安定化させています。', baseDuration: 6, monthlyChance: 0.003, regional: false },
];

export function getCrisisDefinition(id: CrisisDefinitionId): CrisisDefinition {
  const definition = crisisCatalog.find((item) => item.id === id);
  if (!definition) throw new Error('危機定義が存在しません。');
  return definition;
}
