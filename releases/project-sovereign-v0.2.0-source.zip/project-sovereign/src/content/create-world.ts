import type {
  CommodityId,
  CommodityState,
  CompanyState,
  NationId,
  NationState,
  PopulationCohort,
  RegionState,
  WorldState,
} from '../domain/types.js';
import { createDevelopmentSystem } from '../development/system.js';
import { createMilitarySystem } from '../military/system.js';
import { createIntelligenceSystem } from '../intelligence/system.js';
import { createPoliticalSystem } from '../politics/system.js';
import { relationKey } from '../simulation/utils.js';

const nationIds = ['nation:arcadia', 'nation:valen', 'nation:selene', 'nation:dorn'] as const satisfies readonly NationId[];
const commoditySpecs = [
  ['commodity:food', '食料', '百万t', 100],
  ['commodity:energy', 'エネルギー', 'TWh換算', 120],
  ['commodity:steel', '鉄鋼', '百万t', 135],
  ['commodity:machinery', '機械', '指数', 180],
  ['commodity:consumer', '生活用品', '指数', 110],
  ['commodity:medicine', '医薬品', '指数', 210],
  ['commodity:transport', '輸送サービス', '指数', 95],
  ['commodity:finance', '金融サービス', '指数', 160],
] as const satisfies ReadonlyArray<readonly [CommodityId, string, string, number]>;

const nationSpecs: Array<Omit<NationState, 'monthlyRevenue' | 'monthlySpending' | 'tradeBalance'>> = [
  {
    id: 'nation:arcadia', name: 'アルカディア共和国', shortName: 'アルカディア',
    description: '教育とサービス産業に強い民主共和国。エネルギー輸入依存が弱点。', color: '#38bdf8',
    population: 48_000_000, treasury: 210, debt: 620, gdp: 1460, realGdp: 1460, growthRate: 0.018,
    cpi: 100, inflation: 0.024, unemployment: 0.052, policyRate: 0.018, exchangeRate: 1,
    approval: 58, stability: 72, foreignReserves: 220, consumerConfidence: 58, businessConfidence: 61,
    inequality: 0.32, taxPolicy: { income: 0.21, corporate: 0.24, consumption: 0.1 },
    budget: { education: 0.052, healthcare: 0.061, industry: 0.025 },
    strategy: { primaryGoal: 'welfare', riskTolerance: 0.35, tradePreference: 0.75, fiscalDiscipline: 0.55 },
  },
  {
    id: 'nation:valen', name: 'ヴァレン連邦', shortName: 'ヴァレン',
    description: '資源と重工業を持つ連邦国家。所得格差と地方不満を抱える。', color: '#f59e0b',
    population: 67_000_000, treasury: 320, debt: 780, gdp: 1710, realGdp: 1710, growthRate: 0.025,
    cpi: 100, inflation: 0.041, unemployment: 0.061, policyRate: 0.035, exchangeRate: 1.13,
    approval: 52, stability: 61, foreignReserves: 280, consumerConfidence: 51, businessConfidence: 68,
    inequality: 0.43, taxPolicy: { income: 0.18, corporate: 0.19, consumption: 0.12 },
    budget: { education: 0.036, healthcare: 0.043, industry: 0.061 },
    strategy: { primaryGoal: 'growth', riskTolerance: 0.62, tradePreference: 0.58, fiscalDiscipline: 0.43 },
  },
  {
    id: 'nation:selene', name: 'セレネ共同体', shortName: 'セレネ',
    description: '金融・海運・貿易の結節点。食料と資源を海外に依存する。', color: '#a78bfa',
    population: 31_000_000, treasury: 260, debt: 460, gdp: 1320, realGdp: 1320, growthRate: 0.021,
    cpi: 100, inflation: 0.019, unemployment: 0.044, policyRate: 0.012, exchangeRate: 0.82,
    approval: 63, stability: 76, foreignReserves: 360, consumerConfidence: 64, businessConfidence: 72,
    inequality: 0.37, taxPolicy: { income: 0.19, corporate: 0.17, consumption: 0.09 },
    budget: { education: 0.048, healthcare: 0.052, industry: 0.032 },
    strategy: { primaryGoal: 'influence', riskTolerance: 0.48, tradePreference: 0.9, fiscalDiscipline: 0.68 },
  },
  {
    id: 'nation:dorn', name: 'ドーン人民国', shortName: 'ドーン',
    description: '人口と国営企業を基盤とする統制国家。生産性と外交孤立が課題。', color: '#ef4444',
    population: 82_000_000, treasury: 170, debt: 520, gdp: 1190, realGdp: 1190, growthRate: 0.012,
    cpi: 100, inflation: 0.056, unemployment: 0.074, policyRate: 0.045, exchangeRate: 1.42,
    approval: 66, stability: 68, foreignReserves: 150, consumerConfidence: 43, businessConfidence: 46,
    inequality: 0.28, taxPolicy: { income: 0.16, corporate: 0.29, consumption: 0.08 },
    budget: { education: 0.041, healthcare: 0.049, industry: 0.079 },
    strategy: { primaryGoal: 'security', riskTolerance: 0.7, tradePreference: 0.3, fiscalDiscipline: 0.35 },
  },
];

const regionNames: Record<NationId, readonly string[]> = {
  'nation:arcadia': ['ノースゲート', 'リュミエール', 'サウスベイ'],
  'nation:valen': ['アイアンリッジ', 'ヴォルガ平原', 'コールハーバー'],
  'nation:selene': ['ルナ港', 'アストラ島', 'メリディアン'],
  'nation:dorn': ['赤河州', '中央工業区', '東方農業区'],
};

const nationCommodityStrength: Record<NationId, readonly CommodityId[]> = {
  'nation:arcadia': ['commodity:medicine', 'commodity:consumer', 'commodity:finance'],
  'nation:valen': ['commodity:energy', 'commodity:steel', 'commodity:machinery'],
  'nation:selene': ['commodity:transport', 'commodity:finance', 'commodity:consumer'],
  'nation:dorn': ['commodity:food', 'commodity:steel', 'commodity:energy'],
};

function makeNations(): Record<NationId, NationState> {
  return Object.fromEntries(nationSpecs.map((nation) => [nation.id, {
    ...nation, monthlyRevenue: nation.gdp * 0.024, monthlySpending: nation.gdp * 0.026, tradeBalance: 0,
  }])) as Record<NationId, NationState>;
}

function makeRegions(): Record<RegionState['id'], RegionState> {
  const entries: Array<[RegionState['id'], RegionState]> = [];
  nationIds.forEach((nationId, nationIndex) => {
    regionNames[nationId].forEach((name, regionIndex) => {
      const id = `region:${nationId.slice(7)}:${regionIndex + 1}` as RegionState['id'];
      const nation = nationSpecs[nationIndex]!;
      entries.push([id, {
        id, nationId, name,
        population: nation.population * [0.42, 0.34, 0.24][regionIndex]!,
        urbanization: 0.45 + ((nationIndex + regionIndex) % 4) * 0.12,
        infrastructure: 52 + ((nationIndex * 9 + regionIndex * 7) % 35),
        education: 48 + ((nationIndex * 13 + regionIndex * 6) % 38),
        healthcare: 47 + ((nationIndex * 11 + regionIndex * 8) % 38),
        stability: nation.stability - 6 + regionIndex * 3,
        resource: nationCommodityStrength[nationId][regionIndex]!,
        resourceAbundance: 0.65 + regionIndex * 0.13,
      }]);
    });
  });
  return Object.fromEntries(entries) as Record<RegionState['id'], RegionState>;
}

function makeCommodities(): Record<CommodityId, CommodityState> {
  const entries = commoditySpecs.map(([id, name, unit, basePrice]) => {
    const prices = {} as Record<NationId, number>;
    const supply = {} as Record<NationId, number>;
    const demand = {} as Record<NationId, number>;
    const stock = {} as Record<NationId, number>;
    nationIds.forEach((nationId, nationIndex) => {
      const strong = nationCommodityStrength[nationId].includes(id);
      prices[nationId] = basePrice * (1 + (nationIndex - 1.5) * 0.025);
      supply[nationId] = strong ? 125 : 78;
      demand[nationId] = 92 + nationIndex * 5;
      stock[nationId] = strong ? 52 : 28;
    });
    return [id, { id, name, unit, basePrice, prices, supply, demand, stock }] as const;
  });
  return Object.fromEntries(entries) as Record<CommodityId, CommodityState>;
}

function makeCompanies(regions: Record<RegionState['id'], RegionState>): Record<CompanyState['id'], CompanyState> {
  const entries: Array<[CompanyState['id'], CompanyState]> = [];
  nationIds.forEach((nationId, nationIndex) => {
    const nationRegionIds = Object.values(regions).filter((region) => region.nationId === nationId).map((region) => region.id);
    for (let index = 0; index < 6; index += 1) {
      const commodityId = commoditySpecs[(nationIndex * 2 + index) % commoditySpecs.length]![0];
      const id = `company:${nationId.slice(7)}:${index + 1}` as CompanyState['id'];
      const ownership: CompanyState['ownership'] = nationId === 'nation:dorn' && index < 4 ? 'state' : index === 5 ? 'mixed' : 'private';
      entries.push([id, {
        id, nationId, regionId: nationRegionIds[index % nationRegionIds.length]!,
        name: `${['アストラ', 'ヴァンガード', 'ノヴァ', 'ユニオン', 'オービット', 'フロンティア'][index]} ${commoditySpecs.find(([candidate]) => candidate === commodityId)![1]}`,
        industry: commoditySpecs.find(([candidate]) => candidate === commodityId)![1], commodityId, ownership,
        cash: 24 + index * 5 + nationIndex * 3, debt: 18 + index * 3, capitalStock: 70 + index * 14,
        employees: 45_000 + index * 9_000 + nationIndex * 4_000, wage: 2.2 + nationIndex * 0.12,
        productivity: 0.82 + nationIndex * 0.05 + index * 0.018, capacity: 26 + index * 5,
        inventory: 8 + index, reputation: 55 + index * 4, politicalInfluence: 12 + index * 3,
        distressMonths: 0, status: 'active', lastRevenue: 0, lastProfit: 0,
      }]);
    }
  });
  return Object.fromEntries(entries) as Record<CompanyState['id'], CompanyState>;
}

function makeCohorts(regions: Record<RegionState['id'], RegionState>): PopulationCohort[] {
  const cohorts: PopulationCohort[] = [];
  for (const region of Object.values(regions)) {
    const bands = [
      ['low', 0.38, 1.45, 50], ['middle', 0.49, 2.8, 62], ['high', 0.13, 6.2, 70],
    ] as const;
    bands.forEach(([incomeBand, share, income, happiness]) => {
      const size = region.population * share;
      cohorts.push({
        id: `${region.id}:${incomeBand}`, nationId: region.nationId, regionId: region.id,
        incomeBand, size, employed: size * (incomeBand === 'low' ? 0.83 : incomeBand === 'middle' ? 0.91 : 0.95),
        averageIncome: income, happiness, anger: 100 - happiness, politicalInterest: incomeBand === 'middle' ? 68 : 52,
      });
    });
  }
  return cohorts;
}

function makeRelations(): WorldState['relations'] {
  const relations: WorldState['relations'] = {};
  nationIds.forEach((from, fromIndex) => {
    nationIds.forEach((to, toIndex) => {
      if (from === to) return;
      const distance = Math.abs(fromIndex - toIndex);
      const id = relationKey(from, to);
      relations[id] = {
        id, fromNationId: from, toNationId: to,
        trust: 62 - distance * 8, threat: 22 + distance * 6, dependence: 35 + ((fromIndex + toIndex) % 3) * 12,
        affinity: 58 - distance * 7, grievance: 8 + distance * 5, influence: 28 + fromIndex * 5,
        tradeAgreement: distance === 1 && !(from === 'nation:dorn' || to === 'nation:dorn'), sanctioned: false,
      };
    });
  });
  return relations;
}

export function createInitialWorld(options: { playerNationId: NationId; seed: string }): WorldState {
  if (!(nationIds as readonly NationId[]).includes(options.playerNationId)) throw new Error('プレイヤー国家が不正です。');
  const nations = makeNations();
  const regions = makeRegions();
  const politics = createPoliticalSystem(nations);
  const development = createDevelopmentSystem(nations);
  const military = createMilitarySystem(nations);
  const intelligence = createIntelligenceSystem(nations);
  const world: WorldState = {
    schemaVersion: 1, gameVersion: '0.2.0', seed: options.seed || 'sovereign', turn: 0,
    date: { year: 2035, month: 1 }, playerNationId: options.playerNationId,
    nations, regions, commodities: makeCommodities(), companies: makeCompanies(regions),
    populationCohorts: makeCohorts(regions), relations: makeRelations(), parties: politics.parties,
    parliaments: politics.parliaments, laws: politics.laws, research: development.research,
    infrastructureProjects: development.infrastructureProjects, activeCrises: {}, militaries: military.militaries,
    wars: military.wars, intelligence: intelligence.intelligence, covertOperations: intelligence.covertOperations, achievements: {}, history: [], lastReport: null,
  };
  const nation = nations[options.playerNationId];
  world.history.push({ turn: 0, date: { ...world.date }, gdp: nation.gdp, inflation: nation.inflation,
    unemployment: nation.unemployment, approval: nation.approval, treasury: nation.treasury, debt: nation.debt });
  return world;
}

export const playableNations = nationSpecs.map(({ id, name, shortName, description, color }) => ({ id, name, shortName, description, color }));
