import type {
  CovertOperation,
  DomainEvent,
  IntelligenceOperationType,
  IntelligenceState,
  NationId,
  NationState,
  PlayerCommand,
  WorldState,
} from '../domain/types.js';
import { createRng, deriveSeed } from '../simulation/rng.js';
import { clamp, relationKey, round } from '../simulation/utils.js';

const operationDefinitions: Record<IntelligenceOperationType, { duration: number; cost: number; name: string }> = {
  reconnaissance: { duration: 2, cost: 2.5, name: '戦略偵察' },
  influence: { duration: 3, cost: 4.5, name: '世論工作' },
  sabotage: { duration: 4, cost: 7, name: '産業破壊工作' },
};

export function createIntelligenceSystem(nations: Record<NationId, NationState>): {
  intelligence: Record<NationId, IntelligenceState>;
  covertOperations: Record<string, CovertOperation>;
} {
  const intelligence = {} as Record<NationId, IntelligenceState>;
  const nationIds = Object.keys(nations) as NationId[];
  for (const nation of Object.values(nations)) {
    const strategicBias = nation.strategy.primaryGoal === 'influence' ? 1.25 : nation.strategy.primaryGoal === 'security' ? 1.15 : 0.9;
    const confidence = {} as Record<NationId, number>;
    for (const targetId of nationIds) confidence[targetId] = targetId === nation.id ? 100 : round(18 + strategicBias * 12, 3);
    intelligence[nation.id] = {
      nationId: nation.id,
      budgetShare: round(0.008 * strategicBias, 4),
      capability: round(38 * strategicBias, 3),
      counterintelligence: round(42 * strategicBias, 3),
      intelligenceConfidence: confidence,
      operationsCompleted: 0,
      operationsDetected: 0,
    };
  }
  return { intelligence, covertOperations: {} };
}

function spendOperationCost(world: WorldState, nationId: NationId, cost: number): void {
  const nation = world.nations[nationId];
  if (nation.treasury < cost) throw new Error('諜報作戦を開始するための国庫資金が不足しています。');
  nation.treasury = round(nation.treasury - cost, 4);
}

export function applyIntelligenceCommand(world: WorldState, command: PlayerCommand, events: DomainEvent[]): boolean {
  const nationId = world.playerNationId;
  if (command.type === 'set-intelligence-budget') {
    world.intelligence[nationId].budgetShare = round(command.value, 4);
    return true;
  }
  if (command.type !== 'launch-intelligence-operation') return false;
  if (command.targetNationId === nationId || !world.nations[command.targetNationId]) throw new Error('諜報対象国が不正です。');
  const duplicate = Object.values(world.covertOperations).some((operation) => operation.status === 'active'
    && operation.operatorNationId === nationId && operation.targetNationId === command.targetNationId && operation.type === command.operationType);
  if (duplicate) throw new Error('同じ対象国に対する同種の諜報作戦が進行中です。');
  const definition = operationDefinitions[command.operationType];
  spendOperationCost(world, nationId, definition.cost);
  const id = `intel:${nationId.slice(7)}:${command.targetNationId.slice(7)}:${command.operationType}:${world.turn}`;
  world.covertOperations[id] = {
    id,
    operatorNationId: nationId,
    targetNationId: command.targetNationId,
    type: command.operationType,
    status: 'active',
    remainingMonths: definition.duration,
    durationMonths: definition.duration,
    cost: definition.cost,
    progress: 0,
    detected: false,
    startedTurn: world.turn,
    completedTurn: null,
  };
  events.push({
    id: `intel-start:${id}`,
    type: 'info',
    title: `諜報作戦開始：${definition.name}`,
    description: `${world.nations[command.targetNationId].name}を対象に秘密作戦を開始しました。`,
    nationId,
    entityId: id,
  });
  return true;
}

function updateCapabilities(world: WorldState): void {
  for (const nation of Object.values(world.nations)) {
    const state = world.intelligence[nation.id];
    const computing = world.research[nation.id].levels.computing;
    const targetCapability = clamp(26 + state.budgetShare * 850 + computing * 4 + nation.stability * 0.12, 5, 100);
    const targetCounter = clamp(30 + state.budgetShare * 700 + computing * 3 + nation.stability * 0.2, 5, 100);
    state.capability = round(clamp(state.capability * 0.88 + targetCapability * 0.12, 0, 100), 3);
    state.counterintelligence = round(clamp(state.counterintelligence * 0.88 + targetCounter * 0.12, 0, 100), 3);
  }
}

function markDetection(world: WorldState, operation: CovertOperation, events: DomainEvent[]): void {
  operation.detected = true;
  const operator = world.intelligence[operation.operatorNationId];
  operator.operationsDetected += 1;
  const forward = world.relations[relationKey(operation.operatorNationId, operation.targetNationId)];
  const reverse = world.relations[relationKey(operation.targetNationId, operation.operatorNationId)];
  if (forward) {
    forward.trust = round(clamp(forward.trust - 13, 0, 100), 3);
    forward.grievance = round(clamp(forward.grievance + 18, 0, 100), 3);
    forward.threat = round(clamp(forward.threat + 8, 0, 100), 3);
  }
  if (reverse) {
    reverse.trust = round(clamp(reverse.trust - 18, 0, 100), 3);
    reverse.grievance = round(clamp(reverse.grievance + 22, 0, 100), 3);
    reverse.threat = round(clamp(reverse.threat + 10, 0, 100), 3);
  }
  if (operation.operatorNationId === world.playerNationId || operation.targetNationId === world.playerNationId) {
    events.push({
      id: `intel-detected:${world.turn}:${operation.id}`,
      type: 'diplomacy',
      title: operation.operatorNationId === world.playerNationId ? '諜報工作が露見' : '外国の諜報工作を検知',
      description: `${world.nations[operation.operatorNationId].shortName}による秘密作戦が発覚し、国家間関係が悪化しました。`,
      nationId: world.playerNationId,
      entityId: operation.id,
    });
  }
}

function resolveOperation(world: WorldState, operation: CovertOperation, events: DomainEvent[]): void {
  const operator = world.intelligence[operation.operatorNationId];
  const target = world.intelligence[operation.targetNationId];
  const rng = createRng(deriveSeed(world.seed, world.turn, 'intelligence-operation', operation.id));
  const capabilityGap = operator.capability - target.counterintelligence;
  const successChance = clamp(0.48 + capabilityGap * 0.007 + operator.budgetShare * 2, 0.05, 0.95);
  const detectionChance = clamp(0.22 - capabilityGap * 0.006 + target.budgetShare * 1.5, 0.03, 0.92);
  const succeeded = capabilityGap >= 50 || rng.next() < successChance;
  const detected = capabilityGap <= -50 || rng.next() < detectionChance;
  operation.status = succeeded ? 'succeeded' : 'failed';
  operation.completedTurn = world.turn;
  operator.operationsCompleted += 1;
  if (detected) markDetection(world, operation, events);

  if (operation.type === 'reconnaissance') {
    const gain = succeeded ? 24 + operator.capability * 0.18 : 5;
    operator.intelligenceConfidence[operation.targetNationId] = round(clamp(operator.intelligenceConfidence[operation.targetNationId] + gain, 0, 100), 3);
  } else if (operation.type === 'influence') {
    const nation = world.nations[operation.targetNationId];
    nation.stability = round(clamp(nation.stability - (succeeded ? 3.5 : 0.4), 0, 100), 3);
    nation.approval = round(clamp(nation.approval - (succeeded ? 2 : 0.2), 0, 100), 3);
  } else if (succeeded) {
    const companies = Object.values(world.companies).filter((company) => company.nationId === operation.targetNationId && company.status !== 'bankrupt');
    if (companies.length > 0) {
      const company = companies[Math.floor(rng.next() * companies.length)]!;
      company.cash = round(Math.max(0, company.cash * 0.82), 4);
      company.capitalStock = round(Math.max(0, company.capitalStock * 0.96), 4);
      company.reputation = round(clamp(company.reputation - 6, 0, 100), 3);
    }
  }

  if (operation.operatorNationId === world.playerNationId) {
    events.push({
      id: `intel-result:${world.turn}:${operation.id}`,
      type: succeeded ? 'info' : 'warning',
      title: succeeded ? '諜報作戦成功' : '諜報作戦失敗',
      description: `${operationDefinitions[operation.type].name}は${succeeded ? '所期の成果を達成しました' : '成果を得られませんでした'}。`,
      nationId: operation.operatorNationId,
      entityId: operation.id,
    });
  }
}

export function updateIntelligenceSystem(world: WorldState, events: DomainEvent[]): void {
  updateCapabilities(world);
  for (const operation of Object.values(world.covertOperations)) {
    if (operation.status !== 'active') continue;
    const operator = world.intelligence[operation.operatorNationId];
    const target = world.intelligence[operation.targetNationId];
    operation.progress = round(clamp(operation.progress + 18 + operator.capability * 0.22 - target.counterintelligence * 0.08, 0, 100), 3);
    operation.remainingMonths = Math.max(0, operation.remainingMonths - 1);
    if (operation.remainingMonths === 0) resolveOperation(world, operation, events);
  }
}

export function getIntelligenceSpendingShare(world: WorldState, nationId: NationId): number {
  return world.intelligence[nationId].budgetShare;
}
