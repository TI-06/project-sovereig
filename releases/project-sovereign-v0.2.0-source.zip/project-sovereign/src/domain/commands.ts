import type { PlayerCommand, ValidationError, ValidationResult, WorldState } from './types.js';

export function validateCommands(commands: PlayerCommand[], state: WorldState): ValidationResult {
  const errors: ValidationError[] = [];
  commands.forEach((command, index) => {
    if (command.type === 'set-tax-rate' && (!Number.isFinite(command.value) || command.value < 0 || command.value > 0.8)) {
      errors.push({ index, message: '税率は0%以上80%以下で指定してください。' });
    }
    if (command.type === 'set-policy-rate' && (!Number.isFinite(command.value) || command.value < -0.05 || command.value > 0.5)) {
      errors.push({ index, message: '政策金利は-5%以上50%以下で指定してください。' });
    }
    if (command.type === 'set-budget-share' && (!Number.isFinite(command.value) || command.value < 0 || command.value > 0.25)) {
      errors.push({ index, message: '予算比率は0%以上25%以下で指定してください。' });
    }
    if ((command.type === 'propose-trade-agreement' || command.type === 'end-trade-agreement') && !state.nations[command.targetNationId]) {
      errors.push({ index, message: '対象国が存在しません。' });
    }
    if ((command.type === 'propose-trade-agreement' || command.type === 'end-trade-agreement') && command.targetNationId === state.playerNationId) {
      errors.push({ index, message: '自国とは外交協定を締結できません。' });
    }
    if ((command.type === 'propose-law' || command.type === 'repeal-law') && !command.lawId.trim()) {
      errors.push({ index, message: '法律IDを指定してください。' });
    }
    if (command.type === 'start-infrastructure-project' && (!state.regions[command.regionId] || state.regions[command.regionId].nationId !== state.playerNationId)) {
      errors.push({ index, message: '公共事業の対象は自国地域に限られます。' });
    }
    if (command.type === 'respond-to-crisis' && (!state.activeCrises[command.crisisId] || state.activeCrises[command.crisisId].nationId !== state.playerNationId)) {
      errors.push({ index, message: '対応可能な自国危機を指定してください。' });
    }
    if (command.type === 'set-military-budget' && (!Number.isFinite(command.value) || command.value < 0.005 || command.value > 0.2)) {
      errors.push({ index, message: '国防予算はGDP比0.5%以上20%以下で指定してください。' });
    }
    if (command.type === 'declare-war' && (!state.nations[command.targetNationId] || command.targetNationId === state.playerNationId)) {
      errors.push({ index, message: '宣戦対象国が不正です。' });
    }
    if (command.type === 'offer-peace' && !state.wars[command.warId]) {
      errors.push({ index, message: '講和対象の戦争が存在しません。' });
    }
    if (command.type === 'set-intelligence-budget' && (!Number.isFinite(command.value) || command.value < 0.002 || command.value > 0.08)) {
      errors.push({ index, message: '情報予算はGDP比0.2%以上8%以下で指定してください。' });
    }
    if (command.type === 'launch-intelligence-operation' && (!state.nations[command.targetNationId] || command.targetNationId === state.playerNationId)) {
      errors.push({ index, message: '諜報対象国が不正です。' });
    }
  });
  return errors.length === 0 ? { ok: true, commands: structuredClone(commands) } : { ok: false, errors };
}
