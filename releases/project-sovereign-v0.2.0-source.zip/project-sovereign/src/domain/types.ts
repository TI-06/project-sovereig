export type NationId = `nation:${string}`;
export type RegionId = `region:${string}`;
export type CompanyId = `company:${string}`;
export type CommodityId = `commodity:${string}`;

export type TaxKind = 'income' | 'corporate' | 'consumption';
export type BudgetCategory = 'education' | 'healthcare' | 'industry';
export type IncomeBand = 'low' | 'middle' | 'high';
export type CompanyStatus = 'active' | 'distressed' | 'bankrupt';
export type Ownership = 'private' | 'state' | 'foreign' | 'mixed';

export interface GameDate {
  year: number;
  month: number;
}

export interface TaxPolicy {
  income: number;
  corporate: number;
  consumption: number;
}

export interface BudgetPolicy {
  education: number;
  healthcare: number;
  industry: number;
}

export interface NationStrategy {
  primaryGoal: 'growth' | 'security' | 'influence' | 'welfare' | 'ideology';
  riskTolerance: number;
  tradePreference: number;
  fiscalDiscipline: number;
}

export interface NationState {
  id: NationId;
  name: string;
  shortName: string;
  description: string;
  color: string;
  population: number;
  treasury: number;
  debt: number;
  gdp: number;
  realGdp: number;
  growthRate: number;
  cpi: number;
  inflation: number;
  unemployment: number;
  policyRate: number;
  exchangeRate: number;
  approval: number;
  stability: number;
  monthlyRevenue: number;
  monthlySpending: number;
  tradeBalance: number;
  foreignReserves: number;
  consumerConfidence: number;
  businessConfidence: number;
  inequality: number;
  taxPolicy: TaxPolicy;
  budget: BudgetPolicy;
  strategy: NationStrategy;
}

export interface RegionState {
  id: RegionId;
  nationId: NationId;
  name: string;
  population: number;
  urbanization: number;
  infrastructure: number;
  education: number;
  healthcare: number;
  stability: number;
  resource: CommodityId;
  resourceAbundance: number;
}

export interface CommodityState {
  id: CommodityId;
  name: string;
  unit: string;
  basePrice: number;
  prices: Record<NationId, number>;
  supply: Record<NationId, number>;
  demand: Record<NationId, number>;
  stock: Record<NationId, number>;
}

export interface CompanyState {
  id: CompanyId;
  nationId: NationId;
  regionId: RegionId;
  name: string;
  industry: string;
  commodityId: CommodityId;
  ownership: Ownership;
  cash: number;
  debt: number;
  capitalStock: number;
  employees: number;
  wage: number;
  productivity: number;
  capacity: number;
  inventory: number;
  reputation: number;
  politicalInfluence: number;
  distressMonths: number;
  status: CompanyStatus;
  lastRevenue: number;
  lastProfit: number;
}

export interface PopulationCohort {
  id: string;
  nationId: NationId;
  regionId: RegionId;
  incomeBand: IncomeBand;
  size: number;
  employed: number;
  averageIncome: number;
  happiness: number;
  anger: number;
  politicalInterest: number;
}

export interface BilateralRelation {
  id: string;
  fromNationId: NationId;
  toNationId: NationId;
  trust: number;
  threat: number;
  dependence: number;
  affinity: number;
  grievance: number;
  influence: number;
  tradeAgreement: boolean;
  sanctioned: boolean;
}

export interface MetricContribution {
  source: string;
  amount: number;
  description: string;
}

export interface MetricExplanation {
  metric: 'gdp' | 'inflation' | 'approval' | 'treasury' | 'tradeBalance' | 'unemployment';
  label: string;
  previousValue: number;
  currentValue: number;
  contributions: MetricContribution[];
}

export interface DomainEvent {
  id: string;
  type: 'info' | 'warning' | 'crisis' | 'diplomacy' | 'company';
  title: string;
  description: string;
  nationId?: NationId;
  entityId?: string;
}

export interface MonthlyReport {
  turn: number;
  date: GameDate;
  headline: string;
  summary: string;
  explanations: MetricExplanation[];
  events: DomainEvent[];
  alerts: string[];
}

export interface HistoryPoint {
  turn: number;
  date: GameDate;
  gdp: number;
  inflation: number;
  unemployment: number;
  approval: number;
  treasury: number;
  debt: number;
}


export type PartyIdeology = 'social' | 'liberal' | 'conservative' | 'national';

export interface PartyState {
  id: string;
  nationId: NationId;
  name: string;
  ideology: PartyIdeology;
  support: number;
  seats: number;
  discipline: number;
}

export interface ParliamentState {
  nationId: NationId;
  totalSeats: number;
  governmentPartyIds: string[];
  politicalCapital: number;
  legitimacy: number;
  lastElectionTurn: number;
  nextElectionTurn: number;
}

export interface LawState {
  id: string;
  lawId: string;
  nationId: NationId;
  enactedTurn: number;
  active: boolean;
}


export type ResearchField = 'agriculture' | 'industry' | 'energy' | 'computing' | 'medicine' | 'defense';
export type InfrastructureProjectType = 'transport' | 'power' | 'university' | 'hospital' | 'digital';

export interface ResearchState {
  nationId: NationId;
  focus: ResearchField;
  monthlyOutput: number;
  progress: Record<ResearchField, number>;
  levels: Record<ResearchField, number>;
  unlockedTechnologyIds: string[];
}

export interface InfrastructureProject {
  id: string;
  nationId: NationId;
  regionId: RegionId;
  type: InfrastructureProjectType;
  status: 'active' | 'completed' | 'cancelled';
  remainingMonths: number;
  durationMonths: number;
  totalCost: number;
  spent: number;
  startedTurn: number;
}


export type CrisisDefinitionId = 'flood' | 'earthquake' | 'epidemic' | 'energy-shock' | 'financial-panic';
export type CrisisResponse = 'emergency' | 'measured' | 'local';

export interface ActiveCrisis {
  id: string;
  definitionId: CrisisDefinitionId;
  nationId: NationId;
  regionId: RegionId | null;
  severity: number;
  impact: number;
  remainingMonths: number;
  startedTurn: number;
  responded: boolean;
}


export type MobilizationLevel = 'none' | 'partial' | 'full';

export interface MilitaryState {
  nationId: NationId;
  budgetShare: number;
  manpower: number;
  activePersonnel: number;
  reservePersonnel: number;
  readiness: number;
  armyPower: number;
  navyPower: number;
  airPower: number;
  equipment: number;
  logistics: number;
  mobilized: MobilizationLevel;
  monthlyCasualties: number;
  totalCasualties: number;
  warExhaustion: number;
}

export interface WarFrontState {
  id: string;
  regionId: RegionId;
  attackerControl: number;
  intensity: number;
}

export interface WarState {
  id: string;
  attackerId: NationId;
  defenderId: NationId;
  startTurn: number;
  endTurn: number | null;
  status: 'active' | 'ended';
  attackerScore: number;
  defenderScore: number;
  fronts: WarFrontState[];
  outcome: 'ongoing' | 'status-quo' | 'attacker-victory' | 'defender-victory';
}



export type IntelligenceOperationType = 'reconnaissance' | 'influence' | 'sabotage';

export interface IntelligenceState {
  nationId: NationId;
  budgetShare: number;
  capability: number;
  counterintelligence: number;
  intelligenceConfidence: Record<NationId, number>;
  operationsCompleted: number;
  operationsDetected: number;
}

export interface CovertOperation {
  id: string;
  operatorNationId: NationId;
  targetNationId: NationId;
  type: IntelligenceOperationType;
  status: 'active' | 'succeeded' | 'failed';
  remainingMonths: number;
  durationMonths: number;
  cost: number;
  progress: number;
  detected: boolean;
  startedTurn: number;
  completedTurn: number | null;
}


export interface AchievementState {
  id: string;
  title: string;
  description: string;
  unlockedTurn: number;
}

export interface WorldState {
  schemaVersion: 1;
  gameVersion: string;
  seed: string;
  turn: number;
  date: GameDate;
  playerNationId: NationId;
  nations: Record<NationId, NationState>;
  regions: Record<RegionId, RegionState>;
  commodities: Record<CommodityId, CommodityState>;
  companies: Record<CompanyId, CompanyState>;
  populationCohorts: PopulationCohort[];
  relations: Record<string, BilateralRelation>;
  parties: Record<string, PartyState>;
  parliaments: Record<NationId, ParliamentState>;
  laws: Record<string, LawState>;
  research: Record<NationId, ResearchState>;
  infrastructureProjects: Record<string, InfrastructureProject>;
  activeCrises: Record<string, ActiveCrisis>;
  militaries: Record<NationId, MilitaryState>;
  wars: Record<string, WarState>;
  intelligence: Record<NationId, IntelligenceState>;
  covertOperations: Record<string, CovertOperation>;
  achievements: Record<string, AchievementState>;
  history: HistoryPoint[];
  lastReport: MonthlyReport | null;
}

export type PlayerCommand =
  | { type: 'set-tax-rate'; tax: TaxKind; value: number }
  | { type: 'set-policy-rate'; value: number }
  | { type: 'set-budget-share'; category: BudgetCategory; value: number }
  | { type: 'propose-trade-agreement'; targetNationId: NationId }
  | { type: 'end-trade-agreement'; targetNationId: NationId }
  | { type: 'propose-law'; lawId: string }
  | { type: 'repeal-law'; lawId: string }
  | { type: 'call-snap-election' }
  | { type: 'set-research-focus'; focus: ResearchField }
  | { type: 'start-infrastructure-project'; regionId: RegionId; projectType: InfrastructureProjectType }
  | { type: 'respond-to-crisis'; crisisId: string; response: CrisisResponse }
  | { type: 'set-military-budget'; value: number }
  | { type: 'mobilize'; level: MobilizationLevel }
  | { type: 'declare-war'; targetNationId: NationId }
  | { type: 'offer-peace'; warId: string; terms: 'status-quo' | 'demand-concessions' }
  | { type: 'set-intelligence-budget'; value: number }
  | { type: 'launch-intelligence-operation'; targetNationId: NationId; operationType: IntelligenceOperationType };

export interface ValidationError {
  index: number;
  message: string;
}

export type ValidationResult =
  | { ok: true; commands: PlayerCommand[] }
  | { ok: false; errors: ValidationError[] };

export interface SimulationInput {
  previous: WorldState;
  commands: PlayerCommand[];
}

export interface SimulationOutput {
  next: WorldState;
  report: MonthlyReport;
  shouldStop: boolean;
  stopReason: string | null;
}
