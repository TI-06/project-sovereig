import type { AchievementState, DomainEvent, NationId, WorldState } from '../domain/types.js';

interface AchievementDefinition {
  id: string;
  title: string;
  description: string;
  condition: (world: WorldState, nationId: NationId) => boolean;
}

const definitions: readonly AchievementDefinition[] = [
  { id: 'century-administration', title: '長期政権', description: '国家を120か月以上運営した。', condition: (world) => world.turn >= 120 },
  { id: 'research-power', title: '技術立国', description: '研究分野の合計レベルを6以上にした。', condition: (world, nationId) => Object.values(world.research[nationId].levels).reduce((sum, level) => sum + level, 0) >= 6 },
  { id: 'diplomatic-network', title: '外交ネットワーク', description: '3か国すべてと貿易協定を締結した。', condition: (world, nationId) => Object.values(world.relations).filter((relation) => relation.fromNationId === nationId && relation.tradeAgreement).length >= 3 },
  { id: 'fiscal-steward', title: '健全財政', description: '債務GDP比70%未満かつ月次黒字を達成した。', condition: (world, nationId) => {
    const nation = world.nations[nationId];
    return nation.debt / Math.max(1, nation.gdp) < 0.7 && nation.monthlyRevenue >= nation.monthlySpending;
  } },
  { id: 'prosperous-state', title: '繁栄国家', description: '成長率3%以上、失業率6%未満、支持率60%以上を同時達成した。', condition: (world, nationId) => {
    const nation = world.nations[nationId];
    return nation.growthRate >= 0.03 && nation.unemployment < 0.06 && nation.approval >= 60;
  } },
];

export function evaluateAchievements(world: WorldState, events: DomainEvent[]): void {
  const nationId = world.playerNationId;
  for (const definition of definitions) {
    if (world.achievements[definition.id] || !definition.condition(world, nationId)) continue;
    const achievement: AchievementState = { id: definition.id, title: definition.title, description: definition.description, unlockedTurn: world.turn };
    world.achievements[definition.id] = achievement;
    events.push({ id: `achievement:${world.turn}:${definition.id}`, type: 'info', title: `実績解除：${definition.title}`, description: definition.description, nationId, entityId: definition.id });
  }
}

export const achievementCatalog = definitions.map(({ id, title, description }) => ({ id, title, description }));
