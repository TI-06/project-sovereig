import type { DomainEvent, MilitaryState, NationId, NationState, PlayerCommand, WarState, WorldState } from '../domain/types.js';
import { getDevelopmentModifiers } from '../development/system.js';
import { createRng, deriveSeed } from '../simulation/rng.js';
import { clamp, relationKey, round } from '../simulation/utils.js';

export function createMilitarySystem(nations: Record<NationId, NationState>): { militaries: Record<NationId, MilitaryState>; wars: Record<string, WarState> } {
  const militaries = {} as Record<NationId, MilitaryState>;
  for (const nation of Object.values(nations)) {
    const securityBias = nation.strategy.primaryGoal === 'security' ? 1.35 : nation.strategy.primaryGoal === 'influence' ? 1.12 : 0.9;
    militaries[nation.id] = {
      nationId: nation.id, budgetShare: round(0.025 * securityBias, 4), manpower: round(nation.population * 0.19, 0),
      activePersonnel: round(nation.population * 0.0045 * securityBias, 0), reservePersonnel: round(nation.population * 0.012, 0),
      readiness: round(52 * securityBias, 3), armyPower: round(48 * securityBias, 3), navyPower: round(35 * securityBias, 3),
      airPower: round(40 * securityBias, 3), equipment: round(55 * securityBias, 3), logistics: round(52 * securityBias, 3),
      mobilized: 'none', monthlyCasualties: 0, totalCasualties: 0, warExhaustion: 0,
    };
  }
  return { militaries, wars: {} };
}

function activeWarBetween(world: WorldState, first: NationId, second: NationId): WarState | undefined {
  return Object.values(world.wars).find((war) => war.status === 'active' && ((war.attackerId === first && war.defenderId === second) || (war.attackerId === second && war.defenderId === first)));
}

export function applyMilitaryCommand(world: WorldState, command: PlayerCommand, events: DomainEvent[]): boolean {
  const nationId = world.playerNationId;
  const military = world.militaries[nationId];
  if (command.type === 'set-military-budget') {
    military.budgetShare = round(command.value, 4);
    return true;
  }
  if (command.type === 'mobilize') {
    military.mobilized = command.level;
    events.push({ id: `mobilize:${world.turn}:${command.level}`, type: command.level === 'none' ? 'info' : 'warning', title: command.level === 'none' ? '動員解除' : '国家動員を発令', description: `動員水準を${command.level === 'full' ? '全面' : command.level === 'partial' ? '部分' : '平時'}へ変更しました。`, nationId });
    return true;
  }
  if (command.type === 'declare-war') {
    if (command.targetNationId === nationId || !world.nations[command.targetNationId]) throw new Error('宣戦対象が不正です。');
    if (activeWarBetween(world, nationId, command.targetNationId)) throw new Error('対象国とは既に戦争状態です。');
    const parliament = world.parliaments[nationId];
    if (parliament.politicalCapital < 45) throw new Error('宣戦には政治資本45が必要です。');
    parliament.politicalCapital = round(parliament.politicalCapital - 45, 3);
    military.mobilized = military.mobilized === 'none' ? 'partial' : military.mobilized;
    const defenderRegions = Object.values(world.regions).filter((region) => region.nationId === command.targetNationId);
    const id = `war:${nationId.slice(7)}:${command.targetNationId.slice(7)}:${world.turn}`;
    world.wars[id] = {
      id, attackerId: nationId, defenderId: command.targetNationId, startTurn: world.turn, endTurn: null, status: 'active',
      attackerScore: 0, defenderScore: 0, outcome: 'ongoing', fronts: defenderRegions.slice(0, 2).map((region, index) => ({ id: `front:${id}:${index + 1}`, regionId: region.id, attackerControl: 5, intensity: 0.65 + index * 0.1 })),
    };
    const forward = world.relations[relationKey(nationId, command.targetNationId)];
    const reverse = world.relations[relationKey(command.targetNationId, nationId)];
    if (forward) { forward.trust = 0; forward.threat = 100; forward.grievance = 100; forward.tradeAgreement = false; }
    if (reverse) { reverse.trust = 0; reverse.threat = 100; reverse.grievance = 100; reverse.tradeAgreement = false; }
    events.push({ id: `war-declared:${id}`, type: 'crisis', title: '宣戦布告', description: `${world.nations[command.targetNationId].name}との戦争が始まりました。`, nationId, entityId: id });
    return true;
  }
  if (command.type === 'offer-peace') {
    const war = world.wars[command.warId];
    if (!war || war.status !== 'active' || (war.attackerId !== nationId && war.defenderId !== nationId)) throw new Error('講和対象の戦争が存在しません。');
    const exhaustion = world.militaries[war.attackerId].warExhaustion + world.militaries[war.defenderId].warExhaustion;
    const scoreGap = Math.abs(war.attackerScore - war.defenderScore);
    const accepted = command.terms === 'status-quo' ? exhaustion >= 40 || world.turn - war.startTurn >= 10 : exhaustion >= 100 && scoreGap >= 20;
    if (accepted) endWar(world, war, command.terms === 'status-quo' ? 'status-quo' : war.attackerScore >= war.defenderScore ? 'attacker-victory' : 'defender-victory', events);
    else events.push({ id: `peace-rejected:${world.turn}:${war.id}`, type: 'warning', title: '講和提案を拒否', description: '相手国は戦争継続を選択しました。', nationId, entityId: war.id });
    return true;
  }
  return false;
}

function endWar(world: WorldState, war: WarState, outcome: WarState['outcome'], events: DomainEvent[]): void {
  war.status = 'ended';
  war.endTurn = world.turn;
  war.outcome = outcome;
  world.militaries[war.attackerId].mobilized = 'none';
  world.militaries[war.defenderId].mobilized = 'none';
  if (war.attackerId === world.playerNationId || war.defenderId === world.playerNationId) events.push({ id: `peace:${world.turn}:${war.id}`, type: 'info', title: '講和成立', description: outcome === 'status-quo' ? '領土変更なしで停戦しました。' : '戦況を反映した和平が成立しました。', nationId: world.playerNationId, entityId: war.id });
}

function updateForces(world: WorldState): void {
  for (const nation of Object.values(world.nations)) {
    const military = world.militaries[nation.id];
    const targetShare = military.mobilized === 'full' ? 0.014 : military.mobilized === 'partial' ? 0.008 : 0.0045;
    const targetActive = Math.min(military.manpower, nation.population * targetShare);
    military.activePersonnel = round(clamp(military.activePersonnel + (targetActive - military.activePersonnel) * 0.35, 0, military.manpower), 0);
    military.reservePersonnel = round(clamp(military.manpower * 0.12 - military.activePersonnel, 0, military.manpower), 0);
    const budgetTarget = clamp(38 + military.budgetShare * 900 + (military.mobilized === 'full' ? 15 : military.mobilized === 'partial' ? 7 : 0), 20, 98);
    military.readiness = round(clamp(military.readiness * 0.82 + budgetTarget * 0.18, 5, 100), 3);
    military.equipment = round(clamp(military.equipment + military.budgetShare * 0.35 - 0.012, 10, 100), 3);
    military.logistics = round(clamp(military.logistics + military.budgetShare * 0.26 - 0.009, 10, 100), 3);
    military.armyPower = round(clamp(military.armyPower + military.budgetShare * 0.15, 5, 100), 3);
    military.navyPower = round(clamp(military.navyPower + military.budgetShare * 0.11, 2, 100), 3);
    military.airPower = round(clamp(military.airPower + military.budgetShare * 0.13, 2, 100), 3);
    military.monthlyCasualties = 0;
    if (!Object.values(world.wars).some((war) => war.status === 'active' && (war.attackerId === nation.id || war.defenderId === nation.id))) military.warExhaustion = round(clamp(military.warExhaustion - 0.7, 0, 100), 3);
  }
}

function combatPower(world: WorldState, nationId: NationId): number {
  const military = world.militaries[nationId];
  const technology = getDevelopmentModifiers(world, nationId).defense;
  return military.activePersonnel / 1000 * (military.readiness / 100) * (military.equipment / 100) * (military.logistics / 100) * (1 + technology) * (0.7 + (military.armyPower + military.airPower * 0.5 + military.navyPower * 0.25) / 175);
}

function updateWars(world: WorldState, events: DomainEvent[]): void {
  for (const war of Object.values(world.wars)) {
    if (war.status !== 'active') continue;
    const attacker = world.militaries[war.attackerId];
    const defender = world.militaries[war.defenderId];
    const rng = createRng(deriveSeed(world.seed, world.turn, 'war', war.id));
    const attackPower = combatPower(world, war.attackerId) * rng.between(0.92, 1.08);
    const defensePower = combatPower(world, war.defenderId) * rng.between(0.94, 1.1);
    const balance = (attackPower - defensePower) / Math.max(1, attackPower + defensePower);
    const scoreDelta = clamp(balance * 10 + rng.between(-0.7, 0.7), -4, 4);
    if (scoreDelta >= 0) war.attackerScore = round(war.attackerScore + scoreDelta, 3);
    else war.defenderScore = round(war.defenderScore + Math.abs(scoreDelta), 3);
    for (const front of war.fronts) {
      front.attackerControl = round(clamp(front.attackerControl + scoreDelta * front.intensity * 0.55, 0, 100), 3);
      front.intensity = round(clamp(front.intensity + rng.between(-0.04, 0.04), 0.25, 1), 3);
    }
    const attackerLoss = Math.min(attacker.activePersonnel, defensePower * rng.between(0.16, 0.28));
    const defenderLoss = Math.min(defender.activePersonnel, attackPower * rng.between(0.17, 0.3));
    attacker.activePersonnel = round(Math.max(0, attacker.activePersonnel - attackerLoss), 0);
    defender.activePersonnel = round(Math.max(0, defender.activePersonnel - defenderLoss), 0);
    attacker.monthlyCasualties = round(attackerLoss, 0); defender.monthlyCasualties = round(defenderLoss, 0);
    attacker.totalCasualties = round(attacker.totalCasualties + attackerLoss, 0); defender.totalCasualties = round(defender.totalCasualties + defenderLoss, 0);
    attacker.warExhaustion = round(clamp(attacker.warExhaustion + attackerLoss / Math.max(1, attacker.manpower) * 140 + 1.1, 0, 100), 3);
    defender.warExhaustion = round(clamp(defender.warExhaustion + defenderLoss / Math.max(1, defender.manpower) * 140 + 1.1, 0, 100), 3);
    world.nations[war.attackerId].stability = round(clamp(world.nations[war.attackerId].stability - 0.18 - attacker.warExhaustion * 0.002, 3, 100), 3);
    world.nations[war.defenderId].stability = round(clamp(world.nations[war.defenderId].stability - 0.18 - defender.warExhaustion * 0.002, 3, 100), 3);
    const gap = war.attackerScore - war.defenderScore;
    if (Math.abs(gap) >= 45 || attacker.warExhaustion >= 96 || defender.warExhaustion >= 96) endWar(world, war, gap > 8 ? 'attacker-victory' : gap < -8 ? 'defender-victory' : 'status-quo', events);
    else if (war.attackerId === world.playerNationId || war.defenderId === world.playerNationId) events.push({ id: `battle:${world.turn}:${war.id}`, type: 'crisis', title: '戦況報告', description: `今月の損耗：自国${round((war.attackerId === world.playerNationId ? attackerLoss : defenderLoss), 0).toLocaleString('ja-JP')}人。`, nationId: world.playerNationId, entityId: war.id });
  }
}

export function updateMilitarySystem(world: WorldState, events: DomainEvent[]): void {
  updateForces(world);
  updateWars(world, events);
}

export function getWarStopReason(world: WorldState): string | null {
  const war = Object.values(world.wars).find((item) => item.status === 'active' && (item.attackerId === world.playerNationId || item.defenderId === world.playerNationId));
  return war ? `${world.nations[war.attackerId].shortName}と${world.nations[war.defenderId].shortName}の戦争が継続中です。` : null;
}
