import { achievementCatalog } from '../achievements/system.js';
import { createInitialWorld, playableNations } from '../content/create-world.js';
import type { CrisisResponse, InfrastructureProjectType, IntelligenceOperationType, MetricExplanation, MobilizationLevel, NationId, PlayerCommand, ResearchField, WorldState } from '../domain/types.js';
import { lawCatalog } from '../politics/catalog.js';
import { infrastructureCatalog, researchFields, researchNames } from '../development/catalog.js';
import { getCrisisDefinition } from '../crises/catalog.js';
import { createSaveEnvelope, parseSave, serializeSave } from '../save/save.js';
import { IndexedDbSaveRepository } from '../save/indexed-db.js';
import { relationKey } from '../simulation/utils.js';
import { SimulationWorkerClient } from '../worker/client.js';

type TabId = 'dashboard' | 'policies' | 'politics' | 'economy' | 'companies' | 'society' | 'development' | 'diplomacy' | 'defense' | 'intelligence' | 'crises' | 'report';

interface PolicyDraft {
  income: number;
  corporate: number;
  consumption: number;
  policyRate: number;
  education: number;
  healthcare: number;
  industry: number;
}

const root = document.querySelector<HTMLElement>('#app')!;
if (!root) throw new Error('App root not found');

const worker = new SimulationWorkerClient();
const saveRepository = new IndexedDbSaveRepository();
let world: WorldState | null = null;
let activeTab: TabId = 'dashboard';
let busy = false;
let statusMessage = '';
let stopMessage = '';
let policyDraft: PolicyDraft | null = null;
let latestSaveAvailable = false;
let queuedCommands: PlayerCommand[] = [];

const number = new Intl.NumberFormat('ja-JP', { maximumFractionDigits: 1 });
const integer = new Intl.NumberFormat('ja-JP', { maximumFractionDigits: 0 });

function escapeHtml(value: unknown): string {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function percent(value: number, digits = 1): string {
  return `${(value * 100).toFixed(digits)}%`;
}

function signed(value: number, digits = 1): string {
  return `${value >= 0 ? '+' : ''}${value.toFixed(digits)}`;
}

function syncDraft(): void {
  if (!world) return;
  const nation = world.nations[world.playerNationId];
  policyDraft = {
    income: nation.taxPolicy.income,
    corporate: nation.taxPolicy.corporate,
    consumption: nation.taxPolicy.consumption,
    policyRate: nation.policyRate,
    education: nation.budget.education,
    healthcare: nation.budget.healthcare,
    industry: nation.budget.industry,
  };
}

function getPolicyCommands(): PlayerCommand[] {
  if (!world || !policyDraft) return [];
  const nation = world.nations[world.playerNationId];
  const commands: PlayerCommand[] = [];
  const add = (different: boolean, command: PlayerCommand): void => { if (different) commands.push(command); };
  add(policyDraft.income !== nation.taxPolicy.income, { type: 'set-tax-rate', tax: 'income', value: policyDraft.income });
  add(policyDraft.corporate !== nation.taxPolicy.corporate, { type: 'set-tax-rate', tax: 'corporate', value: policyDraft.corporate });
  add(policyDraft.consumption !== nation.taxPolicy.consumption, { type: 'set-tax-rate', tax: 'consumption', value: policyDraft.consumption });
  add(policyDraft.policyRate !== nation.policyRate, { type: 'set-policy-rate', value: policyDraft.policyRate });
  add(policyDraft.education !== nation.budget.education, { type: 'set-budget-share', category: 'education', value: policyDraft.education });
  add(policyDraft.healthcare !== nation.budget.healthcare, { type: 'set-budget-share', category: 'healthcare', value: policyDraft.healthcare });
  add(policyDraft.industry !== nation.budget.industry, { type: 'set-budget-share', category: 'industry', value: policyDraft.industry });
  return commands;
}

function nationSelection(): string {
  const cards = playableNations.map((nation) => `
    <button type="button" class="nation-card" data-start-nation="${escapeHtml(nation.id)}" style="--nation-color:${escapeHtml(nation.color)}">
      <span class="nation-card__flag" aria-hidden="true"></span>
      <span class="nation-card__body">
        <strong>${escapeHtml(nation.name)}</strong>
        <small>${escapeHtml(nation.description)}</small>
      </span>
      <span class="nation-card__action">統治を開始 →</span>
    </button>`).join('');
  return `
    <section class="start-screen" aria-labelledby="start-title">
      <div class="start-brand">
        <div class="eyebrow">NATIONAL COMMAND SIMULATION</div>
        <h1 id="start-title">PROJECT <span>SOVEREIGN</span></h1>
        <p>経済・企業・国民・政治・外交が連鎖する、高難度国家運営シミュレーション。</p>
      </div>
      <div class="start-panel">
        <div class="start-panel__header">
          <div>
            <span class="section-kicker">NEW ADMINISTRATION</span>
            <h2>国家を選択</h2>
          </div>
          <label class="seed-field">世界シード
            <input id="seed-input" type="text" value="sovereign-2035" maxlength="40" autocomplete="off">
          </label>
        </div>
        <div class="nation-grid">${cards}</div>
        <div class="start-actions">
          <button type="button" class="button button--secondary" id="load-latest" ${latestSaveAvailable ? '' : 'disabled'}>最新セーブから再開</button>
          <label class="button button--ghost" for="import-save">セーブファイルを読み込む</label>
          <input id="import-save" type="file" accept="application/json,.json" hidden>
        </div>
        <p class="start-note">1ターン＝1か月。平時は最大12か月進行し、危機発生時は自動停止します。</p>
      </div>
    </section>`;
}

const navItems: Array<[TabId, string, string]> = [
  ['dashboard', '国家概況', '⌂'], ['policies', '政策・予算', '⚙'], ['politics', '政治・議会', '◆'],
  ['economy', '経済・市場', '◫'], ['companies', '産業・企業', '▦'], ['society', '国民・社会', '◉'],
  ['development', '研究・公共事業', '◇'], ['diplomacy', '外交', '◎'], ['defense', '国防・戦争', '▲'],
  ['intelligence', '情報・諜報', '◈'], ['crises', '危機管理', '⚠'], ['report', '国家月報', '≡'],
];

function metricCard(label: string, value: string, detail: string, tone = ''): string {
  return `<article class="metric ${tone ? `metric--${tone}` : ''}"><span>${escapeHtml(label)}</span><strong>${escapeHtml(value)}</strong><small>${escapeHtml(detail)}</small></article>`;
}

function shell(): string {
  if (!world) return nationSelection();
  const nation = world.nations[world.playerNationId];
  const commands = getPolicyCommands().length + queuedCommands.length;
  const nav = navItems.map(([id, label, icon]) => `<button type="button" data-tab="${id}" class="nav-item ${activeTab === id ? 'is-active' : ''}"><span aria-hidden="true">${icon}</span>${label}</button>`).join('');
  return `
    <div class="console-shell" style="--nation-accent:${escapeHtml(nation.color)}">
      <header class="topbar">
        <div class="brand-lockup"><span class="brand-mark">S</span><div><strong>PROJECT SOVEREIGN</strong><small>政府統合管理局</small></div></div>
        <div class="time-status"><span>第${world.turn}ターン</span><strong>${world.date.year}年 ${world.date.month}月</strong><span class="status-dot ${stopMessage ? 'status-dot--danger' : ''}">${stopMessage ? '要緊急対応' : '国家運営中'}</span></div>
        <div class="top-actions">
          <button type="button" class="icon-button" data-action="save" title="手動保存">保存</button>
          <button type="button" class="icon-button" data-action="export" title="セーブ出力">出力</button>
          <button type="button" class="icon-button" data-action="new-game" title="新規ゲーム">終了</button>
        </div>
      </header>
      <aside class="sidebar">
        <div class="nation-identity"><span class="nation-emblem"></span><div><small>統治国家</small><strong>${escapeHtml(nation.shortName)}</strong></div></div>
        <nav aria-label="主要機能">${nav}</nav>
        <div class="sidebar-state"><span>未確定政策</span><strong>${commands}件</strong><small>${commands ? '次回ターンに適用' : '変更なし'}</small></div>
      </aside>
      <main class="workspace">
        ${statusMessage ? `<div class="notice" role="status">${escapeHtml(statusMessage)}</div>` : ''}
        ${stopMessage ? `<div class="crisis-banner" role="alert"><strong>高速進行を停止</strong><span>${escapeHtml(stopMessage)}</span><button type="button" data-action="dismiss-stop">確認</button></div>` : ''}
        ${renderTab()}
      </main>
      <footer class="turnbar">
        <div><span class="turnbar__label">政策を確定して時間を進める</span><small>${busy ? '国家シミュレーションを処理しています…' : '危機条件に一致すると途中で停止します'}</small></div>
        <div class="turn-buttons" aria-label="ターン進行">
          ${([1, 3, 6, 12] as const).map((months) => `<button type="button" data-advance="${months}" ${busy ? 'disabled' : ''}><strong>${months}</strong><span>か月</span></button>`).join('')}
        </div>
      </footer>
    </div>
    <input id="import-save" type="file" accept="application/json,.json" hidden>`;
}

function renderTab(): string {
  switch (activeTab) {
    case 'dashboard': return dashboardView();
    case 'policies': return policiesView();
    case 'politics': return politicsView();
    case 'economy': return economyView();
    case 'companies': return companiesView();
    case 'society': return societyView();
    case 'development': return developmentView();
    case 'diplomacy': return diplomacyView();
    case 'defense': return defenseView();
    case 'intelligence': return intelligenceView();
    case 'crises': return crisesView();
    case 'report': return reportView();
  }
}

function viewHeader(kicker: string, title: string, description: string): string {
  return `<div class="view-header"><div><span class="section-kicker">${escapeHtml(kicker)}</span><h2>${escapeHtml(title)}</h2><p>${escapeHtml(description)}</p></div></div>`;
}

function dashboardView(): string {
  if (!world) return '';
  const nation = world.nations[world.playerNationId];
  const debtRatio = nation.debt / Math.max(1, nation.gdp);
  const metrics = [
    metricCard('名目GDP', `${number.format(nation.gdp)} B`, `前月比 ${signed(nation.growthRate * 100, 2)}%`, nation.growthRate < 0 ? 'danger' : 'good'),
    metricCard('年率インフレ', percent(nation.inflation), `CPI ${number.format(nation.cpi)}`, nation.inflation > 0.08 ? 'danger' : ''),
    metricCard('失業率', percent(nation.unemployment), `消費者信頼 ${number.format(nation.consumerConfidence)}`, nation.unemployment > 0.1 ? 'danger' : ''),
    metricCard('政権支持率', `${number.format(nation.approval)}%`, `国家安定 ${number.format(nation.stability)}`, nation.approval < 40 ? 'danger' : 'good'),
    metricCard('国庫', `${number.format(nation.treasury)} B`, `月次収支 ${signed(nation.monthlyRevenue - nation.monthlySpending)} B`, nation.treasury < 40 ? 'danger' : ''),
    metricCard('政府債務', `${number.format(nation.debt)} B`, `GDP比 ${percent(debtRatio, 0)}`, debtRatio > 1.2 ? 'danger' : ''),
  ].join('');
  const regions = Object.values(world.regions).map((region) => {
    const owner = world!.nations[region.nationId];
    return `<div class="map-region" style="--region-color:${escapeHtml(owner.color)}" title="${escapeHtml(region.name)} / 人口${integer.format(region.population)}">
      <span>${escapeHtml(region.name)}</span><small>${escapeHtml(owner.shortName)}</small>
    </div>`;
  }).join('');
  const recent = [...world.history].slice(-24);
  const gdpValues = recent.map((item) => item.gdp);
  const approvalValues = recent.map((item) => item.approval);
  return `${viewHeader('EXECUTIVE OVERVIEW', '国家ダッシュボード', '経済・財政・国民・外交の変化を一画面で監視します。')}
    <section class="metrics-grid">${metrics}</section>
    <section class="dashboard-grid">
      <article class="panel panel--map"><div class="panel-heading"><div><span>WORLD STATUS</span><h3>世界情勢マップ</h3></div><small>12地域 / 4国家</small></div><div class="world-map">${regions}</div></article>
      <article class="panel"><div class="panel-heading"><div><span>TREND</span><h3>主要指標推移</h3></div><small>直近${recent.length}か月</small></div>
        ${sparkline('GDP', gdpValues, `${number.format(nation.gdp)} B`)}
        ${sparkline('支持率', approvalValues, `${number.format(nation.approval)}%`)}
      </article>
      <article class="panel"><div class="panel-heading"><div><span>PRIORITY</span><h3>対応優先事項</h3></div></div>${priorityList()}</article>
      <article class="panel"><div class="panel-heading"><div><span>ACHIEVEMENTS</span><h3>国家実績</h3></div><small>${Object.keys(world.achievements).length} / ${achievementCatalog.length}解除</small></div>${achievementSummary()}</article>
      <article class="panel"><div class="panel-heading"><div><span>LATEST REPORT</span><h3>最新国家月報</h3></div><button type="button" class="text-button" data-tab="report">詳細</button></div>${latestSummary()}</article>
    </section>`;
}

function sparkline(label: string, values: number[], current: string): string {
  if (values.length < 2) return `<div class="spark-row"><span>${label}</span><strong>${current}</strong><div class="spark-empty">データ蓄積中</div></div>`;
  const min = Math.min(...values);
  const max = Math.max(...values);
  const range = Math.max(0.0001, max - min);
  const points = values.map((value, index) => `${(index / (values.length - 1)) * 100},${35 - ((value - min) / range) * 30}`).join(' ');
  return `<div class="spark-row"><div class="spark-label"><span>${label}</span><strong>${current}</strong></div><svg viewBox="0 0 100 40" role="img" aria-label="${escapeHtml(label)}の推移"><polyline points="${points}" fill="none" vector-effect="non-scaling-stroke"/></svg></div>`;
}

function priorityList(): string {
  if (!world) return '';
  const nation = world.nations[world.playerNationId];
  const items: Array<[string, string, 'high' | 'medium' | 'low']> = [];
  if (nation.debt / nation.gdp > 1.2) items.push(['財政再建', '債務残高がGDP比120%を超えています', 'high']);
  if (nation.inflation > 0.08) items.push(['物価安定', `インフレ率 ${percent(nation.inflation)}`, 'high']);
  if (nation.unemployment > 0.08) items.push(['雇用対策', `失業率 ${percent(nation.unemployment)}`, 'medium']);
  if (nation.approval < 50) items.push(['政権基盤', `支持率 ${number.format(nation.approval)}%`, 'medium']);
  if (nation.tradeBalance < 0) items.push(['貿易赤字', `${number.format(Math.abs(nation.tradeBalance))} Bの赤字`, 'medium']);
  if (!items.length) items.push(['成長投資', '教育・産業投資で中長期成長を強化できます', 'low']);
  return `<div class="priority-list">${items.slice(0, 4).map(([title, detail, severity]) => `<div class="priority priority--${severity}"><span></span><div><strong>${escapeHtml(title)}</strong><small>${escapeHtml(detail)}</small></div></div>`).join('')}</div>`;
}

function achievementSummary(): string {
  if (!world) return '';
  return `<div class="achievement-list">${achievementCatalog.map((entry) => {
    const unlocked = world!.achievements[entry.id];
    return `<div class="achievement-item ${unlocked ? 'is-unlocked' : ''}"><span aria-hidden="true">${unlocked ? '◆' : '◇'}</span><div><strong>${escapeHtml(entry.title)}</strong><small>${unlocked ? `第${unlocked.unlockedTurn}ターンに解除` : escapeHtml(entry.description)}</small></div></div>`;
  }).join('')}</div>`;
}

function latestSummary(): string {
  if (!world?.lastReport) return '<div class="empty-state"><strong>月次報告はまだありません</strong><span>最初のターンを進めると、変化理由を含む国家月報が作成されます。</span></div>';
  const report = world.lastReport;
  return `<div class="report-summary"><strong>${escapeHtml(report.headline)}</strong><p>${escapeHtml(report.summary)}</p>${report.alerts.length ? `<div class="inline-alert">${escapeHtml(report.alerts[0])}</div>` : '<div class="inline-ok">重大警戒事項はありません</div>'}</div>`;
}

function policiesView(): string {
  if (!world || !policyDraft) return '';
  const changed = getPolicyCommands().length;
  const control = (id: keyof PolicyDraft, label: string, min: number, max: number, step: number, help: string) => `
    <label class="policy-control" for="policy-${id}"><div><strong>${escapeHtml(label)}</strong><small>${escapeHtml(help)}</small></div>
      <div class="policy-input"><input id="policy-${id}" data-policy="${id}" type="number" min="${min}" max="${max}" step="${step}" value="${(policyDraft![id] * 100).toFixed(1)}"><span>%</span></div>
    </label>`;
  return `${viewHeader('CABINET DIRECTIVES', '政策・予算', '税制・金融政策・重点予算を変更し、次回ターンで実施します。')}
    <div class="policy-status"><div><span>未確定の政策変更</span><strong>${changed}件</strong></div><button type="button" class="button button--secondary" data-action="reset-policies" ${changed ? '' : 'disabled'}>変更を取り消す</button></div>
    <section class="policy-columns">
      <article class="panel"><div class="panel-heading"><div><span>TAXATION</span><h3>税制</h3></div></div>
        ${control('income', '所得税率', 0, 80, 0.5, '家計可処分所得と税収に影響')}
        ${control('corporate', '法人税率', 0, 80, 0.5, '企業利益・投資・税収に影響')}
        ${control('consumption', '消費税率', 0, 80, 0.5, '消費需要と低所得層の生活実感に影響')}
      </article>
      <article class="panel"><div class="panel-heading"><div><span>MONETARY POLICY</span><h3>中央銀行</h3></div></div>
        ${control('policyRate', '政策金利', -5, 50, 0.1, '物価・投資・為替・国債利払いに影響')}
        <div class="policy-guidance"><strong>政策判断</strong><p>${policyGuidance()}</p></div>
      </article>
      <article class="panel"><div class="panel-heading"><div><span>PUBLIC BUDGET</span><h3>重点予算（GDP比）</h3></div></div>
        ${control('education', '教育予算', 0, 25, 0.1, '生産性・所得・中間層の支持に長期影響')}
        ${control('healthcare', '医療予算', 0, 25, 0.1, '幸福度・低所得層の支持・国家安定に影響')}
        ${control('industry', '産業支援', 0, 25, 0.1, '企業生産・投資・財政支出に影響')}
      </article>
    </section>`;
}

function policyGuidance(): string {
  if (!world || !policyDraft) return '';
  const nation = world.nations[world.playerNationId];
  if (nation.inflation > 0.08 && policyDraft.policyRate <= nation.policyRate) return '物価上昇が強いため、金利据え置き・引き下げはインフレを長期化させる可能性があります。';
  if (nation.growthRate < 0 && policyDraft.policyRate >= nation.policyRate) return '景気後退局面での利上げは企業投資と雇用をさらに圧迫する可能性があります。';
  return '現在の政策変更は即時効果と遅行効果が混在します。複数月進行時は危機停止条件を確認してください。';
}

function economyView(): string {
  if (!world) return '';
  const nation = world.nations[world.playerNationId];
  const rows = Object.values(world.commodities).map((commodity) => {
    const supply = commodity.supply[nation.id];
    const demand = commodity.demand[nation.id];
    const balance = supply - demand;
    return `<tr><th>${escapeHtml(commodity.name)}</th><td>${number.format(commodity.prices[nation.id])}</td><td>${number.format(supply)}</td><td>${number.format(demand)}</td><td class="${balance < 0 ? 'negative' : 'positive'}">${signed(balance)}</td><td>${number.format(commodity.stock[nation.id])}</td></tr>`;
  }).join('');
  return `${viewHeader('MINISTRY OF ECONOMY', '経済・商品市場', '国内8市場の価格、需給、在庫と財政状態を確認します。')}
    <section class="metrics-grid metrics-grid--compact">
      ${metricCard('月次税収', `${number.format(nation.monthlyRevenue)} B`, `実効税負担 ${percent(nation.monthlyRevenue * 12 / nation.gdp)}`)}
      ${metricCard('月次歳出', `${number.format(nation.monthlySpending)} B`, `収支 ${signed(nation.monthlyRevenue - nation.monthlySpending)} B`, nation.monthlySpending > nation.monthlyRevenue ? 'danger' : '')}
      ${metricCard('貿易収支', `${signed(nation.tradeBalance)} B`, `外貨準備 ${number.format(nation.foreignReserves)} B`, nation.tradeBalance < 0 ? 'danger' : 'good')}
      ${metricCard('為替指数', number.format(nation.exchangeRate), `政策金利 ${percent(nation.policyRate)}`)}
    </section>
    <article class="panel table-panel"><div class="panel-heading"><div><span>COMMODITY MONITOR</span><h3>国内商品市場</h3></div><small>価格指数 / 月次需給</small></div>
      <div class="table-wrap"><table><thead><tr><th>商品</th><th>価格</th><th>供給</th><th>需要</th><th>需給差</th><th>在庫</th></tr></thead><tbody>${rows}</tbody></table></div>
    </article>`;
}

function companiesView(): string {
  if (!world) return '';
  const companies = Object.values(world.companies).filter((company) => company.nationId === world!.playerNationId).sort((a, b) => b.lastRevenue - a.lastRevenue);
  const rows = companies.map((company) => `<tr><th><span class="company-name">${escapeHtml(company.name)}</span><small>${escapeHtml(company.ownership)}</small></th><td>${escapeHtml(company.industry)}</td><td>${integer.format(company.employees)}</td><td>${number.format(company.lastRevenue)} B</td><td class="${company.lastProfit < 0 ? 'negative' : 'positive'}">${signed(company.lastProfit)} B</td><td>${number.format(company.cash)} B</td><td><span class="badge badge--${company.status}">${company.status === 'active' ? '正常' : company.status === 'distressed' ? '警戒' : '破綻'}</span></td></tr>`).join('');
  const active = companies.filter((company) => company.status === 'active').length;
  const employment = sumValues(companies.map((company) => company.employees));
  return `${viewHeader('INDUSTRIAL COMMAND', '産業・企業', '主要企業の生産、雇用、利益、資金繰りを監視します。')}
    <section class="metrics-grid metrics-grid--compact">
      ${metricCard('主要企業', `${companies.length}社`, `正常稼働 ${active}社`)}
      ${metricCard('主要企業雇用', `${integer.format(employment)}人`, '月次で採用・解雇を判断')}
      ${metricCard('企業景況感', `${number.format(world.nations[world.playerNationId].businessConfidence)}`, '投資・生産計画に影響')}
      ${metricCard('産業予算', percent(world.nations[world.playerNationId].budget.industry), 'GDP比')}
    </section>
    <article class="panel table-panel"><div class="panel-heading"><div><span>CORPORATE REGISTRY</span><h3>主要企業台帳</h3></div></div><div class="table-wrap"><table><thead><tr><th>企業</th><th>産業</th><th>雇用</th><th>売上</th><th>利益</th><th>現金</th><th>状態</th></tr></thead><tbody>${rows}</tbody></table></div></article>`;
}

function societyView(): string {
  if (!world) return '';
  const nation = world.nations[world.playerNationId];
  const cohorts = world.populationCohorts.filter((cohort) => cohort.nationId === nation.id);
  const bands = (['low', 'middle', 'high'] as const).map((band) => {
    const selected = cohorts.filter((cohort) => cohort.incomeBand === band);
    const size = sumValues(selected.map((cohort) => cohort.size));
    const happiness = weighted(selected.map((cohort) => [cohort.happiness, cohort.size]));
    const income = weighted(selected.map((cohort) => [cohort.averageIncome, cohort.size]));
    const labels = { low: '低所得層', middle: '中間層', high: '高所得層' };
    return `<article class="cohort-card"><div><span>${labels[band]}</span><strong>${integer.format(size)}人</strong></div><dl><div><dt>幸福度</dt><dd>${number.format(happiness)}</dd></div><div><dt>平均所得</dt><dd>${number.format(income)}</dd></div><div><dt>人口比</dt><dd>${percent(size / nation.population)}</dd></div></dl><div class="meter"><span style="width:${Math.max(0, Math.min(100, happiness))}%"></span></div></article>`;
  }).join('');
  const regionRows = Object.values(world.regions).filter((region) => region.nationId === nation.id).map((region) => `<tr><th>${escapeHtml(region.name)}</th><td>${integer.format(region.population)}</td><td>${number.format(region.education)}</td><td>${number.format(region.healthcare)}</td><td>${number.format(region.infrastructure)}</td><td>${number.format(region.stability)}</td></tr>`).join('');
  return `${viewHeader('SOCIAL COHESION', '国民・社会', '所得階層と地域ごとに、政策の受益・負担・生活実感が異なります。')}
    <section class="cohort-grid">${bands}</section>
    <article class="panel table-panel"><div class="panel-heading"><div><span>REGIONAL CONDITIONS</span><h3>地域別社会基盤</h3></div><small>人口・教育・医療・インフラ</small></div><div class="table-wrap"><table><thead><tr><th>地域</th><th>人口</th><th>教育</th><th>医療</th><th>インフラ</th><th>安定度</th></tr></thead><tbody>${regionRows}</tbody></table></div></article>`;
}

function diplomacyView(): string {
  if (!world) return '';
  const playerId = world.playerNationId;
  const relations = Object.values(world.relations).filter((relation) => relation.fromNationId === playerId);
  const cards = relations.map((relation) => {
    const target = world!.nations[relation.toNationId];
    return `<article class="diplomacy-card" style="--target-color:${escapeHtml(target.color)}">
      <div class="diplomacy-card__header"><span class="nation-dot"></span><div><strong>${escapeHtml(target.name)}</strong><small>${escapeHtml(target.description)}</small></div></div>
      <dl><div><dt>信頼</dt><dd>${number.format(relation.trust)}</dd></div><div><dt>脅威</dt><dd>${number.format(relation.threat)}</dd></div><div><dt>依存</dt><dd>${number.format(relation.dependence)}</dd></div></dl>
      <div class="relation-state"><span class="badge ${relation.tradeAgreement ? 'badge--agreement' : ''}">${relation.tradeAgreement ? '貿易協定あり' : '協定なし'}</span>
        <button type="button" class="button button--small ${relation.tradeAgreement ? 'button--danger' : 'button--secondary'}" data-trade-action="${relation.tradeAgreement ? 'end' : 'propose'}" data-target-nation="${escapeHtml(target.id)}">${relation.tradeAgreement ? '協定終了' : '協定を提案'}</button></div>
    </article>`;
  }).join('');
  return `${viewHeader('FOREIGN AFFAIRS', '外交・国際関係', '信頼・脅威・依存を見ながら、貿易協定と外交関係を管理します。')}<section class="diplomacy-grid">${cards}</section>`;
}


function politicsView(): string {
  if (!world) return '';
  const nationId = world.playerNationId;
  const parliament = world.parliaments[nationId];
  const parties = Object.values(world.parties).filter((party) => party.nationId === nationId).sort((a, b) => b.seats - a.seats);
  const activeLawIds = new Set(Object.values(world.laws).filter((law) => law.nationId === nationId && law.active).map((law) => law.lawId));
  const partyRows = parties.map((party) => `<tr><th>${escapeHtml(party.name)}</th><td>${escapeHtml(party.ideology)}</td><td>${party.seats}</td><td>${number.format(party.support)}%</td><td>${number.format(party.discipline)}</td><td>${parliament.governmentPartyIds.includes(party.id) ? '<span class="badge badge--active">与党</span>' : '<span class="badge">野党</span>'}</td></tr>`).join('');
  const laws = lawCatalog.map((law) => {
    const active = activeLawIds.has(law.id);
    return `<article class="system-card"><div><span class="section-kicker">LAW</span><h3>${escapeHtml(law.name)}</h3><p>${escapeHtml(law.description)}</p></div><div class="system-card__footer"><span>政治資本 ${law.politicalCost}</span><button type="button" class="button button--small ${active ? 'button--danger' : 'button--secondary'}" data-law-action="${active ? 'repeal' : 'propose'}" data-law-id="${escapeHtml(law.id)}">${active ? '廃止を提案' : '法案提出'}</button></div></article>`;
  }).join('');
  return `${viewHeader('PARLIAMENT & LAW', '政治・議会', '政党勢力、連立政権、政治資本を管理し、国家制度を法律として変更します。')}
    <section class="metrics-grid metrics-grid--compact">
      ${metricCard('政治資本', number.format(parliament.politicalCapital), '法案・宣戦・政治判断で消費')}
      ${metricCard('政権正統性', `${number.format(parliament.legitimacy)}%`, `次回選挙 第${parliament.nextElectionTurn}ターン`)}
      ${metricCard('与党議席', `${sumValues(parties.filter((party) => parliament.governmentPartyIds.includes(party.id)).map((party) => party.seats))} / ${parliament.totalSeats}`, '過半数101議席')}
      ${metricCard('施行中の法律', `${activeLawIds.size}件`, '政策効果は月次計算へ反映')}
    </section>
    <div class="toolbar-row"><button type="button" class="button button--secondary" data-political-action="election">解散総選挙を命令キューへ追加</button></div>
    <article class="panel table-panel"><div class="panel-heading"><div><span>PARTY BALANCE</span><h3>議会勢力</h3></div></div><div class="table-wrap"><table><thead><tr><th>政党</th><th>思想</th><th>議席</th><th>支持</th><th>党議拘束</th><th>立場</th></tr></thead><tbody>${partyRows}</tbody></table></div></article>
    <section class="system-grid">${laws}</section>`;
}

function developmentView(): string {
  if (!world) return '';
  const research = world.research[world.playerNationId];
  const researchCards = researchFields.map((field) => {
    const level = research.levels[field];
    const threshold = 100 + level * 80;
    return `<article class="system-card ${research.focus === field ? 'is-selected' : ''}"><div><span class="section-kicker">RESEARCH</span><h3>${escapeHtml(researchNames[field])} Lv.${level}</h3><p>進捗 ${number.format(research.progress[field])} / ${threshold}</p><div class="meter"><span style="width:${Math.min(100, research.progress[field] / threshold * 100)}%"></span></div></div><div class="system-card__footer"><span>${research.focus === field ? '重点研究中' : '通常配分'}</span><button type="button" class="button button--small button--secondary" data-research-focus="${field}" ${research.focus === field ? 'disabled' : ''}>重点指定</button></div></article>`;
  }).join('');
  const projects = Object.values(world.infrastructureProjects).filter((project) => project.nationId === world!.playerNationId);
  const projectRows = projects.length ? projects.map((project) => `<tr><th>${escapeHtml(world!.regions[project.regionId].name)}</th><td>${escapeHtml(infrastructureCatalog[project.type].name)}</td><td>${project.status === 'active' ? '進行中' : project.status === 'completed' ? '完成' : '中止'}</td><td>${project.remainingMonths}か月</td><td>${number.format(project.spent)} / ${number.format(project.totalCost)} B</td></tr>`).join('') : '<tr><td colspan="5">進行中・完了済みの公共事業はありません。</td></tr>';
  const regionProjects = Object.values(world.regions).filter((region) => region.nationId === world!.playerNationId).map((region) => `<article class="system-card"><div><span class="section-kicker">REGIONAL DEVELOPMENT</span><h3>${escapeHtml(region.name)}</h3><p>インフラ ${number.format(region.infrastructure)} / 教育 ${number.format(region.education)} / 医療 ${number.format(region.healthcare)}</p></div><div class="command-buttons">${(Object.keys(infrastructureCatalog) as InfrastructureProjectType[]).map((type) => `<button type="button" class="button button--small button--ghost" data-project-type="${type}" data-region-id="${escapeHtml(region.id)}">${escapeHtml(infrastructureCatalog[type].name)}</button>`).join('')}</div></article>`).join('');
  return `${viewHeader('SCIENCE & DEVELOPMENT', '研究・公共事業', '研究重点を設定し、地域別の交通・電力・大学・医療・デジタル基盤を整備します。')}
    <section class="metrics-grid metrics-grid--compact">${metricCard('月間研究力', number.format(research.monthlyOutput), `解放技術 ${research.unlockedTechnologyIds.length}件`)}${metricCard('重点分野', researchNames[research.focus], '次回ターンから配分へ反映')}${metricCard('公共事業', `${projects.filter((project) => project.status === 'active').length}件進行中`, `累計 ${projects.length}件`)}</section>
    <section class="system-grid">${researchCards}</section>
    <article class="panel table-panel"><div class="panel-heading"><div><span>PROJECT PORTFOLIO</span><h3>公共事業一覧</h3></div></div><div class="table-wrap"><table><thead><tr><th>地域</th><th>事業</th><th>状態</th><th>残期間</th><th>支出</th></tr></thead><tbody>${projectRows}</tbody></table></div></article>
    <section class="system-grid">${regionProjects}</section>`;
}

function defenseView(): string {
  if (!world) return '';
  const nationId = world.playerNationId;
  const military = world.militaries[nationId];
  const wars = Object.values(world.wars).filter((war) => war.attackerId === nationId || war.defenderId === nationId);
  const opponents = Object.values(world.nations).filter((nation) => nation.id !== nationId);
  const warCards = wars.length ? wars.map((war) => {
    const opponentId = war.attackerId === nationId ? war.defenderId : war.attackerId;
    return `<article class="system-card"><div><span class="section-kicker">${war.status === 'active' ? 'ACTIVE WAR' : 'WAR RECORD'}</span><h3>対 ${escapeHtml(world!.nations[opponentId].name)}</h3><p>戦況 ${number.format(war.attackerScore)} - ${number.format(war.defenderScore)} / ${war.fronts.length}戦線 / 結果 ${escapeHtml(war.outcome)}</p></div><div class="system-card__footer"><span>第${war.startTurn}ターン開始</span>${war.status === 'active' ? `<button type="button" class="button button--small button--secondary" data-offer-peace="${escapeHtml(war.id)}">現状維持で講和提案</button>` : ''}</div></article>`;
  }).join('') : '<article class="panel empty-state"><strong>現在、戦争状態ではありません</strong><span>外交的解決が国家経済と国民生活を守ります。</span></article>';
  return `${viewHeader('MINISTRY OF DEFENSE', '国防・戦争', '国防予算、動員、兵站、戦線、損耗、戦争疲弊を統合管理します。')}
    <section class="metrics-grid metrics-grid--compact">
      ${metricCard('現役兵力', integer.format(military.activePersonnel), `予備役 ${integer.format(military.reservePersonnel)}`)}
      ${metricCard('即応度', `${number.format(military.readiness)}%`, `装備 ${number.format(military.equipment)} / 兵站 ${number.format(military.logistics)}`)}
      ${metricCard('国防予算', percent(military.budgetShare), `動員 ${military.mobilized}`)}
      ${metricCard('戦争疲弊', `${number.format(military.warExhaustion)}%`, `累計損耗 ${integer.format(military.totalCasualties)}`, military.warExhaustion > 60 ? 'danger' : '')}
    </section>
    <article class="panel command-panel"><div class="panel-heading"><div><span>DEFENSE DIRECTIVES</span><h3>国防命令</h3></div></div><div class="command-form"><label>国防予算（GDP比）<input id="military-budget" type="number" min="0.5" max="20" step="0.1" value="${(military.budgetShare * 100).toFixed(1)}"></label><button type="button" class="button button--secondary" data-budget-action="military">予算変更を追加</button></div><div class="command-buttons">${(['none', 'partial', 'full'] as MobilizationLevel[]).map((level) => `<button type="button" class="button button--small ${military.mobilized === level ? 'button--secondary' : 'button--ghost'}" data-mobilize="${level}">${level === 'none' ? '動員解除' : level === 'partial' ? '部分動員' : '全面動員'}</button>`).join('')}</div></article>
    <section class="system-grid">${warCards}</section>
    <article class="panel"><div class="panel-heading"><div><span>WAR AUTHORITY</span><h3>宣戦権限</h3></div></div><div class="command-buttons">${opponents.map((nation) => `<button type="button" class="button button--danger" data-declare-war="${escapeHtml(nation.id)}">${escapeHtml(nation.shortName)}へ宣戦</button>`).join('')}</div><p class="danger-note">宣戦には政治資本45が必要です。貿易・外交・国民生活に重大な影響があります。</p></article>`;
}

function intelligenceView(): string {
  if (!world) return '';
  const nationId = world.playerNationId;
  const intelligence = world.intelligence[nationId];
  const operations = Object.values(world.covertOperations).filter((operation) => operation.operatorNationId === nationId || operation.targetNationId === nationId).sort((a, b) => b.startedTurn - a.startedTurn);
  const targets = Object.values(world.nations).filter((nation) => nation.id !== nationId).map((target) => `<article class="system-card"><div><span class="section-kicker">TARGET STATE</span><h3>${escapeHtml(target.name)}</h3><p>情報確度 ${number.format(intelligence.intelligenceConfidence[target.id])}% / 関係信頼 ${number.format(world!.relations[relationKey(nationId, target.id)].trust)}</p></div><div class="command-buttons">${(['reconnaissance', 'influence', 'sabotage'] as IntelligenceOperationType[]).map((type) => `<button type="button" class="button button--small button--ghost" data-intel-operation="${type}" data-target-nation="${escapeHtml(target.id)}">${type === 'reconnaissance' ? '戦略偵察' : type === 'influence' ? '世論工作' : '産業破壊'}</button>`).join('')}</div></article>`).join('');
  const operationRows = operations.length ? operations.map((operation) => `<tr><th>${escapeHtml(world!.nations[operation.operatorNationId].shortName)} → ${escapeHtml(world!.nations[operation.targetNationId].shortName)}</th><td>${operation.type}</td><td>${operation.status}</td><td>${operation.remainingMonths}か月</td><td>${number.format(operation.progress)}%</td><td>${operation.detected ? '<span class="negative">露見</span>' : '秘匿'}</td></tr>`).join('') : '<tr><td colspan="6">作戦履歴はありません。</td></tr>';
  return `${viewHeader('INTELLIGENCE DIRECTORATE', '情報・諜報', '情報確度、防諜能力、秘密工作と露見リスクを管理します。')}
    <section class="metrics-grid metrics-grid--compact">${metricCard('諜報能力', number.format(intelligence.capability), `防諜 ${number.format(intelligence.counterintelligence)}`)}${metricCard('情報予算', percent(intelligence.budgetShare), 'GDP比')}${metricCard('完了作戦', `${intelligence.operationsCompleted}件`, `露見 ${intelligence.operationsDetected}件`)}</section>
    <article class="panel command-panel"><div class="panel-heading"><div><span>INTELLIGENCE BUDGET</span><h3>情報予算</h3></div></div><div class="command-form"><label>情報予算（GDP比）<input id="intelligence-budget" type="number" min="0.2" max="8" step="0.1" value="${(intelligence.budgetShare * 100).toFixed(1)}"></label><button type="button" class="button button--secondary" data-budget-action="intelligence">予算変更を追加</button></div></article>
    <section class="system-grid">${targets}</section>
    <article class="panel table-panel"><div class="panel-heading"><div><span>OPERATION LOG</span><h3>諜報作戦</h3></div></div><div class="table-wrap"><table><thead><tr><th>当事国</th><th>種別</th><th>状態</th><th>残期間</th><th>進捗</th><th>秘匿</th></tr></thead><tbody>${operationRows}</tbody></table></div></article>`;
}

function crisesView(): string {
  if (!world) return '';
  const crises = Object.values(world.activeCrises).filter((crisis) => crisis.nationId === world!.playerNationId);
  const cards = crises.length ? crises.map((crisis) => {
    const definition = getCrisisDefinition(crisis.definitionId);
    const region = crisis.regionId ? world!.regions[crisis.regionId].name : '全国';
    return `<article class="system-card system-card--danger"><div><span class="section-kicker">ACTIVE CRISIS</span><h3>${escapeHtml(definition.name)}</h3><p>${escapeHtml(definition.description)} / 対象 ${escapeHtml(region)} / 深刻度 ${number.format(crisis.severity * 100)}%</p><div class="meter"><span style="width:${crisis.severity * 100}%"></span></div></div><div class="command-buttons">${(['emergency', 'measured', 'local'] as CrisisResponse[]).map((response) => `<button type="button" class="button button--small ${response === 'emergency' ? 'button--danger' : 'button--secondary'}" data-crisis-response="${response}" data-crisis-id="${escapeHtml(crisis.id)}">${response === 'emergency' ? '国家緊急対応' : response === 'measured' ? '段階対応' : '地方対応'}</button>`).join('')}</div></article>`;
  }).join('') : '<article class="panel empty-state"><strong>対応中の国家危機はありません</strong><span>危機は発生確率、地域条件、国家能力に基づき決定論的に判定されます。</span></article>';
  return `${viewHeader('NATIONAL EMERGENCY', '危機管理', '災害・感染症・エネルギー・金融危機へ国家資源を投入し、被害拡大を抑制します。')}<section class="metrics-grid metrics-grid--compact">${metricCard('活動中の危機', `${crises.length}件`, crises.some((crisis) => crisis.severity >= 0.72) ? '高速進行停止水準あり' : '監視継続', crises.length ? 'danger' : 'good')}${metricCard('最高深刻度', `${number.format(Math.max(0, ...crises.map((crisis) => crisis.severity)) * 100)}%`, '72%以上で自動停止')}</section><section class="system-grid">${cards}</section>`;
}

function reportView(): string {
  if (!world?.lastReport) return `${viewHeader('NATIONAL REPORT', '国家月報', 'ターン処理の結果と、主要指標が変化した理由を確認します。')}<div class="panel empty-state"><strong>国家月報はまだありません</strong><span>政策を設定し、1か月以上進めてください。</span></div>`;
  const report = world.lastReport;
  const explanations = report.explanations.map(explanationCard).join('');
  const events = report.events.length ? report.events.map((event) => `<div class="event-item event-item--${event.type}"><span></span><div><strong>${escapeHtml(event.title)}</strong><p>${escapeHtml(event.description)}</p></div></div>`).join('') : '<div class="empty-state empty-state--small"><span>今月の重大イベントはありません。</span></div>';
  return `${viewHeader('NATIONAL REPORT', report.headline, report.summary)}
    ${report.alerts.length ? `<div class="alert-stack">${report.alerts.map((alert) => `<div class="inline-alert">${escapeHtml(alert)}</div>`).join('')}</div>` : '<div class="inline-ok report-ok">重大な警戒事項はありません</div>'}
    <section class="explanation-grid">${explanations}</section>
    <article class="panel"><div class="panel-heading"><div><span>EVENT LOG</span><h3>今月の出来事</h3></div></div><div class="event-list">${events}</div></article>`;
}

function explanationCard(explanation: MetricExplanation): string {
  const delta = explanation.currentValue - explanation.previousValue;
  const isPercent = ['inflation', 'unemployment'].includes(explanation.metric);
  const format = (value: number) => isPercent ? percent(value) : number.format(value);
  return `<article class="panel explanation-card"><div class="explanation-title"><div><span>${escapeHtml(explanation.label)}</span><strong>${format(explanation.currentValue)}</strong></div><em class="${delta < 0 ? 'negative' : 'positive'}">${signed(isPercent ? delta * 100 : delta, 2)}${isPercent ? 'pt' : ''}</em></div><div class="contribution-list">${explanation.contributions.map((item) => `<div><span>${escapeHtml(item.source)}<small>${escapeHtml(item.description)}</small></span><strong class="${item.amount < 0 ? 'negative' : 'positive'}">${signed(item.amount, 2)}</strong></div>`).join('')}</div></article>`;
}

function sumValues(values: number[]): number {
  return values.reduce((total, value) => total + value, 0);
}

function weighted(values: Array<[number, number]>): number {
  const denominator = sumValues(values.map(([, weight]) => weight));
  return denominator ? sumValues(values.map(([value, weight]) => value * weight)) / denominator : 0;
}

function render(): void {
  root.innerHTML = shell();
  bindEvents();
}

function bindEvents(): void {
  root.querySelectorAll<HTMLElement>('[data-start-nation]').forEach((button) => button.addEventListener('click', () => {
    const input = root.querySelector<HTMLInputElement>('#seed-input');
    startNewGame(button.dataset.startNation as NationId, input?.value.trim() || 'sovereign-2035');
  }));
  root.querySelectorAll<HTMLElement>('[data-tab]').forEach((button) => button.addEventListener('click', () => {
    activeTab = button.dataset.tab as TabId;
    statusMessage = '';
    render();
  }));
  root.querySelectorAll<HTMLInputElement>('[data-policy]').forEach((input) => input.addEventListener('change', () => {
    if (!policyDraft) return;
    const key = input.dataset.policy as keyof PolicyDraft;
    const numeric = Number(input.value);
    if (!Number.isFinite(numeric)) return;
    policyDraft[key] = numeric / 100;
    render();
  }));
  root.querySelectorAll<HTMLElement>('[data-advance]').forEach((button) => button.addEventListener('click', () => void advance(Number(button.dataset.advance) as 1 | 3 | 6 | 12)));
  root.querySelectorAll<HTMLElement>('[data-action]').forEach((button) => button.addEventListener('click', () => void action(button.dataset.action ?? '')));
  root.querySelectorAll<HTMLElement>('[data-trade-action]').forEach((button) => button.addEventListener('click', () => {
    if (!world) return;
    const target = button.dataset.targetNation as NationId;
    const relation = world.relations[relationKey(world.playerNationId, target)];
    if (!relation) return;
    queueCommand(relation.tradeAgreement ? { type: 'end-trade-agreement', targetNationId: target } : { type: 'propose-trade-agreement', targetNationId: target }, '外交命令を追加しました。');
  }));
  root.querySelectorAll<HTMLElement>('[data-law-action]').forEach((button) => button.addEventListener('click', () => {
    const lawId = button.dataset.lawId ?? '';
    queueCommand(button.dataset.lawAction === 'repeal' ? { type: 'repeal-law', lawId } : { type: 'propose-law', lawId }, '法案命令を追加しました。');
  }));
  root.querySelector<HTMLElement>('[data-political-action="election"]')?.addEventListener('click', () => queueCommand({ type: 'call-snap-election' }, '解散総選挙を命令キューへ追加しました。'));
  root.querySelectorAll<HTMLElement>('[data-research-focus]').forEach((button) => button.addEventListener('click', () => queueCommand({ type: 'set-research-focus', focus: button.dataset.researchFocus as ResearchField }, '研究重点の変更を追加しました。', 'set-research-focus')));
  root.querySelectorAll<HTMLElement>('[data-project-type]').forEach((button) => button.addEventListener('click', () => queueCommand({ type: 'start-infrastructure-project', regionId: button.dataset.regionId as `region:${string}`, projectType: button.dataset.projectType as InfrastructureProjectType }, '公共事業の開始命令を追加しました。')));
  root.querySelectorAll<HTMLElement>('[data-mobilize]').forEach((button) => button.addEventListener('click', () => queueCommand({ type: 'mobilize', level: button.dataset.mobilize as MobilizationLevel }, '動員命令を追加しました。', 'mobilize')));
  root.querySelectorAll<HTMLElement>('[data-declare-war]').forEach((button) => button.addEventListener('click', () => {
    const targetNationId = button.dataset.declareWar as NationId;
    if (confirm(`${world?.nations[targetNationId].name ?? '対象国'}へ宣戦する命令を追加しますか？`)) queueCommand({ type: 'declare-war', targetNationId }, '宣戦命令を追加しました。');
  }));
  root.querySelectorAll<HTMLElement>('[data-offer-peace]').forEach((button) => button.addEventListener('click', () => queueCommand({ type: 'offer-peace', warId: button.dataset.offerPeace ?? '', terms: 'status-quo' }, '講和提案を追加しました。')));
  root.querySelectorAll<HTMLElement>('[data-intel-operation]').forEach((button) => button.addEventListener('click', () => queueCommand({ type: 'launch-intelligence-operation', targetNationId: button.dataset.targetNation as NationId, operationType: button.dataset.intelOperation as IntelligenceOperationType }, '諜報作戦を追加しました。')));
  root.querySelectorAll<HTMLElement>('[data-crisis-response]').forEach((button) => button.addEventListener('click', () => queueCommand({ type: 'respond-to-crisis', crisisId: button.dataset.crisisId ?? '', response: button.dataset.crisisResponse as CrisisResponse }, '危機対応命令を追加しました。')));
  root.querySelectorAll<HTMLElement>('[data-budget-action]').forEach((button) => button.addEventListener('click', () => {
    const kind = button.dataset.budgetAction;
    const input = root.querySelector<HTMLInputElement>(kind === 'military' ? '#military-budget' : '#intelligence-budget');
    const value = Number(input?.value) / 100;
    if (!Number.isFinite(value)) return;
    if (kind === 'military') queueCommand({ type: 'set-military-budget', value }, '国防予算変更を追加しました。', 'set-military-budget');
    else queueCommand({ type: 'set-intelligence-budget', value }, '情報予算変更を追加しました。', 'set-intelligence-budget');
  }));
  root.querySelector<HTMLButtonElement>('#load-latest')?.addEventListener('click', () => void loadLatest());
  root.querySelector<HTMLInputElement>('#import-save')?.addEventListener('change', (event) => void importSave(event));
}


function queueCommand(command: PlayerCommand, message: string, replaceType?: PlayerCommand['type']): void {
  if (replaceType) queuedCommands = queuedCommands.filter((item) => item.type !== replaceType);
  queuedCommands.push(command);
  statusMessage = message;
  render();
}

async function action(name: string): Promise<void> {
  if (name === 'save') await saveNow('手動保存を作成しました。');
  if (name === 'export') exportSave();
  if (name === 'new-game') {
    if (confirm('現在のゲームを終了して国家選択へ戻りますか？未保存の変更は失われます。')) {
      world = null; policyDraft = null; queuedCommands = []; activeTab = 'dashboard'; stopMessage = ''; statusMessage = ''; render();
    }
  }
  if (name === 'reset-policies') { syncDraft(); queuedCommands = []; statusMessage = '未確定の政策・命令を取り消しました。'; render(); }
  if (name === 'dismiss-stop') { stopMessage = ''; render(); }
}

function startNewGame(nationId: NationId, seed: string): void {
  world = createInitialWorld({ playerNationId: nationId, seed });
  queuedCommands = [];
  activeTab = 'dashboard';
  stopMessage = '';
  statusMessage = `${world.nations[nationId].name}の統治を開始しました。`;
  syncDraft();
  render();
  void saveNow('');
}

async function advance(months: 1 | 3 | 6 | 12, extraCommands: PlayerCommand[] = []): Promise<void> {
  if (!world || busy) return;
  busy = true;
  stopMessage = '';
  statusMessage = '';
  render();
  try {
    await saveRepository.save(createSaveEnvelope(world));
    const result = await worker.advance(world, [...getPolicyCommands(), ...queuedCommands, ...extraCommands], months);
    world = result.next;
    queuedCommands = [];
    syncDraft();
    stopMessage = result.stoppedBy ?? '';
    statusMessage = `${result.monthsProcessed}か月進行しました。`;
    await saveRepository.save(createSaveEnvelope(world));
    if (stopMessage || result.reports.some((report) => report.events.length > 0)) activeTab = 'report';
  } catch (error) {
    statusMessage = error instanceof Error ? error.message : 'ターン処理に失敗しました。';
  } finally {
    busy = false;
    render();
  }
}

async function saveNow(message: string): Promise<void> {
  if (!world) return;
  try {
    await saveRepository.save(createSaveEnvelope(world));
    if (message) statusMessage = message;
  } catch (error) {
    statusMessage = error instanceof Error ? error.message : '保存に失敗しました。';
  }
  render();
}

function exportSave(): void {
  if (!world) return;
  const envelope = createSaveEnvelope(world);
  const blob = new Blob([serializeSave(envelope)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = `project-sovereign-${world.date.year}-${String(world.date.month).padStart(2, '0')}.json`;
  anchor.click();
  URL.revokeObjectURL(url);
  statusMessage = 'セーブファイルを出力しました。';
  render();
}

async function importSave(event: Event): Promise<void> {
  const input = event.target as HTMLInputElement;
  const file = input.files?.[0];
  if (!file) return;
  try {
    const envelope = parseSave(await file.text());
    world = envelope.snapshot;
    queuedCommands = [];
    syncDraft();
    activeTab = 'dashboard';
    statusMessage = 'セーブファイルを読み込みました。';
    stopMessage = '';
    await saveRepository.save(envelope);
  } catch (error) {
    statusMessage = error instanceof Error ? error.message : 'セーブファイルを読み込めませんでした。';
  }
  render();
}

async function loadLatest(): Promise<void> {
  try {
    const envelope = await saveRepository.loadLatestValid();
    if (!envelope) throw new Error('有効なセーブデータが見つかりません。');
    world = envelope.snapshot;
    queuedCommands = [];
    syncDraft();
    activeTab = 'dashboard';
    statusMessage = '最新の有効なセーブから復旧しました。';
  } catch (error) {
    statusMessage = error instanceof Error ? error.message : 'セーブの復旧に失敗しました。';
  }
  render();
}

async function boot(): Promise<void> {
  try {
    latestSaveAvailable = (await saveRepository.loadLatestValid()) !== null;
  } catch {
    latestSaveAvailable = false;
  }
  render();
  window.setInterval(() => { if (world && !busy) void saveNow('自動保存しました。'); }, 180_000);
  window.addEventListener('keydown', (event) => {
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 's') {
      event.preventDefault();
      void saveNow('手動保存を作成しました。');
    }
  });
}

void boot();
