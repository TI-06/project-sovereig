import type { PlayerCommand, WorldState } from '../domain/types.js';

export interface SaveEnvelope {
  schemaVersion: 1;
  gameVersion: string;
  createdAt: string;
  updatedAt: string;
  checksum: string;
  snapshot: WorldState;
  commandLog: PlayerCommand[];
  rngState: string;
}


function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function isFiniteNumber(value: unknown): value is number {
  return typeof value === 'number' && Number.isFinite(value);
}

function hasNumericFields(record: Record<string, unknown>, fields: readonly string[]): boolean {
  return fields.every((field) => isFiniteNumber(record[field]));
}

function isWorldState(value: unknown): value is WorldState {
  if (!isRecord(value)) return false;
  if (value.schemaVersion !== 1 || typeof value.gameVersion !== 'string' || typeof value.seed !== 'string') return false;
  if (!Number.isInteger(value.turn) || (value.turn as number) < 0 || typeof value.playerNationId !== 'string') return false;
  if (!isRecord(value.date) || !Number.isInteger(value.date.year) || !Number.isInteger(value.date.month)) return false;
  if ((value.date.month as number) < 1 || (value.date.month as number) > 12) return false;
  if (!isRecord(value.nations) || !isRecord(value.regions) || !isRecord(value.commodities) || !isRecord(value.companies) || !isRecord(value.relations)) return false;
  if (!isRecord(value.parties) || !isRecord(value.parliaments) || !isRecord(value.laws) || !isRecord(value.research)) return false;
  if (!isRecord(value.infrastructureProjects) || !isRecord(value.activeCrises) || !isRecord(value.militaries) || !isRecord(value.wars)) return false;
  if (!isRecord(value.intelligence) || !isRecord(value.covertOperations) || !isRecord(value.achievements)) return false;
  if (!Array.isArray(value.populationCohorts) || !Array.isArray(value.history)) return false;
  if (!isRecord(value.nations[value.playerNationId])) return false;

  const nationNumbers = [
    'population', 'treasury', 'debt', 'gdp', 'realGdp', 'growthRate', 'cpi', 'inflation', 'unemployment',
    'policyRate', 'exchangeRate', 'approval', 'stability', 'monthlyRevenue', 'monthlySpending', 'tradeBalance',
    'foreignReserves', 'consumerConfidence', 'businessConfidence', 'inequality',
  ] as const;
  for (const nation of Object.values(value.nations)) {
    if (!isRecord(nation) || typeof nation.id !== 'string' || typeof nation.name !== 'string' || typeof nation.shortName !== 'string') return false;
    if (!hasNumericFields(nation, nationNumbers) || !isRecord(nation.taxPolicy) || !isRecord(nation.budget) || !isRecord(nation.strategy)) return false;
    if (!hasNumericFields(nation.taxPolicy, ['income', 'corporate', 'consumption'])) return false;
    if (!hasNumericFields(nation.budget, ['education', 'healthcare', 'industry'])) return false;
  }

  for (const region of Object.values(value.regions)) {
    if (!isRecord(region) || typeof region.id !== 'string' || typeof region.nationId !== 'string' || typeof region.name !== 'string') return false;
    if (!hasNumericFields(region, ['population', 'urbanization', 'infrastructure', 'education', 'healthcare', 'stability', 'resourceAbundance'])) return false;
  }

  for (const commodity of Object.values(value.commodities)) {
    if (!isRecord(commodity) || typeof commodity.id !== 'string' || typeof commodity.name !== 'string') return false;
    if (!isFiniteNumber(commodity.basePrice) || !isRecord(commodity.prices) || !isRecord(commodity.supply) || !isRecord(commodity.demand) || !isRecord(commodity.stock)) return false;
    for (const nationId of Object.keys(value.nations)) {
      if (![commodity.prices[nationId], commodity.supply[nationId], commodity.demand[nationId], commodity.stock[nationId]].every(isFiniteNumber)) return false;
    }
  }

  for (const company of Object.values(value.companies)) {
    if (!isRecord(company) || typeof company.id !== 'string' || typeof company.nationId !== 'string' || typeof company.regionId !== 'string' || typeof company.name !== 'string') return false;
    if (!hasNumericFields(company, ['cash', 'debt', 'capitalStock', 'employees', 'wage', 'productivity', 'capacity', 'inventory', 'reputation', 'politicalInfluence', 'distressMonths', 'lastRevenue', 'lastProfit'])) return false;
  }

  for (const cohort of value.populationCohorts) {
    if (!isRecord(cohort) || typeof cohort.id !== 'string' || typeof cohort.nationId !== 'string' || typeof cohort.regionId !== 'string') return false;
    if (!hasNumericFields(cohort, ['size', 'employed', 'averageIncome', 'happiness', 'anger', 'politicalInterest'])) return false;
  }

  for (const party of Object.values(value.parties)) {
    if (!isRecord(party) || typeof party.id !== 'string' || typeof party.nationId !== 'string' || typeof party.name !== 'string' || typeof party.ideology !== 'string') return false;
    if (!hasNumericFields(party, ['support', 'seats', 'discipline'])) return false;
  }
  for (const nationId of Object.keys(value.nations)) {
    const parliament = value.parliaments[nationId];
    const research = value.research[nationId];
    const military = value.militaries[nationId];
    const intelligence = value.intelligence[nationId];
    if (!isRecord(parliament) || !Array.isArray(parliament.governmentPartyIds) || !hasNumericFields(parliament, ['totalSeats', 'politicalCapital', 'legitimacy', 'lastElectionTurn', 'nextElectionTurn'])) return false;
    if (!isRecord(research) || typeof research.focus !== 'string' || !isRecord(research.progress) || !isRecord(research.levels) || !Array.isArray(research.unlockedTechnologyIds) || !isFiniteNumber(research.monthlyOutput)) return false;
    if (![...Object.values(research.progress), ...Object.values(research.levels)].every(isFiniteNumber)) return false;
    if (!isRecord(military) || typeof military.mobilized !== 'string' || !hasNumericFields(military, ['budgetShare', 'manpower', 'activePersonnel', 'reservePersonnel', 'readiness', 'armyPower', 'navyPower', 'airPower', 'equipment', 'logistics', 'monthlyCasualties', 'totalCasualties', 'warExhaustion'])) return false;
    if (!isRecord(intelligence) || !isRecord(intelligence.intelligenceConfidence) || !hasNumericFields(intelligence, ['budgetShare', 'capability', 'counterintelligence', 'operationsCompleted', 'operationsDetected'])) return false;
    const confidence = intelligence.intelligenceConfidence;
    if (Object.keys(value.nations).some((targetId) => !isFiniteNumber(confidence[targetId]))) return false;
  }
  for (const law of Object.values(value.laws)) {
    if (!isRecord(law) || typeof law.id !== 'string' || typeof law.lawId !== 'string' || typeof law.nationId !== 'string' || typeof law.active !== 'boolean' || !isFiniteNumber(law.enactedTurn)) return false;
  }
  for (const project of Object.values(value.infrastructureProjects)) {
    if (!isRecord(project) || typeof project.id !== 'string' || typeof project.nationId !== 'string' || typeof project.regionId !== 'string' || typeof project.type !== 'string' || typeof project.status !== 'string') return false;
    if (!hasNumericFields(project, ['remainingMonths', 'durationMonths', 'totalCost', 'spent', 'startedTurn'])) return false;
  }
  for (const crisis of Object.values(value.activeCrises)) {
    if (!isRecord(crisis) || typeof crisis.id !== 'string' || typeof crisis.definitionId !== 'string' || typeof crisis.nationId !== 'string' || typeof crisis.responded !== 'boolean') return false;
    if (!(crisis.regionId === null || typeof crisis.regionId === 'string') || !hasNumericFields(crisis, ['severity', 'impact', 'remainingMonths', 'startedTurn'])) return false;
  }
  for (const war of Object.values(value.wars)) {
    if (!isRecord(war) || typeof war.id !== 'string' || typeof war.attackerId !== 'string' || typeof war.defenderId !== 'string' || typeof war.status !== 'string' || typeof war.outcome !== 'string' || !Array.isArray(war.fronts)) return false;
    if (!hasNumericFields(war, ['startTurn', 'attackerScore', 'defenderScore']) || !(war.endTurn === null || isFiniteNumber(war.endTurn))) return false;
    for (const front of war.fronts) if (!isRecord(front) || typeof front.id !== 'string' || typeof front.regionId !== 'string' || !hasNumericFields(front, ['attackerControl', 'intensity'])) return false;
  }
  for (const operation of Object.values(value.covertOperations)) {
    if (!isRecord(operation) || typeof operation.id !== 'string' || typeof operation.operatorNationId !== 'string' || typeof operation.targetNationId !== 'string' || typeof operation.type !== 'string' || typeof operation.status !== 'string' || typeof operation.detected !== 'boolean') return false;
    if (!hasNumericFields(operation, ['remainingMonths', 'durationMonths', 'cost', 'progress', 'startedTurn']) || !(operation.completedTurn === null || isFiniteNumber(operation.completedTurn))) return false;
  }
  for (const achievement of Object.values(value.achievements)) {
    if (!isRecord(achievement) || typeof achievement.id !== 'string' || typeof achievement.title !== 'string' || typeof achievement.description !== 'string' || !isFiniteNumber(achievement.unlockedTurn)) return false;
  }

  return value.lastReport === null || isRecord(value.lastReport);
}

function isSaveEnvelope(value: unknown): value is SaveEnvelope {
  if (!isRecord(value) || value.schemaVersion !== 1 || typeof value.gameVersion !== 'string') return false;
  if (typeof value.createdAt !== 'string' || typeof value.updatedAt !== 'string' || typeof value.checksum !== 'string' || typeof value.rngState !== 'string') return false;
  return Array.isArray(value.commandLog) && isWorldState(value.snapshot);
}

function stableStringify(value: unknown): string {
  if (value === null || typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(stableStringify).join(',')}]`;
  const record = value as Record<string, unknown>;
  return `{${Object.keys(record).sort().map((key) => `${JSON.stringify(key)}:${stableStringify(record[key])}`).join(',')}}`;
}

function hash(text: string): string {
  let value = 2166136261;
  for (let index = 0; index < text.length; index += 1) {
    value ^= text.charCodeAt(index);
    value = Math.imul(value, 16777619);
  }
  return (value >>> 0).toString(16).padStart(8, '0');
}

function payload(envelope: Omit<SaveEnvelope, 'checksum'> | SaveEnvelope): unknown {
  const { checksum: _checksum, ...rest } = envelope as SaveEnvelope;
  return rest;
}

export function createSaveEnvelope(snapshot: WorldState, commandLog: PlayerCommand[] = []): SaveEnvelope {
  const now = new Date().toISOString();
  const base: Omit<SaveEnvelope, 'checksum'> = {
    schemaVersion: 1, gameVersion: snapshot.gameVersion, createdAt: now, updatedAt: now,
    snapshot: structuredClone(snapshot), commandLog: structuredClone(commandLog), rngState: snapshot.seed,
  };
  return { ...base, checksum: hash(stableStringify(base)) };
}

export function verifySaveEnvelope(envelope: unknown): envelope is SaveEnvelope {
  return isSaveEnvelope(envelope) && envelope.checksum === hash(stableStringify(payload(envelope)));
}

export interface SaveRepository {
  save(envelope: SaveEnvelope): Promise<void>;
  list(): Promise<SaveEnvelope[]>;
  loadLatestValid(): Promise<SaveEnvelope | null>;
}

export class MemorySaveRepository implements SaveRepository {
  private generations: SaveEnvelope[] = [];
  async save(envelope: SaveEnvelope): Promise<void> {
    this.generations.unshift(structuredClone(envelope));
    this.generations = this.generations.slice(0, 10);
  }
  async list(): Promise<SaveEnvelope[]> {
    return structuredClone(this.generations);
  }
  async loadLatestValid(): Promise<SaveEnvelope | null> {
    const found = this.generations.find(verifySaveEnvelope);
    return found ? structuredClone(found) : null;
  }
}

export function serializeSave(envelope: SaveEnvelope): string {
  return JSON.stringify(envelope, null, 2);
}

export function parseSave(text: string): SaveEnvelope {
  const parsed: unknown = JSON.parse(text);
  if (isRecord(parsed) && isRecord(parsed.snapshot) && typeof parsed.snapshot.gameVersion === 'string' && parsed.snapshot.gameVersion !== '0.2.0') {
    throw new Error(`セーブデータのバージョン${parsed.snapshot.gameVersion}には対応していません。`);
  }
  if (!isSaveEnvelope(parsed)) throw new Error('セーブデータの構造が不正です。');
  if (!verifySaveEnvelope(parsed)) throw new Error('セーブデータのチェックサムが一致しません。');
  return parsed;
}
