import type { SaveEnvelope, SaveRepository } from './save.js';
import { verifySaveEnvelope } from './save.js';

const DB_NAME = 'project-sovereign';
const STORE_NAME = 'save-generations';
const DB_VERSION = 1;

function requestToPromise<T>(request: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    request.addEventListener('success', () => resolve(request.result));
    request.addEventListener('error', () => reject(request.error ?? new Error('IndexedDB operation failed')));
  });
}

async function openDatabase(): Promise<IDBDatabase> {
  const request = indexedDB.open(DB_NAME, DB_VERSION);
  request.addEventListener('upgradeneeded', () => {
    const database = request.result;
    if (!database.objectStoreNames.contains(STORE_NAME)) database.createObjectStore(STORE_NAME, { keyPath: 'updatedAt' });
  });
  return requestToPromise(request);
}

export class IndexedDbSaveRepository implements SaveRepository {
  async save(envelope: SaveEnvelope): Promise<void> {
    const database = await openDatabase();
    const transaction = database.transaction(STORE_NAME, 'readwrite');
    transaction.objectStore(STORE_NAME).put(structuredClone(envelope));
    await new Promise<void>((resolve, reject) => {
      transaction.addEventListener('complete', () => resolve());
      transaction.addEventListener('error', () => reject(transaction.error ?? new Error('保存に失敗しました。')));
    });
    const all = await this.list();
    if (all.length > 10) {
      const cleanup = database.transaction(STORE_NAME, 'readwrite');
      const store = cleanup.objectStore(STORE_NAME);
      for (const item of all.slice(10)) store.delete(item.updatedAt);
    }
    database.close();
  }

  async list(): Promise<SaveEnvelope[]> {
    const database = await openDatabase();
    const transaction = database.transaction(STORE_NAME, 'readonly');
    const values = await requestToPromise(transaction.objectStore(STORE_NAME).getAll()) as SaveEnvelope[];
    database.close();
    return values.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  }

  async loadLatestValid(): Promise<SaveEnvelope | null> {
    const all = await this.list();
    const found = all.find(verifySaveEnvelope);
    return found ? structuredClone(found) : null;
  }
}
