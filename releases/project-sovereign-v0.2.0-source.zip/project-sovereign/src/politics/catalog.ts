import type { PartyIdeology } from '../domain/types.js';

export interface LawDefinition {
  id: string;
  name: string;
  description: string;
  politicalCost: number;
  support: Record<PartyIdeology, number>;
  modifiers: {
    spendingShare?: number;
    businessConfidence?: number;
    consumerConfidence?: number;
    inequality?: number;
    productivity?: number;
    happiness?: number;
  };
}

export const lawCatalog: readonly LawDefinition[] = [
  {
    id: 'universal-healthcare', name: '国民医療保障法', description: '公的医療を拡充し、生活安定と低所得層の支持を高める。', politicalCost: 24,
    support: { social: 1, liberal: 0.82, conservative: 0.25, national: 0.38 },
    modifiers: { spendingShare: 0.008, consumerConfidence: 1.2, happiness: 2.4 },
  },
  {
    id: 'industrial-strategy', name: '国家産業戦略法', description: '重点産業へ長期投資し、生産性と企業景況を高める。', politicalCost: 22,
    support: { social: 0.52, liberal: 0.58, conservative: 0.72, national: 0.88 },
    modifiers: { spendingShare: 0.006, businessConfidence: 1.4, productivity: 0.002 },
  },
  {
    id: 'labor-protection', name: '労働保護強化法', description: '雇用保護と労働条件を改善するが、企業負担を増やす。', politicalCost: 20,
    support: { social: 0.94, liberal: 0.7, conservative: 0.28, national: 0.45 },
    modifiers: { businessConfidence: -0.8, inequality: -0.006, happiness: 1.2 },
  },
  {
    id: 'market-liberalization', name: '市場競争促進法', description: '規制を緩和し企業活動を促進するが、格差拡大の恐れがある。', politicalCost: 19,
    support: { social: 0.22, liberal: 0.92, conservative: 0.82, national: 0.42 },
    modifiers: { businessConfidence: 1.8, inequality: 0.005, productivity: 0.0015 },
  },
  {
    id: 'green-transition', name: 'エネルギー転換法', description: 'エネルギー安全保障と長期的な技術基盤を強化する。', politicalCost: 26,
    support: { social: 0.82, liberal: 0.8, conservative: 0.35, national: 0.62 },
    modifiers: { spendingShare: 0.005, consumerConfidence: 0.4, productivity: 0.0008 },
  },
];

export function getLawDefinition(lawId: string): LawDefinition | undefined {
  return lawCatalog.find((law) => law.id === lawId);
}
