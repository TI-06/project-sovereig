import type { DomainEvent, LawState, NationId, NationState, ParliamentState, PartyIdeology, PartyState, PlayerCommand, WorldState } from '../domain/types.js';
import { createRng, deriveSeed } from '../simulation/rng.js';
import { clamp, round } from '../simulation/utils.js';
import { getLawDefinition } from './catalog.js';

const ideologyNames: Record<PartyIdeology, string> = {
  social: '社会連帯党', liberal: '自由改革党', conservative: '保守国民党', national: '国家進歩党',
};

const initialSupport: Record<NationId, Record<PartyIdeology, number>> = {
  'nation:arcadia': { social: 30, liberal: 28, conservative: 24, national: 18 },
  'nation:valen': { social: 21, liberal: 22, conservative: 31, national: 26 },
  'nation:selene': { social: 20, liberal: 37, conservative: 27, national: 16 },
  'nation:dorn': { social: 24, liberal: 12, conservative: 18, national: 46 },
};

function allocateSeats(support: Array<{ id: string; value: number }>, totalSeats: number): Record<string, number> {
  const total = support.reduce((sum, item) => sum + item.value, 0) || 1;
  const exact = support.map((item) => ({ ...item, exact: item.value / total * totalSeats }));
  const seats = Object.fromEntries(exact.map((item) => [item.id, Math.floor(item.exact)])) as Record<string, number>;
  let remaining = totalSeats - Object.values(seats).reduce((sum, value) => sum + value, 0);
  exact.sort((a, b) => (b.exact - Math.floor(b.exact)) - (a.exact - Math.floor(a.exact)) || a.id.localeCompare(b.id));
  for (let index = 0; index < remaining; index += 1) seats[exact[index % exact.length]!.id] += 1;
  return seats;
}

function chooseGovernment(parties: PartyState[], totalSeats: number): string[] {
  const sorted = [...parties].sort((a, b) => b.seats - a.seats || b.support - a.support);
  const coalition: string[] = [];
  let seats = 0;
  for (const party of sorted) {
    coalition.push(party.id);
    seats += party.seats;
    if (seats > totalSeats / 2) break;
  }
  return coalition;
}

export function createPoliticalSystem(nations: Record<NationId, NationState>): {
  parties: Record<string, PartyState>;
  parliaments: Record<NationId, ParliamentState>;
  laws: Record<string, LawState>;
} {
  const parties: Record<string, PartyState> = {};
  const parliaments = {} as Record<NationId, ParliamentState>;
  for (const nation of Object.values(nations)) {
    const nationParties: PartyState[] = (Object.keys(initialSupport[nation.id]) as PartyIdeology[]).map((ideology, index) => ({
      id: `party:${nation.id.slice(7)}:${ideology}`, nationId: nation.id,
      name: `${nation.shortName}${ideologyNames[ideology]}`, ideology,
      support: initialSupport[nation.id][ideology], seats: 0, discipline: 0.72 + index * 0.06,
    }));
    const seats = allocateSeats(nationParties.map((party) => ({ id: party.id, value: party.support })), 200);
    for (const party of nationParties) { party.seats = seats[party.id] ?? 0; parties[party.id] = party; }
    parliaments[nation.id] = {
      nationId: nation.id, totalSeats: 200, governmentPartyIds: chooseGovernment(nationParties, 200),
      politicalCapital: 68, legitimacy: nation.stability, lastElectionTurn: 0, nextElectionTurn: 48,
    };
  }
  return { parties, parliaments, laws: {} };
}

export function getPoliticalModifiers(world: WorldState, nationId: NationId): {
  spendingShare: number; businessConfidence: number; consumerConfidence: number; inequality: number; productivity: number; happiness: number;
} {
  const result = { spendingShare: 0, businessConfidence: 0, consumerConfidence: 0, inequality: 0, productivity: 0, happiness: 0 };
  for (const law of Object.values(world.laws)) {
    if (!law.active || law.nationId !== nationId) continue;
    const modifiers = getLawDefinition(law.lawId)?.modifiers;
    if (!modifiers) continue;
    for (const key of Object.keys(result) as Array<keyof typeof result>) result[key] += modifiers[key] ?? 0;
  }
  return result;
}

function lawSupport(world: WorldState, nationId: NationId, lawId: string): number {
  const definition = getLawDefinition(lawId);
  if (!definition) return 0;
  return Object.values(world.parties)
    .filter((party) => party.nationId === nationId)
    .reduce((sum, party) => sum + party.seats * party.discipline * definition.support[party.ideology], 0);
}

export function applyPoliticalCommand(world: WorldState, command: PlayerCommand, events: DomainEvent[]): boolean {
  if (command.type !== 'propose-law' && command.type !== 'repeal-law' && command.type !== 'call-snap-election') return false;
  const nationId = world.playerNationId;
  const parliament = world.parliaments[nationId];
  if (command.type === 'call-snap-election') {
    if (parliament.politicalCapital < 35) throw new Error('解散総選挙には政治資本35が必要です。');
    parliament.politicalCapital = round(parliament.politicalCapital - 35, 3);
    parliament.nextElectionTurn = world.turn;
    events.push({ id: `election-call:${world.turn}`, type: 'info', title: '議会を解散', description: '解散総選挙を実施します。', nationId });
    return true;
  }
  const definition = getLawDefinition(command.lawId);
  if (!definition) throw new Error('指定された法律が存在しません。');
  const key = `law:${nationId}:${command.lawId}`;
  if (command.type === 'propose-law') {
    if (world.laws[key]?.active) throw new Error('この法律は既に施行されています。');
    if (parliament.politicalCapital < definition.politicalCost) throw new Error(`法案提出には政治資本${definition.politicalCost}が必要です。`);
    parliament.politicalCapital = round(parliament.politicalCapital - definition.politicalCost, 3);
    const support = lawSupport(world, nationId, command.lawId);
    if (support > parliament.totalSeats / 2) {
      world.laws[key] = { id: key, lawId: definition.id, nationId, enactedTurn: world.turn, active: true };
      events.push({ id: `law-pass:${world.turn}:${definition.id}`, type: 'info', title: `法案可決：${definition.name}`, description: definition.description, nationId });
    } else {
      parliament.legitimacy = round(clamp(parliament.legitimacy - 1.5, 0, 100), 3);
      events.push({ id: `law-fail:${world.turn}:${definition.id}`, type: 'warning', title: `法案否決：${definition.name}`, description: '議会過半数の支持を得られませんでした。', nationId });
    }
  } else {
    const active = world.laws[key];
    if (!active?.active) throw new Error('廃止対象の法律が施行されていません。');
    if (parliament.politicalCapital < Math.ceil(definition.politicalCost * 0.6)) throw new Error('法律廃止に必要な政治資本が不足しています。');
    parliament.politicalCapital = round(parliament.politicalCapital - Math.ceil(definition.politicalCost * 0.6), 3);
    active.active = false;
    events.push({ id: `law-repeal:${world.turn}:${definition.id}`, type: 'info', title: `法律廃止：${definition.name}`, description: '既存法を廃止しました。', nationId });
  }
  return true;
}

function runElection(world: WorldState, nationId: NationId, events: DomainEvent[]): void {
  const nation = world.nations[nationId];
  const parliament = world.parliaments[nationId];
  const parties = Object.values(world.parties).filter((party) => party.nationId === nationId);
  const rng = createRng(deriveSeed(world.seed, world.turn, 'election', nationId));
  for (const party of parties) {
    let drift = rng.between(-1.6, 1.6);
    if (party.ideology === 'social') drift += (nation.unemployment - 0.06) * 28 + (0.4 - nation.inequality) * 8;
    if (party.ideology === 'liberal') drift += (nation.businessConfidence - 55) * 0.035 + nation.growthRate * 30;
    if (party.ideology === 'conservative') drift += (nation.stability - 55) * 0.025 - nation.inflation * 4;
    if (party.ideology === 'national') drift += (55 - nation.stability) * 0.035 + nation.inflation * 3;
    party.support = round(clamp(party.support + drift, 4, 62), 3);
  }
  const totalSupport = parties.reduce((sum, party) => sum + party.support, 0);
  for (const party of parties) party.support = round(party.support / totalSupport * 100, 3);
  const seats = allocateSeats(parties.map((party) => ({ id: party.id, value: party.support })), parliament.totalSeats);
  for (const party of parties) party.seats = seats[party.id] ?? 0;
  parliament.governmentPartyIds = chooseGovernment(parties, parliament.totalSeats);
  parliament.lastElectionTurn = world.turn;
  parliament.nextElectionTurn = world.turn + 48;
  parliament.legitimacy = round(clamp(45 + nation.approval * 0.45, 20, 95), 3);
  parliament.politicalCapital = round(clamp(48 + nation.approval * 0.32, 25, 85), 3);
  if (nationId === world.playerNationId) events.push({ id: `election:${world.turn}`, type: 'info', title: '総選挙を実施', description: '新たな議席配分と連立政権が確定しました。', nationId });
}

export function updatePoliticalSystem(world: WorldState, events: DomainEvent[]): void {
  for (const nation of Object.values(world.nations)) {
    const parliament = world.parliaments[nation.id];
    parliament.politicalCapital = round(clamp(parliament.politicalCapital + nation.approval / 100 * 1.4 + nation.stability / 100 * 0.8 - 0.7, 0, 100), 3);
    parliament.legitimacy = round(clamp(parliament.legitimacy * 0.96 + nation.approval * 0.04, 0, 100), 3);
    if (world.turn >= parliament.nextElectionTurn) runElection(world, nation.id, events);
  }
}
