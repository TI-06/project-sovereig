function hash(text: string): number {
  let value = 2166136261;
  for (let index = 0; index < text.length; index += 1) {
    value ^= text.charCodeAt(index);
    value = Math.imul(value, 16777619);
  }
  return value >>> 0;
}

export function deriveSeed(...parts: Array<string | number>): string {
  return parts.join('|');
}

export interface SeededRng {
  next(): number;
  between(min: number, max: number): number;
  integer(min: number, max: number): number;
}

export function createRng(seed: string): SeededRng {
  let state = hash(seed) || 1;
  const next = (): number => {
    state ^= state << 13;
    state ^= state >>> 17;
    state ^= state << 5;
    return (state >>> 0) / 4294967296;
  };
  return {
    next,
    between(min: number, max: number): number {
      return min + (max - min) * next();
    },
    integer(min: number, max: number): number {
      return Math.floor(this.between(min, max + 1));
    },
  };
}
