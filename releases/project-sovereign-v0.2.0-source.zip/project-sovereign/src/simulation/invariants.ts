import type { NationId, WorldState } from '../domain/types.js';

function assertFiniteNonNegative(value: number, label: string): void {
  if (!Number.isFinite(value) || value < 0) throw new Error(`不変条件違反: ${label}=${value}`);
}

function assertRange(value: number, minimum: number, maximum: number, label: string): void {
  if (!Number.isFinite(value) || value < minimum || value > maximum) throw new Error(`不変条件違反: ${label}=${value}`);
}

function assertNationRecord(world: WorldState, nationId: NationId, record: unknown, label: string): void {
  if (!world.nations[nationId] || !record) throw new Error(`不変条件違反: ${label}.${nationId}`);
}

export function assertWorldInvariants(world: WorldState): void {
  if (!Number.isInteger(world.turn) || world.turn < 0) throw new Error('不変条件違反: turn');
  if (!world.nations[world.playerNationId]) throw new Error('不変条件違反: playerNationId');
  for (const nation of Object.values(world.nations)) {
    assertFiniteNonNegative(nation.population, `${nation.id}.population`);
    assertFiniteNonNegative(nation.gdp, `${nation.id}.gdp`);
    assertFiniteNonNegative(nation.realGdp, `${nation.id}.realGdp`);
    assertFiniteNonNegative(nation.cpi, `${nation.id}.cpi`);
    assertFiniteNonNegative(nation.debt, `${nation.id}.debt`);
    assertFiniteNonNegative(nation.treasury, `${nation.id}.treasury`);
    assertRange(nation.approval, 0, 100, `${nation.id}.approval`);
    assertRange(nation.stability, 0, 100, `${nation.id}.stability`);
    assertRange(nation.unemployment, 0, 1, `${nation.id}.unemployment`);
    assertNationRecord(world, nation.id, world.parliaments[nation.id], 'parliament');
    assertNationRecord(world, nation.id, world.research[nation.id], 'research');
    assertNationRecord(world, nation.id, world.militaries[nation.id], 'military');
    assertNationRecord(world, nation.id, world.intelligence[nation.id], 'intelligence');
  }
  for (const commodity of Object.values(world.commodities)) {
    for (const nationId of Object.keys(world.nations) as NationId[]) {
      assertFiniteNonNegative(commodity.prices[nationId], `${commodity.id}.price.${nationId}`);
      assertFiniteNonNegative(commodity.stock[nationId], `${commodity.id}.stock.${nationId}`);
      assertFiniteNonNegative(commodity.supply[nationId], `${commodity.id}.supply.${nationId}`);
      assertFiniteNonNegative(commodity.demand[nationId], `${commodity.id}.demand.${nationId}`);
    }
  }
  for (const company of Object.values(world.companies)) {
    if (!world.nations[company.nationId] || !world.regions[company.regionId]) throw new Error(`不変条件違反: ${company.id}.ownership`);
    assertFiniteNonNegative(company.employees, `${company.id}.employees`);
    assertFiniteNonNegative(company.inventory, `${company.id}.inventory`);
    assertFiniteNonNegative(company.capitalStock, `${company.id}.capitalStock`);
    assertFiniteNonNegative(company.debt, `${company.id}.debt`);
  }
  for (const cohort of world.populationCohorts) {
    assertFiniteNonNegative(cohort.size, `${cohort.id}.size`);
    assertFiniteNonNegative(cohort.employed, `${cohort.id}.employed`);
    if (cohort.employed > cohort.size + 0.001) throw new Error(`不変条件違反: ${cohort.id}.employment`);
    assertRange(cohort.happiness, 0, 100, `${cohort.id}.happiness`);
    assertRange(cohort.anger, 0, 100, `${cohort.id}.anger`);
  }
  for (const relation of Object.values(world.relations)) {
    if (!world.nations[relation.fromNationId] || !world.nations[relation.toNationId] || relation.fromNationId === relation.toNationId) throw new Error(`不変条件違反: ${relation.id}.nations`);
    assertRange(relation.trust, 0, 100, `${relation.id}.trust`);
    assertRange(relation.threat, 0, 100, `${relation.id}.threat`);
    assertRange(relation.dependence, 0, 100, `${relation.id}.dependence`);
    assertRange(relation.grievance, 0, 100, `${relation.id}.grievance`);
  }
  for (const party of Object.values(world.parties)) {
    if (!world.nations[party.nationId]) throw new Error(`不変条件違反: ${party.id}.nationId`);
    assertRange(party.support, 0, 100, `${party.id}.support`);
    if (!Number.isInteger(party.seats) || party.seats < 0) throw new Error(`不変条件違反: ${party.id}.seats`);
    assertRange(party.discipline, 0, 1, `${party.id}.discipline`);
  }
  for (const parliament of Object.values(world.parliaments)) {
    assertRange(parliament.politicalCapital, 0, 100, `${parliament.nationId}.politicalCapital`);
    assertRange(parliament.legitimacy, 0, 100, `${parliament.nationId}.legitimacy`);
    const parties = Object.values(world.parties).filter((party) => party.nationId === parliament.nationId);
    const seatTotal = parties.reduce((sum, party) => sum + party.seats, 0);
    if (seatTotal !== parliament.totalSeats) throw new Error(`不変条件違反: ${parliament.nationId}.seatTotal=${seatTotal}`);
    if (parliament.governmentPartyIds.some((id) => !world.parties[id])) throw new Error(`不変条件違反: ${parliament.nationId}.governmentPartyIds`);
  }
  for (const law of Object.values(world.laws)) {
    if (!world.nations[law.nationId] || !Number.isInteger(law.enactedTurn) || law.enactedTurn < 0) throw new Error(`不変条件違反: ${law.id}`);
  }
  for (const research of Object.values(world.research)) {
    assertFiniteNonNegative(research.monthlyOutput, `${research.nationId}.research.monthlyOutput`);
    for (const [field, level] of Object.entries(research.levels)) {
      if (!Number.isInteger(level) || level < 0 || level > 5) throw new Error(`不変条件違反: ${research.nationId}.research.${field}.level`);
      assertFiniteNonNegative(research.progress[field as keyof typeof research.progress], `${research.nationId}.research.${field}.progress`);
    }
  }
  for (const project of Object.values(world.infrastructureProjects)) {
    if (!world.nations[project.nationId] || !world.regions[project.regionId]) throw new Error(`不変条件違反: ${project.id}.target`);
    if (!Number.isInteger(project.remainingMonths) || project.remainingMonths < 0) throw new Error(`不変条件違反: ${project.id}.remainingMonths`);
    assertFiniteNonNegative(project.totalCost, `${project.id}.totalCost`);
    assertFiniteNonNegative(project.spent, `${project.id}.spent`);
  }
  for (const crisis of Object.values(world.activeCrises)) {
    if (!world.nations[crisis.nationId] || (crisis.regionId && !world.regions[crisis.regionId])) throw new Error(`不変条件違反: ${crisis.id}.target`);
    assertRange(crisis.severity, 0, 1, `${crisis.id}.severity`);
    assertRange(crisis.impact, 0, 1, `${crisis.id}.impact`);
    if (!Number.isInteger(crisis.remainingMonths) || crisis.remainingMonths < 0) throw new Error(`不変条件違反: ${crisis.id}.remainingMonths`);
  }
  for (const military of Object.values(world.militaries)) {
    assertFiniteNonNegative(military.manpower, `${military.nationId}.military.manpower`);
    assertFiniteNonNegative(military.activePersonnel, `${military.nationId}.military.activePersonnel`);
    assertFiniteNonNegative(military.reservePersonnel, `${military.nationId}.military.reservePersonnel`);
    if (military.activePersonnel > military.manpower + 1 || military.reservePersonnel > military.manpower + 1) throw new Error(`不変条件違反: ${military.nationId}.military.personnel`);
    for (const field of ['readiness', 'armyPower', 'navyPower', 'airPower', 'equipment', 'logistics', 'warExhaustion'] as const) assertRange(military[field], 0, 100, `${military.nationId}.military.${field}`);
    assertFiniteNonNegative(military.monthlyCasualties, `${military.nationId}.military.monthlyCasualties`);
    assertFiniteNonNegative(military.totalCasualties, `${military.nationId}.military.totalCasualties`);
  }
  for (const war of Object.values(world.wars)) {
    if (!world.nations[war.attackerId] || !world.nations[war.defenderId] || war.attackerId === war.defenderId) throw new Error(`不変条件違反: ${war.id}.participants`);
    assertFiniteNonNegative(war.attackerScore, `${war.id}.attackerScore`);
    assertFiniteNonNegative(war.defenderScore, `${war.id}.defenderScore`);
    for (const front of war.fronts) {
      if (!world.regions[front.regionId]) throw new Error(`不変条件違反: ${front.id}.regionId`);
      assertRange(front.attackerControl, 0, 100, `${front.id}.attackerControl`);
      assertRange(front.intensity, 0, 1, `${front.id}.intensity`);
    }
  }
  for (const intelligence of Object.values(world.intelligence)) {
    assertRange(intelligence.budgetShare, 0, 0.08, `${intelligence.nationId}.intelligence.budgetShare`);
    assertRange(intelligence.capability, 0, 100, `${intelligence.nationId}.intelligence.capability`);
    assertRange(intelligence.counterintelligence, 0, 100, `${intelligence.nationId}.intelligence.counterintelligence`);
    for (const nationId of Object.keys(world.nations) as NationId[]) assertRange(intelligence.intelligenceConfidence[nationId], 0, 100, `${intelligence.nationId}.intelligence.confidence.${nationId}`);
    assertFiniteNonNegative(intelligence.operationsCompleted, `${intelligence.nationId}.intelligence.operationsCompleted`);
    assertFiniteNonNegative(intelligence.operationsDetected, `${intelligence.nationId}.intelligence.operationsDetected`);
  }
  for (const operation of Object.values(world.covertOperations)) {
    if (!world.nations[operation.operatorNationId] || !world.nations[operation.targetNationId] || operation.operatorNationId === operation.targetNationId) throw new Error(`不変条件違反: ${operation.id}.participants`);
    if (!Number.isInteger(operation.remainingMonths) || operation.remainingMonths < 0) throw new Error(`不変条件違反: ${operation.id}.remainingMonths`);
    assertRange(operation.progress, 0, 100, `${operation.id}.progress`);
    assertFiniteNonNegative(operation.cost, `${operation.id}.cost`);
  }
  for (const achievement of Object.values(world.achievements)) {
    if (!achievement.id || !achievement.title || !Number.isInteger(achievement.unlockedTurn) || achievement.unlockedTurn < 0 || achievement.unlockedTurn > world.turn) throw new Error(`不変条件違反: achievement.${achievement.id}`);
  }
}
