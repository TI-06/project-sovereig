import { validateCommands } from '../domain/commands.js';
import type {
  BilateralRelation,
  CommodityId,
  DomainEvent,
  MetricContribution,
  MetricExplanation,
  MonthlyReport,
  NationId,
  NationState,
  PlayerCommand,
  SimulationInput,
  SimulationOutput,
  WorldState,
} from '../domain/types.js';
import { applyCrisisCommand, getCrisisStopReason, updateCrises } from '../crises/system.js';
import { applyDevelopmentCommand, getDevelopmentModifiers, updateDevelopmentSystem } from '../development/system.js';
import { applyMilitaryCommand, getWarStopReason, updateMilitarySystem } from '../military/system.js';
import { applyIntelligenceCommand, getIntelligenceSpendingShare, updateIntelligenceSystem } from '../intelligence/system.js';
import { evaluateAchievements } from '../achievements/system.js';
import { applyPoliticalCommand, getPoliticalModifiers, updatePoliticalSystem } from '../politics/system.js';
import { assertWorldInvariants } from './invariants.js';
import { createRng, deriveSeed } from './rng.js';
import { advanceDate, clamp, relationKey, round, sum } from './utils.js';

interface NationMonthStats {
  companyRevenue: number;
  companyProfit: number;
  employmentDelta: number;
  bankruptcies: number;
  commodityInflation: number[];
  tradeBoost: number;
}

function makeStats(world: WorldState): Record<NationId, NationMonthStats> {
  return Object.fromEntries((Object.keys(world.nations) as NationId[]).map((nationId) => [nationId, {
    companyRevenue: 0, companyProfit: 0, employmentDelta: 0, bankruptcies: 0, commodityInflation: [], tradeBoost: 0,
  }])) as Record<NationId, NationMonthStats>;
}

function applyPlayerCommands(world: WorldState, commands: PlayerCommand[], events: DomainEvent[]): void {
  const nation = world.nations[world.playerNationId];
  for (const command of commands) {
    if (applyPoliticalCommand(world, command, events)) continue;
    if (applyDevelopmentCommand(world, command, events)) continue;
    if (applyCrisisCommand(world, command, events)) continue;
    if (applyMilitaryCommand(world, command, events)) continue;
    if (applyIntelligenceCommand(world, command, events)) continue;
    switch (command.type) {
      case 'set-tax-rate':
        nation.taxPolicy[command.tax] = round(command.value, 4);
        break;
      case 'set-policy-rate':
        nation.policyRate = round(command.value, 4);
        break;
      case 'set-budget-share':
        nation.budget[command.category] = round(command.value, 4);
        break;
      case 'propose-trade-agreement': {
        const forward = world.relations[relationKey(world.playerNationId, command.targetNationId)];
        const reverse = world.relations[relationKey(command.targetNationId, world.playerNationId)];
        if (forward && reverse) {
          const acceptance = reverse.trust + reverse.dependence * 0.55 - reverse.threat * 0.3;
          if (acceptance >= 58) {
            forward.tradeAgreement = true;
            reverse.tradeAgreement = true;
            events.push({ id: `trade:${world.turn}:${command.targetNationId}`, type: 'diplomacy', title: '貿易協定を締結',
              description: `${world.nations[command.targetNationId].shortName}が貿易協定を受諾しました。`, nationId: world.playerNationId });
          } else {
            forward.trust = clamp(forward.trust - 1, 0, 100);
            events.push({ id: `trade-reject:${world.turn}:${command.targetNationId}`, type: 'warning', title: '貿易協定を拒否',
              description: `${world.nations[command.targetNationId].shortName}は条件が整っていないとして提案を拒否しました。`, nationId: world.playerNationId });
          }
        }
        break;
      }
      case 'end-trade-agreement': {
        const forward = world.relations[relationKey(world.playerNationId, command.targetNationId)];
        const reverse = world.relations[relationKey(command.targetNationId, world.playerNationId)];
        if (forward && reverse) {
          forward.tradeAgreement = false;
          reverse.tradeAgreement = false;
          forward.trust = clamp(forward.trust - 5, 0, 100);
          reverse.trust = clamp(reverse.trust - 8, 0, 100);
        }
        break;
      }
    }
  }
}

function applyAiPolicies(world: WorldState): void {
  for (const nation of Object.values(world.nations)) {
    if (nation.id === world.playerNationId) continue;
    const rng = createRng(deriveSeed(world.seed, world.turn, 'ai-policy', nation.id));
    const debtRatio = nation.debt / Math.max(1, nation.gdp);
    const inflationPressure = nation.inflation - 0.025;
    const growthPressure = 0.018 - nation.growthRate;
    if (inflationPressure > 0.015) nation.policyRate = round(clamp(nation.policyRate + 0.001 + rng.next() * 0.002, -0.05, 0.5), 4);
    else if (growthPressure > 0.012) nation.policyRate = round(clamp(nation.policyRate - 0.001 - rng.next() * 0.0015, -0.05, 0.5), 4);
    if (debtRatio > 1.15 && nation.strategy.fiscalDiscipline > 0.45) {
      nation.taxPolicy.consumption = round(clamp(nation.taxPolicy.consumption + 0.001, 0, 0.8), 4);
      nation.budget.industry = round(clamp(nation.budget.industry - 0.0005, 0.01, 0.25), 4);
    } else if (nation.strategy.primaryGoal === 'growth' && nation.businessConfidence < 58) {
      nation.budget.industry = round(clamp(nation.budget.industry + 0.0008, 0, 0.25), 4);
    } else if (nation.strategy.primaryGoal === 'welfare' && nation.approval < 52) {
      nation.budget.healthcare = round(clamp(nation.budget.healthcare + 0.0006, 0, 0.25), 4);
    }
  }
}

function prepareMarkets(world: WorldState): void {
  for (const commodity of Object.values(world.commodities)) {
    for (const nation of Object.values(world.nations)) {
      const populationScale = nation.population / 1_000_000;
      const confidence = 0.72 + nation.consumerConfidence / 180;
      const developmentModifiers = getDevelopmentModifiers(world, nation.id);
      const commodityWeight: Record<CommodityId, number> = {
        'commodity:food': 1.4, 'commodity:energy': 1.15, 'commodity:steel': 0.82, 'commodity:machinery': 0.78,
        'commodity:consumer': 1.05, 'commodity:medicine': 0.66, 'commodity:transport': 0.94, 'commodity:finance': 0.7,
      };
      commodity.demand[nation.id] = round((populationScale * commodityWeight[commodity.id] * confidence + 40) * (commodity.id === 'commodity:energy' ? 1 - developmentModifiers.energyEfficiency : 1), 4);
      commodity.supply[nation.id] = round(45 + commodity.stock[nation.id] * 0.04, 4);
    }
  }
}

function simulateCompanies(world: WorldState, stats: Record<NationId, NationMonthStats>, events: DomainEvent[]): void {
  for (const company of Object.values(world.companies)) {
    if (company.status === 'bankrupt') continue;
    const nation = world.nations[company.nationId];
    const politicalModifiers = getPoliticalModifiers(world, nation.id);
    const developmentModifiers = getDevelopmentModifiers(world, nation.id);
    const commodity = world.commodities[company.commodityId];
    const rng = createRng(deriveSeed(world.seed, world.turn, 'company', company.id));
    const openingEmployees = company.employees;
    const demandIndex = commodity.demand[company.nationId] / 100;
    const industrySupport = 1 + nation.budget.industry * 1.8;
    const financingPenalty = clamp(nation.policyRate * 0.9, -0.03, 0.35);
    const targetUtilization = clamp(0.62 + demandIndex * 0.22 + industrySupport * 0.08 - financingPenalty + rng.between(-0.025, 0.025), 0.35, 1.08);
    const production = clamp(company.capacity * company.productivity * targetUtilization, 1, company.capacity * 1.2);
    const targetEmployees = Math.max(2_000, production * 1_900 / Math.max(0.45, company.productivity));
    company.employees = round(Math.max(0, openingEmployees + (targetEmployees - openingEmployees) * 0.1), 0);
    const available = company.inventory + production;
    const marketShare = 0.11 + company.reputation / 1200;
    const sold = Math.min(available, commodity.demand[company.nationId] * marketShare);
    company.inventory = round(clamp(available - sold, 0, company.capacity * 2.4), 4);
    const unitPrice = commodity.prices[company.nationId] / 100;
    const revenue = sold * unitPrice * 0.72;
    const laborCost = company.employees / 100_000 * company.wage * 1.8;
    const materialCost = production * unitPrice * 0.31;
    const maintenance = company.capitalStock * 0.006;
    const interest = company.debt * Math.max(0.001, nation.policyRate / 12 + 0.0025);
    const operatingProfit = revenue - laborCost - materialCost - maintenance - interest;
    const taxes = Math.max(0, operatingProfit) * nation.taxPolicy.corporate;
    const netProfit = operatingProfit - taxes;
    const investment = netProfit > 0 && nation.businessConfidence > 55 ? Math.min(netProfit * 0.24, company.capitalStock * 0.015) : 0;
    company.cash = round(company.cash + netProfit - investment, 4);
    company.capitalStock = round(Math.max(5, company.capitalStock * 0.998 + investment), 4);
    company.capacity = round(Math.max(2, company.capacity * 0.999 + investment * 0.07), 4);
    company.productivity = round(clamp(company.productivity + nation.budget.education * 0.00045 + investment * 0.00015 + politicalModifiers.productivity + developmentModifiers.productivity, 0.4, 2.2), 6);
    company.lastRevenue = round(revenue, 4);
    company.lastProfit = round(netProfit, 4);
    if (company.cash < 0) {
      const borrowingRoom = Math.max(0, company.capitalStock * 1.1 - company.debt);
      const financing = Math.min(-company.cash + 2, borrowingRoom * 0.16);
      company.cash = round(company.cash + financing, 4);
      company.debt = round(company.debt + financing, 4);
    } else if (company.debt > 0 && company.cash > 18) {
      const repayment = Math.min(company.debt, company.cash * 0.06);
      company.cash = round(company.cash - repayment, 4);
      company.debt = round(company.debt - repayment, 4);
    }
    const distressed = company.cash < -8 || company.debt > company.capitalStock * 1.65 || netProfit < -company.capitalStock * 0.09;
    company.distressMonths = distressed ? company.distressMonths + 1 : Math.max(0, company.distressMonths - 1);
    company.status = company.distressMonths > 0 ? 'distressed' : 'active';
    if (company.distressMonths >= 3 && company.cash < -12 && company.debt > company.capitalStock * 1.25) {
      company.status = 'bankrupt';
      company.employees = 0;
      company.inventory = 0;
      stats[company.nationId].bankruptcies += 1;
      events.push({ id: `bankruptcy:${world.turn}:${company.id}`, type: 'company', title: '主要企業が経営破綻',
        description: `${company.name}が資金調達に失敗し、操業を停止しました。`, nationId: company.nationId, entityId: company.id });
    }
    stats[company.nationId].companyRevenue += revenue;
    stats[company.nationId].companyProfit += netProfit;
    stats[company.nationId].employmentDelta += company.employees - openingEmployees;
    commodity.supply[company.nationId] += production;
  }
}

function updateMarkets(world: WorldState, previous: WorldState, stats: Record<NationId, NationMonthStats>): void {
  for (const commodity of Object.values(world.commodities)) {
    for (const nation of Object.values(world.nations)) {
      const nationId = nation.id;
      const oldPrice = previous.commodities[commodity.id].prices[nationId];
      const relationTrade = Object.values(world.relations).filter((relation) => relation.fromNationId === nationId && relation.tradeAgreement).length;
      const accessibleSupply = commodity.supply[nationId] + commodity.stock[nationId] * 0.09 + relationTrade * 4.5;
      const shortage = (commodity.demand[nationId] - accessibleSupply) / Math.max(40, accessibleSupply);
      const ratePressure = clamp(-nation.policyRate * 0.05, -0.02, 0.005);
      const change = clamp(shortage * 0.055 + ratePressure, -0.075, 0.12);
      commodity.prices[nationId] = round(Math.max(1, oldPrice * (1 + change)), 4);
      commodity.stock[nationId] = round(clamp(commodity.stock[nationId] + commodity.supply[nationId] - commodity.demand[nationId], 0, 260), 4);
      stats[nationId].commodityInflation.push(change);
      stats[nationId].tradeBoost += relationTrade * 0.08;
    }
  }
}

function taxTake(nation: NationState): number {
  return nation.taxPolicy.income * 0.39 + nation.taxPolicy.corporate * 0.2 + nation.taxPolicy.consumption * 0.32;
}

function updateEconomy(world: WorldState, previous: WorldState, stats: Record<NationId, NationMonthStats>): void {
  for (const nation of Object.values(world.nations)) {
    const old = previous.nations[nation.id];
    const nationStats = stats[nation.id];
    const politicalModifiers = getPoliticalModifiers(world, nation.id);
    const military = world.militaries[nation.id];
    const mobilizationShare = military.mobilized === 'full' ? 0.11 : military.mobilized === 'partial' ? 0.06 : 0;
    const annualizedCompanyOutput = nationStats.companyRevenue * 12;
    const confidenceFactor = 0.92 + nation.businessConfidence / 1200;
    const newGdp = clamp(old.gdp * 0.89 + annualizedCompanyOutput * confidenceFactor * 0.11, 180, 20_000);
    nation.growthRate = round((newGdp / Math.max(1, old.gdp)) - 1, 6);
    nation.gdp = round(newGdp, 4);
    const monthlyInflation = clamp(sum(nationStats.commodityInflation) / Math.max(1, nationStats.commodityInflation.length), -0.05, 0.18);
    nation.cpi = round(clamp(old.cpi * (1 + monthlyInflation), 35, 10_000), 4);
    nation.inflation = round(clamp(monthlyInflation * 12, -0.2, 1.2), 6);
    nation.realGdp = round(nation.gdp / (nation.cpi / 100), 4);
    const growthJobs = nation.growthRate * -0.42;
    const companyJobs = nationStats.employmentDelta / Math.max(1, nation.population * 0.55) * -2.2;
    const mobilizationLaborDrag = military.mobilized === 'none' ? 0 : military.activePersonnel / Math.max(1, nation.population * 0.55) * (military.mobilized === 'full' ? 0.12 : 0.06);
    nation.unemployment = round(clamp(old.unemployment + growthJobs + companyJobs + mobilizationLaborDrag + nationStats.bankruptcies * 0.004, 0.018, 0.35), 6);
    const effectiveTake = clamp(taxTake(nation) * (0.85 - nation.unemployment * 0.35), 0.04, 0.55);
    nation.monthlyRevenue = round(nation.gdp / 12 * effectiveTake, 4);
    const programShare = nation.budget.education + nation.budget.healthcare + nation.budget.industry;
    const interestCost = nation.debt * Math.max(0.001, nation.policyRate / 12 + 0.0018);
    const intelligenceShare = getIntelligenceSpendingShare(world, nation.id);
    nation.monthlySpending = round(nation.gdp / 12 * (0.078 + programShare + politicalModifiers.spendingShare + military.budgetShare + mobilizationShare + intelligenceShare) + interestCost, 4);
    const fiscalBalance = nation.monthlyRevenue - nation.monthlySpending;
    nation.treasury = round(nation.treasury + fiscalBalance, 4);
    if (nation.treasury < 0) {
      nation.debt = round(nation.debt + Math.abs(nation.treasury), 4);
      nation.treasury = 0;
    } else if (nation.treasury > nation.gdp * 0.24 && nation.debt > 0) {
      const debtPayment = Math.min(nation.debt, (nation.treasury - nation.gdp * 0.24) * 0.08);
      nation.treasury = round(nation.treasury - debtPayment, 4);
      nation.debt = round(nation.debt - debtPayment, 4);
    }
    nation.debt = round(clamp(nation.debt, 0, nation.gdp * 20), 4);
    const supplyTotal = sum(Object.values(world.commodities).map((commodity) => commodity.supply[nation.id]));
    const demandTotal = sum(Object.values(world.commodities).map((commodity) => commodity.demand[nation.id]));
    nation.tradeBalance = round((supplyTotal - demandTotal) * 0.11 + nationStats.tradeBoost, 4);
    nation.foreignReserves = round(clamp(nation.foreignReserves + nation.tradeBalance * 0.18, 0, 5_000), 4);
    nation.exchangeRate = round(clamp(old.exchangeRate * (1 + monthlyInflation * 0.22 - nation.tradeBalance / Math.max(1, nation.gdp) * 0.08 - nation.policyRate * 0.01), 0.2, 8), 5);
    nation.consumerConfidence = round(clamp(old.consumerConfidence + nation.growthRate * 75 - nation.inflation * 1.4 - (nation.unemployment - old.unemployment) * 180 + politicalModifiers.consumerConfidence, 10, 95), 3);
    nation.businessConfidence = round(clamp(old.businessConfidence + nation.growthRate * 90 - nation.policyRate * 2.5 + nation.budget.industry * 6 - nationStats.bankruptcies * 4 + politicalModifiers.businessConfidence, 10, 95), 3);
    nation.inequality = round(clamp(old.inequality + politicalModifiers.inequality, 0.18, 0.72), 4);
  }
}

function updatePopulationAndPolitics(world: WorldState, previous: WorldState): void {
  for (const cohort of world.populationCohorts) {
    const nation = world.nations[cohort.nationId];
    const oldNation = previous.nations[cohort.nationId];
    const demographicDrift = cohort.incomeBand === 'low' ? 0.00018 : cohort.incomeBand === 'middle' ? 0.00008 : -0.00002;
    cohort.size = round(Math.max(0, cohort.size * (1 + demographicDrift / 12)), 2);
    cohort.employed = round(clamp(cohort.size * (1 - nation.unemployment) * (cohort.incomeBand === 'low' ? 0.92 : cohort.incomeBand === 'middle' ? 1 : 1.03), 0, cohort.size), 2);
    const wageGrowth = clamp(nation.growthRate * 0.5 - nation.inflation / 12 * 0.35 + nation.budget.education * 0.008, -0.025, 0.035);
    cohort.averageIncome = round(Math.max(0.25, cohort.averageIncome * (1 + wageGrowth)), 4);
    const politicalModifiers = getPoliticalModifiers(world, nation.id);
    const developmentModifiers = getDevelopmentModifiers(world, nation.id);
    const healthcareBenefit = nation.budget.healthcare * (cohort.incomeBand === 'low' ? 13 : 7);
    const educationBenefit = nation.budget.education * (cohort.incomeBand === 'middle' ? 8 : 5);
    const taxPain = nation.taxPolicy.consumption * (cohort.incomeBand === 'low' ? 9 : 4) + nation.taxPolicy.income * (cohort.incomeBand === 'high' ? 6 : 2);
    const targetHappiness = 66 + nation.growthRate * 150 - nation.inflation * 38 - nation.unemployment * 95 + healthcareBenefit + educationBenefit - taxPain + politicalModifiers.happiness + developmentModifiers.healthcare;
    cohort.happiness = round(clamp(cohort.happiness * 0.88 + targetHappiness * 0.12, 5, 95), 3);
    cohort.anger = round(clamp(100 - cohort.happiness + nation.inequality * (cohort.incomeBand === 'low' ? 18 : 4), 2, 98), 3);
    cohort.politicalInterest = round(clamp(cohort.politicalInterest + (cohort.anger - 35) * 0.006, 20, 95), 3);
    nation.population = 0;
    void oldNation;
  }
  for (const nation of Object.values(world.nations)) {
    const cohorts = world.populationCohorts.filter((cohort) => cohort.nationId === nation.id);
    nation.population = round(sum(cohorts.map((cohort) => cohort.size)), 2);
    const weightedHappiness = sum(cohorts.map((cohort) => cohort.happiness * cohort.size)) / Math.max(1, nation.population);
    const old = previous.nations[nation.id];
    const fiscalPenalty = nation.debt / Math.max(1, nation.gdp) > 1.35 ? 6 : 0;
    const performance = nation.growthRate * 100 + (old.unemployment - nation.unemployment) * 45 - nation.inflation * 8;
    const approvalTarget = weightedHappiness * 0.82 + performance - fiscalPenalty;
    nation.approval = round(clamp(old.approval * 0.84 + approvalTarget * 0.16, 3, 95), 3);
    const stabilityTarget = 48 + nation.approval * 0.43 - nation.unemployment * 70 - nation.inflation * 17 - nation.inequality * 12;
    nation.stability = round(clamp(old.stability * 0.9 + stabilityTarget * 0.1, 5, 95), 3);
  }
}

function updateDiplomacy(world: WorldState): void {
  for (const relation of Object.values(world.relations)) {
    const from = world.nations[relation.fromNationId];
    const to = world.nations[relation.toNationId];
    const rng = createRng(deriveSeed(world.seed, world.turn, 'relation', relation.id));
    const economicAffinity = 1 - Math.abs(from.growthRate - to.growthRate) * 2;
    const agreementBoost = relation.tradeAgreement ? 0.35 : 0;
    const isolationPenalty = to.id === 'nation:dorn' || from.id === 'nation:dorn' ? -0.1 : 0;
    relation.trust = round(clamp(relation.trust + agreementBoost + economicAffinity * 0.06 + isolationPenalty + rng.between(-0.12, 0.12), 0, 100), 3);
    relation.dependence = round(clamp(relation.dependence + (relation.tradeAgreement ? 0.16 : -0.04), 0, 100), 3);
    relation.threat = round(clamp(relation.threat + (to.stability < 35 ? 0.22 : -0.03) + rng.between(-0.08, 0.08), 0, 100), 3);
    relation.grievance = round(clamp(relation.grievance + (relation.sanctioned ? 0.5 : -0.08), 0, 100), 3);
    if (!relation.tradeAgreement && !relation.sanctioned && from.id !== world.playerNationId) {
      const score = relation.trust * 0.55 + relation.dependence * 0.35 + from.strategy.tradePreference * 20 - relation.threat * 0.2;
      if (score > 67 && rng.next() > 0.94) {
        relation.tradeAgreement = true;
        const reverse = world.relations[relationKey(relation.toNationId, relation.fromNationId)];
        if (reverse) reverse.tradeAgreement = true;
      }
    }
  }
}

function contribution(source: string, amount: number, description: string): MetricContribution {
  return { source, amount: round(amount, 4), description };
}

function sortedContributions(items: MetricContribution[]): MetricContribution[] {
  return items.sort((a, b) => Math.abs(b.amount) - Math.abs(a.amount)).slice(0, 5);
}

function makeReport(world: WorldState, previous: WorldState, events: DomainEvent[], stats: Record<NationId, NationMonthStats>): MonthlyReport {
  const nation = world.nations[world.playerNationId];
  const old = previous.nations[world.playerNationId];
  const inflationDelta = nation.inflation - old.inflation;
  const approvalDelta = nation.approval - old.approval;
  const treasuryDelta = nation.treasury - old.treasury;
  const explanations: MetricExplanation[] = [
    {
      metric: 'gdp', label: '名目GDP', previousValue: old.gdp, currentValue: nation.gdp,
      contributions: sortedContributions([
        contribution('企業生産', stats[nation.id].companyRevenue * 0.12, '主要企業の売上と生産活動'),
        contribution('企業景況感', (nation.businessConfidence - old.businessConfidence) * 0.45, '企業の投資・採用姿勢'),
        contribution('金利環境', -nation.policyRate * 18, '政策金利による投資需要への影響'),
        contribution('産業支援', nation.budget.industry * 34, '産業補助金と設備投資支援'),
      ]),
    },
    {
      metric: 'inflation', label: '年率インフレ', previousValue: old.inflation, currentValue: nation.inflation,
      contributions: sortedContributions([
        contribution('商品需給', inflationDelta * 0.72, '国内の商品不足・在庫状況'),
        contribution('政策金利', -nation.policyRate * 0.09, '金融引き締めによる需要抑制'),
        contribution('為替', (nation.exchangeRate - old.exchangeRate) * 0.08, '輸入価格に対する通貨変動'),
      ]),
    },
    {
      metric: 'approval', label: '政権支持率', previousValue: old.approval, currentValue: nation.approval,
      contributions: sortedContributions([
        contribution('生活実感', (nation.consumerConfidence - old.consumerConfidence) * 0.18, '消費者信頼感と実質所得'),
        contribution('雇用', (old.unemployment - nation.unemployment) * 35, '雇用環境の改善・悪化'),
        contribution('物価', -nation.inflation * 6, '生活費の上昇'),
        contribution('医療・教育', (nation.budget.healthcare + nation.budget.education) * 12, '公共サービスへの支出'),
        contribution('財政不安', nation.debt / Math.max(1, nation.gdp) > 1.35 ? -4 : 0.5, '政府債務への評価'),
      ]),
    },
    {
      metric: 'treasury', label: '国庫', previousValue: old.treasury, currentValue: nation.treasury,
      contributions: sortedContributions([
        contribution('税収', nation.monthlyRevenue, '所得税・法人税・消費税'),
        contribution('政府支出', -nation.monthlySpending, '行政・教育・医療・産業政策・利払い'),
        contribution('貿易収支', nation.tradeBalance * 0.1, '対外取引による間接的な財政効果'),
      ]),
    },
    {
      metric: 'tradeBalance', label: '貿易収支', previousValue: old.tradeBalance, currentValue: nation.tradeBalance,
      contributions: sortedContributions([
        contribution('国内供給', sum(Object.values(world.commodities).map((item) => item.supply[nation.id])) * 0.01, '国内企業と資源の供給能力'),
        contribution('国内需要', -sum(Object.values(world.commodities).map((item) => item.demand[nation.id])) * 0.01, '家計・企業の輸入需要'),
        contribution('貿易協定', stats[nation.id].tradeBoost, '協定国との市場アクセス'),
      ]),
    },
    {
      metric: 'unemployment', label: '失業率', previousValue: old.unemployment, currentValue: nation.unemployment,
      contributions: sortedContributions([
        contribution('企業雇用', -stats[nation.id].employmentDelta / 100_000, '主要企業の採用・解雇'),
        contribution('景気', -nation.growthRate * 0.42, '経済成長による労働需要'),
        contribution('企業倒産', stats[nation.id].bankruptcies * 0.4, '主要企業の操業停止'),
      ]),
    },
  ];
  const alerts: string[] = [];
  const debtRatio = nation.debt / Math.max(1, nation.gdp);
  if (debtRatio > 1.5) alerts.push(`債務残高がGDP比${(debtRatio * 100).toFixed(0)}%に達しています。`);
  if (nation.inflation > 0.12) alerts.push(`インフレ率が${(nation.inflation * 100).toFixed(1)}%まで上昇しています。`);
  if (nation.approval < 35) alerts.push(`支持率が${nation.approval.toFixed(1)}%まで低下しています。`);
  if (nation.stability < 30) alerts.push(`国家安定度が${nation.stability.toFixed(1)}まで低下しています。`);
  const activeCrisisCount = Object.values(world.activeCrises).filter((crisis) => crisis.nationId === nation.id).length;
  if (activeCrisisCount > 0) alerts.push(`対応中の国家危機が${activeCrisisCount}件あります。`);
  const direction = nation.growthRate >= 0 ? '拡大' : '縮小';
  return {
    turn: world.turn, date: { ...world.date }, headline: `${world.date.year}年${world.date.month}月 国家月報`,
    summary: `経済は前月比${(nation.growthRate * 100).toFixed(2)}%で${direction}。支持率は${approvalDelta >= 0 ? '+' : ''}${approvalDelta.toFixed(1)}ポイント変化しました。`,
    explanations, events, alerts,
  };
}

function determineStopReason(world: WorldState, previous: WorldState, report: MonthlyReport, stats: Record<NationId, NationMonthStats>): string | null {
  const nation = world.nations[world.playerNationId];
  const old = previous.nations[world.playerNationId];
  const crisisReason = getCrisisStopReason(world);
  if (crisisReason) return crisisReason;
  const warReason = getWarStopReason(world);
  if (warReason) return warReason;
  const debtRatio = nation.debt / Math.max(1, nation.gdp);
  if (debtRatio > 1.5) return '財政破綻リスクが危険域に入りました。';
  if (nation.inflation > 0.12 || nation.inflation - old.inflation > 0.02) return '物価上昇が警戒基準を超えました。';
  if (old.approval - nation.approval > 5) return '支持率が1か月で5ポイント以上低下しました。';
  if (stats[nation.id].bankruptcies > 0) return '主要企業の倒産が発生しました。';
  if (nation.stability < 25) return '国家安定度が危機水準です。';
  return report.alerts.length > 0 && debtRatio > 1.4 ? report.alerts[0]! : null;
}

export function advanceMonth(input: SimulationInput): SimulationOutput {
  const validation = validateCommands(input.commands, input.previous);
  if (!validation.ok) throw new Error(validation.errors.map((item) => item.message).join('\n'));
  const previous = input.previous;
  const world = structuredClone(previous);
  world.turn += 1;
  world.date = advanceDate(previous.date);
  const events: DomainEvent[] = [];
  applyPlayerCommands(world, validation.commands, events);
  applyAiPolicies(world);
  updateMilitarySystem(world, events);
  prepareMarkets(world);
  const stats = makeStats(world);
  simulateCompanies(world, stats, events);
  updateMarkets(world, previous, stats);
  updateEconomy(world, previous, stats);
  updateDevelopmentSystem(world, events);
  updatePopulationAndPolitics(world, previous);
  updatePoliticalSystem(world, events);
  updateCrises(world, events);
  updateIntelligenceSystem(world, events);
  updateDiplomacy(world);
  evaluateAchievements(world, events);
  const report = makeReport(world, previous, events, stats);
  world.lastReport = report;
  const player = world.nations[world.playerNationId];
  world.history.push({ turn: world.turn, date: { ...world.date }, gdp: player.gdp, inflation: player.inflation,
    unemployment: player.unemployment, approval: player.approval, treasury: player.treasury, debt: player.debt });
  if (world.history.length > 240) world.history = world.history.slice(-240);
  assertWorldInvariants(world);
  const stopReason = determineStopReason(world, previous, report, stats);
  return { next: world, report, shouldStop: stopReason !== null, stopReason };
}

export function advanceMonths(previous: WorldState, commands: PlayerCommand[], months: 1 | 3 | 6 | 12): {
  next: WorldState;
  reports: MonthlyReport[];
  monthsProcessed: number;
  stoppedBy: string | null;
} {
  let world = previous;
  const reports: MonthlyReport[] = [];
  let stoppedBy: string | null = null;
  for (let index = 0; index < months; index += 1) {
    const output = advanceMonth({ previous: world, commands: index === 0 ? commands : [] });
    world = output.next;
    reports.push(output.report);
    if (output.shouldStop) {
      stoppedBy = output.stopReason;
      break;
    }
  }
  return { next: world, reports, monthsProcessed: reports.length, stoppedBy };
}
