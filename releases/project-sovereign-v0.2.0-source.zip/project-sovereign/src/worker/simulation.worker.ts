/// <reference lib="webworker" />
import type { PlayerCommand, WorldState } from '../domain/types.js';
import { advanceMonths } from '../simulation/engine.js';

type AdvanceRequest = {
  id: number;
  type: 'advance';
  world: WorldState;
  commands: PlayerCommand[];
  months: 1 | 3 | 6 | 12;
};

type WorkerRequest = AdvanceRequest;

self.addEventListener('message', (event: MessageEvent<WorkerRequest>) => {
  const request = event.data;
  try {
    if (request.type === 'advance') {
      const result = advanceMonths(request.world, request.commands, request.months);
      self.postMessage({ id: request.id, ok: true, result });
    }
  } catch (error) {
    self.postMessage({
      id: request.id,
      ok: false,
      error: error instanceof Error ? error.message : 'シミュレーション処理に失敗しました。',
    });
  }
});
