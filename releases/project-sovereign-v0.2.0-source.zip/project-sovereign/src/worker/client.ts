import type { MonthlyReport, PlayerCommand, WorldState } from '../domain/types.js';

interface AdvanceResult {
  next: WorldState;
  reports: MonthlyReport[];
  monthsProcessed: number;
  stoppedBy: string | null;
}

interface PendingRequest {
  resolve(value: AdvanceResult): void;
  reject(reason: Error): void;
}

export class SimulationWorkerClient {
  private worker: Worker;
  private sequence = 0;
  private readonly pending = new Map<number, PendingRequest>();

  constructor() {
    this.worker = this.createWorker();
  }

  private createWorker(): Worker {
    const worker = new Worker(new URL('./simulation.worker.js', import.meta.url), { type: 'module' });
    worker.addEventListener('message', (event: MessageEvent<{ id: number; ok: boolean; result?: AdvanceResult; error?: string }>) => {
      const request = this.pending.get(event.data.id);
      if (!request) return;
      this.pending.delete(event.data.id);
      if (event.data.ok && event.data.result) request.resolve(event.data.result);
      else request.reject(new Error(event.data.error ?? 'Workerから不正な応答を受信しました。'));
    });
    worker.addEventListener('error', () => {
      for (const request of this.pending.values()) request.reject(new Error('シミュレーションWorkerが停止しました。'));
      this.pending.clear();
      worker.terminate();
      this.worker = this.createWorker();
    });
    return worker;
  }

  advance(world: WorldState, commands: PlayerCommand[], months: 1 | 3 | 6 | 12): Promise<AdvanceResult> {
    const id = ++this.sequence;
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.worker.postMessage({ id, type: 'advance', world, commands, months });
    });
  }
}
