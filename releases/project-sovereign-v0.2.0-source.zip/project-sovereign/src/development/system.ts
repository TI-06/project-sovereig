import type { DomainEvent, InfrastructureProject, NationId, NationState, PlayerCommand, ResearchField, ResearchState, WorldState } from '../domain/types.js';
import { clamp, round } from '../simulation/utils.js';
import { infrastructureCatalog, researchFields, researchNames } from './catalog.js';

export function createDevelopmentSystem(nations: Record<NationId, NationState>): {
  research: Record<NationId, ResearchState>;
  infrastructureProjects: Record<string, InfrastructureProject>;
} {
  const research = {} as Record<NationId, ResearchState>;
  for (const nation of Object.values(nations)) {
    const zeros = Object.fromEntries(researchFields.map((field) => [field, 0])) as Record<ResearchField, number>;
    research[nation.id] = {
      nationId: nation.id, focus: nation.strategy.primaryGoal === 'security' ? 'defense' : nation.strategy.primaryGoal === 'growth' ? 'industry' : 'computing',
      monthlyOutput: 0, progress: { ...zeros }, levels: { ...zeros }, unlockedTechnologyIds: [],
    };
  }
  return { research, infrastructureProjects: {} };
}

export function applyDevelopmentCommand(world: WorldState, command: PlayerCommand, events: DomainEvent[]): boolean {
  if (command.type === 'set-research-focus') {
    world.research[world.playerNationId].focus = command.focus;
    events.push({ id: `research-focus:${world.turn}:${command.focus}`, type: 'info', title: '研究重点を変更', description: `${researchNames[command.focus]}を重点研究分野に指定しました。`, nationId: world.playerNationId });
    return true;
  }
  if (command.type !== 'start-infrastructure-project') return false;
  const region = world.regions[command.regionId];
  if (!region || region.nationId !== world.playerNationId) throw new Error('自国の地域を指定してください。');
  const duplicate = Object.values(world.infrastructureProjects).some((project) => project.regionId === command.regionId && project.type === command.projectType && project.status === 'active');
  if (duplicate) throw new Error('同じ地域で同種の公共事業が進行中です。');
  const definition = infrastructureCatalog[command.projectType];
  const id = `project:${world.playerNationId.slice(7)}:${command.regionId.slice(7)}:${command.projectType}:${world.turn}`;
  world.infrastructureProjects[id] = {
    id, nationId: world.playerNationId, regionId: command.regionId, type: command.projectType, status: 'active',
    remainingMonths: definition.durationMonths, durationMonths: definition.durationMonths, totalCost: definition.totalCost, spent: 0, startedTurn: world.turn,
  };
  events.push({ id: `project-start:${id}`, type: 'info', title: `公共事業開始：${definition.name}`, description: `${region.name}で事業を開始しました。`, nationId: world.playerNationId, entityId: id });
  return true;
}

function spend(nation: NationState, amount: number): void {
  nation.treasury = round(nation.treasury - amount, 4);
  if (nation.treasury < 0) {
    nation.debt = round(nation.debt + Math.abs(nation.treasury), 4);
    nation.treasury = 0;
  }
}

function updateResearch(world: WorldState, events: DomainEvent[]): void {
  for (const nation of Object.values(world.nations)) {
    const research = world.research[nation.id];
    const regions = Object.values(world.regions).filter((region) => region.nationId === nation.id);
    const education = regions.reduce((sum, region) => sum + region.education, 0) / Math.max(1, regions.length);
    research.monthlyOutput = round(3.2 + nation.budget.education * 70 + education * 0.025, 4);
    const secondary = research.monthlyOutput * 0.1;
    for (const field of researchFields) research.progress[field] = round(research.progress[field] + (field === research.focus ? research.monthlyOutput * 0.5 : secondary), 4);
    for (const field of researchFields) {
      let level = research.levels[field];
      const threshold = 100 + level * 80;
      if (research.progress[field] >= threshold && level < 5) {
        research.progress[field] = round(research.progress[field] - threshold, 4);
        level += 1;
        research.levels[field] = level;
        const technologyId = `${field}-${level}`;
        if (!research.unlockedTechnologyIds.includes(technologyId)) research.unlockedTechnologyIds.push(technologyId);
        if (nation.id === world.playerNationId) events.push({ id: `technology:${world.turn}:${technologyId}`, type: 'info', title: `技術確立：${researchNames[field]} Lv.${level}`, description: '国家技術基盤が強化されました。', nationId: nation.id });
      }
    }
  }
}

function updateProjects(world: WorldState, events: DomainEvent[]): void {
  for (const project of Object.values(world.infrastructureProjects)) {
    if (project.status !== 'active') continue;
    const definition = infrastructureCatalog[project.type];
    const monthlyCost = definition.totalCost / definition.durationMonths;
    spend(world.nations[project.nationId], monthlyCost);
    project.spent = round(project.spent + monthlyCost, 4);
    project.remainingMonths = Math.max(0, project.remainingMonths - 1);
    if (project.remainingMonths > 0) continue;
    project.status = 'completed';
    const region = world.regions[project.regionId];
    region.infrastructure = round(clamp(region.infrastructure + (definition.effects.infrastructure ?? 0), 0, 100), 3);
    region.education = round(clamp(region.education + (definition.effects.education ?? 0), 0, 100), 3);
    region.healthcare = round(clamp(region.healthcare + (definition.effects.healthcare ?? 0), 0, 100), 3);
    region.stability = round(clamp(region.stability + (definition.effects.stability ?? 0), 0, 100), 3);
    region.resourceAbundance = round(clamp(region.resourceAbundance + (definition.effects.resourceAbundance ?? 0), 0.1, 2), 4);
    if (project.nationId === world.playerNationId) events.push({ id: `project-complete:${project.id}`, type: 'info', title: `公共事業完成：${definition.name}`, description: `${region.name}の社会基盤が改善しました。`, nationId: project.nationId, entityId: project.id });
  }
}

export function getDevelopmentModifiers(world: WorldState, nationId: NationId): { productivity: number; healthcare: number; energyEfficiency: number; defense: number } {
  const levels = world.research[nationId].levels;
  return {
    productivity: levels.industry * 0.0012 + levels.computing * 0.001,
    healthcare: levels.medicine * 0.8,
    energyEfficiency: levels.energy * 0.018,
    defense: levels.defense * 0.04,
  };
}

export function updateDevelopmentSystem(world: WorldState, events: DomainEvent[]): void {
  updateResearch(world, events);
  updateProjects(world, events);
}
