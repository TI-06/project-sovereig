import type { InfrastructureProjectType, ResearchField } from '../domain/types.js';

export const researchFields: readonly ResearchField[] = ['agriculture', 'industry', 'energy', 'computing', 'medicine', 'defense'];

export const researchNames: Record<ResearchField, string> = {
  agriculture: '農業・食料', industry: '産業工学', energy: 'エネルギー', computing: '情報技術', medicine: '医療・生命', defense: '防衛技術',
};

export const infrastructureCatalog: Record<InfrastructureProjectType, {
  name: string; durationMonths: number; totalCost: number;
  effects: { infrastructure?: number; education?: number; healthcare?: number; stability?: number; resourceAbundance?: number };
}> = {
  transport: { name: '広域交通網', durationMonths: 12, totalCost: 36, effects: { infrastructure: 9, stability: 1 } },
  power: { name: '電力基盤増強', durationMonths: 16, totalCost: 48, effects: { infrastructure: 7, resourceAbundance: 0.08 } },
  university: { name: '国立研究大学', durationMonths: 18, totalCost: 42, effects: { education: 11, infrastructure: 2 } },
  hospital: { name: '高度医療拠点', durationMonths: 12, totalCost: 34, effects: { healthcare: 11, stability: 1 } },
  digital: { name: '国家デジタル網', durationMonths: 10, totalCost: 30, effects: { infrastructure: 6, education: 3 } },
};
