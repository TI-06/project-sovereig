import test from 'node:test';
import assert from 'node:assert/strict';
import { createInitialWorld } from '../dist/src/content/create-world.js';
import { advanceMonth } from '../dist/src/simulation/engine.js';

test('research focus redirects progress without changing generated research', () => {
  const base = createInitialWorld({ playerNationId: 'nation:arcadia', seed: 'research-focus' });
  const changed = structuredClone(base);
  const normal = advanceMonth({ previous: base, commands: [] }).next.research['nation:arcadia'];
  const focused = advanceMonth({ previous: changed, commands: [{ type: 'set-research-focus', focus: 'medicine' }] }).next.research['nation:arcadia'];
  const normalGain = Object.values(normal.progress).reduce((sum, value) => sum + value, 0);
  const focusedGain = Object.values(focused.progress).reduce((sum, value) => sum + value, 0);
  assert.ok(Math.abs(normalGain - focusedGain) < 0.01);
  assert.ok(focused.progress.medicine > normal.progress.medicine);
  assert.equal(focused.focus, 'medicine');
});

test('technology unlocks once and emits an event', () => {
  const world = createInitialWorld({ playerNationId: 'nation:arcadia', seed: 'technology' });
  world.research['nation:arcadia'].focus = 'medicine';
  world.research['nation:arcadia'].progress.medicine = 99;
  const output = advanceMonth({ previous: world, commands: [] });
  assert.ok(output.next.research['nation:arcadia'].unlockedTechnologyIds.includes('medicine-1'));
  assert.equal(output.next.research['nation:arcadia'].levels.medicine, 1);
  assert.ok(output.report.events.some((event) => event.title.includes('技術')));
});

test('infrastructure projects spend over time and improve their region on completion', () => {
  const world = createInitialWorld({ playerNationId: 'nation:arcadia', seed: 'infrastructure' });
  const regionId = 'region:arcadia:1';
  const beforeTreasury = world.nations['nation:arcadia'].treasury;
  const started = advanceMonth({ previous: world, commands: [{ type: 'start-infrastructure-project', regionId, projectType: 'transport' }] }).next;
  const project = Object.values(started.infrastructureProjects)[0];
  assert.ok(project);
  assert.ok(started.nations['nation:arcadia'].treasury < beforeTreasury);
  const beforeInfrastructure = started.regions[regionId].infrastructure;
  project.remainingMonths = 1;
  const completed = advanceMonth({ previous: started, commands: [] });
  assert.equal(completed.next.infrastructureProjects[project.id].status, 'completed');
  assert.ok(completed.next.regions[regionId].infrastructure > beforeInfrastructure);
  assert.ok(completed.report.events.some((event) => event.title.includes('公共事業')));
});
