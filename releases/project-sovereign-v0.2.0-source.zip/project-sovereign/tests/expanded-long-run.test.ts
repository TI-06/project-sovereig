import test from 'node:test';
import assert from 'node:assert/strict';
import { createInitialWorld } from '../dist/src/content/create-world.js';
import { advanceMonth } from '../dist/src/simulation/engine.js';
import { assertWorldInvariants } from '../dist/src/simulation/invariants.js';

test('expanded systems survive 1,200 deterministic monthly turns', () => {
  let world = createInitialWorld({ playerNationId: 'nation:arcadia', seed: 'expanded-1200' });
  for (let turn = 0; turn < 1200; turn += 1) world = advanceMonth({ previous: world, commands: [] }).next;
  assertWorldInvariants(world);
  assert.equal(Object.keys(world.parliaments).length, 4);
  assert.equal(Object.keys(world.research).length, 4);
  assert.equal(Object.keys(world.militaries).length, 4);
  assert.equal(Object.keys(world.intelligence).length, 4);
  assert.ok(Object.keys(world.achievements).length >= 1);
});
