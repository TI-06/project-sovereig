import test from 'node:test';
import assert from 'node:assert/strict';
import { createInitialWorld } from '../dist/src/content/create-world.js';
import { advanceMonth } from '../dist/src/simulation/engine.js';

test('war declaration consumes political capital and creates a symmetric conflict', () => {
  const world = createInitialWorld({ playerNationId: 'nation:arcadia', seed: 'declare-war' });
  const before = world.parliaments['nation:arcadia'].politicalCapital;
  const output = advanceMonth({ previous: world, commands: [{ type: 'declare-war', targetNationId: 'nation:dorn' }] });
  const war = Object.values(output.next.wars)[0];
  assert.ok(war);
  assert.equal(war.attackerId, 'nation:arcadia');
  assert.equal(war.defenderId, 'nation:dorn');
  assert.equal(war.status, 'active');
  assert.ok(output.next.parliaments['nation:arcadia'].politicalCapital < before);
  assert.ok(output.report.events.some((event) => event.title.includes('宣戦')));
});

test('mobilization raises active personnel and readiness while increasing spending', () => {
  const world = createInitialWorld({ playerNationId: 'nation:arcadia', seed: 'mobilize' });
  const control = structuredClone(world);
  const before = structuredClone(world.militaries['nation:arcadia']);
  const baseline = advanceMonth({ previous: control, commands: [] });
  const output = advanceMonth({ previous: world, commands: [{ type: 'mobilize', level: 'partial' }] });
  const after = output.next.militaries['nation:arcadia'];
  assert.ok(after.activePersonnel > before.activePersonnel);
  assert.ok(after.readiness > before.readiness);
  assert.equal(after.mobilized, 'partial');
  assert.ok(output.next.nations['nation:arcadia'].monthlySpending > baseline.next.nations['nation:arcadia'].monthlySpending);
  assert.ok(output.next.nations['nation:arcadia'].unemployment > baseline.next.nations['nation:arcadia'].unemployment);
});

test('war resolution is deterministic and manpower never becomes negative', () => {
  const left = createInitialWorld({ playerNationId: 'nation:arcadia', seed: 'war-determinism' });
  const right = structuredClone(left);
  const command = [{ type: 'declare-war', targetNationId: 'nation:dorn' }];
  let a = advanceMonth({ previous: left, commands: command }).next;
  let b = advanceMonth({ previous: right, commands: command }).next;
  for (let month = 0; month < 24; month += 1) {
    a = advanceMonth({ previous: a, commands: [] }).next;
    b = advanceMonth({ previous: b, commands: [] }).next;
  }
  assert.deepEqual(a.wars, b.wars);
  assert.deepEqual(a.militaries, b.militaries);
  for (const military of Object.values(a.militaries)) {
    assert.ok(military.activePersonnel >= 0);
    assert.ok(military.reservePersonnel >= 0);
  }
});

test('a peace offer ends an exhausted war for both participants', () => {
  const world = createInitialWorld({ playerNationId: 'nation:arcadia', seed: 'peace' });
  const started = advanceMonth({ previous: world, commands: [{ type: 'declare-war', targetNationId: 'nation:dorn' }] }).next;
  const war = Object.values(started.wars)[0];
  started.militaries[war.attackerId].warExhaustion = 65;
  started.militaries[war.defenderId].warExhaustion = 65;
  const output = advanceMonth({ previous: started, commands: [{ type: 'offer-peace', warId: war.id, terms: 'status-quo' }] });
  assert.equal(output.next.wars[war.id].status, 'ended');
  assert.ok(output.report.events.some((event) => event.title.includes('講和')));
});
