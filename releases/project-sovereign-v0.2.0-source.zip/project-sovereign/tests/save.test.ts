import test from 'node:test';
import assert from 'node:assert/strict';
import { createInitialWorld } from '../dist/src/content/create-world.js';
import { createSaveEnvelope, verifySaveEnvelope, MemorySaveRepository, parseSave, serializeSave } from '../dist/src/save/save.js';

test('save checksum detects corruption', () => {
  const envelope = createSaveEnvelope(createInitialWorld({ playerNationId: 'nation:arcadia', seed: 'save' }));
  assert.equal(verifySaveEnvelope(envelope), true);
  envelope.snapshot.turn += 1;
  assert.equal(verifySaveEnvelope(envelope), false);
});

test('repository keeps ten generations and recovers the latest valid one', async () => {
  const repo = new MemorySaveRepository();
  for (let turn = 0; turn < 12; turn += 1) {
    const world = createInitialWorld({ playerNationId: 'nation:arcadia', seed: `save-${turn}` });
    world.turn = turn;
    await repo.save(createSaveEnvelope(world));
  }
  assert.equal((await repo.list()).length, 10);
  const latest = await repo.loadLatestValid();
  assert.equal(latest?.snapshot.turn, 11);
});


test('save parser rejects a checksummed but structurally invalid world', () => {
  const world = createInitialWorld({ playerNationId: 'nation:arcadia', seed: 'invalid-structure' });
  delete world.nations[world.playerNationId];
  const envelope = createSaveEnvelope(world);
  assert.throws(() => parseSave(serializeSave(envelope)), /構造/);
});


test('save parser rejects missing or malformed expanded state blocks', () => {
  const missing = createInitialWorld({ playerNationId: 'nation:arcadia', seed: 'missing-expanded' });
  delete missing.militaries;
  assert.throws(() => parseSave(serializeSave(createSaveEnvelope(missing))), /構造/);

  const malformed = createInitialWorld({ playerNationId: 'nation:arcadia', seed: 'malformed-expanded' });
  malformed.intelligence['nation:arcadia'].intelligenceConfidence['nation:dorn'] = Number.NaN;
  assert.throws(() => parseSave(serializeSave(createSaveEnvelope(malformed))), /構造/);
});
