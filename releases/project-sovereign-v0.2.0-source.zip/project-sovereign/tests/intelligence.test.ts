import test from 'node:test';
import assert from 'node:assert/strict';
import { createInitialWorld } from '../dist/src/content/create-world.js';
import { advanceMonth } from '../dist/src/simulation/engine.js';

test('covert operations resolve deterministically for the same seed and command log', () => {
  const left = createInitialWorld({ playerNationId: 'nation:arcadia', seed: 'intel-determinism' });
  const right = structuredClone(left);
  const commands = [{ type: 'launch-intelligence-operation', targetNationId: 'nation:dorn', operationType: 'influence' }] as const;
  let a = advanceMonth({ previous: left, commands: [...commands] }).next;
  let b = advanceMonth({ previous: right, commands: [...commands] }).next;
  for (let month = 0; month < 5; month += 1) {
    a = advanceMonth({ previous: a, commands: [] }).next;
    b = advanceMonth({ previous: b, commands: [] }).next;
  }
  assert.ok(a.intelligence['nation:arcadia']);
  assert.ok(Object.keys(a.covertOperations).length > 0);
  assert.deepEqual(a.intelligence, b.intelligence);
  assert.deepEqual(a.covertOperations, b.covertOperations);
});

test('a detected covert operation damages bilateral trust and creates grievance', () => {
  const world = createInitialWorld({ playerNationId: 'nation:arcadia', seed: 'intel-detected' });
  const launched = advanceMonth({ previous: world, commands: [{ type: 'launch-intelligence-operation', targetNationId: 'nation:dorn', operationType: 'sabotage' }] }).next;
  const operation = Object.values(launched.covertOperations)[0];
  operation.remainingMonths = 1;
  launched.intelligence['nation:arcadia'].capability = 0;
  launched.intelligence['nation:dorn'].counterintelligence = 100;
  const relation = launched.relations['nation:arcadia->nation:dorn'];
  const beforeTrust = relation.trust;
  const beforeGrievance = relation.grievance;
  const output = advanceMonth({ previous: launched, commands: [] });
  assert.equal(output.next.covertOperations[operation.id].detected, true);
  assert.ok(output.next.relations['nation:arcadia->nation:dorn'].trust < beforeTrust);
  assert.ok(output.next.relations['nation:arcadia->nation:dorn'].grievance > beforeGrievance);
  assert.ok(output.report.events.some((event) => event.title.includes('工作') || event.title.includes('諜報')));
});

test('successful reconnaissance increases knowledge without changing target resources', () => {
  const operated = createInitialWorld({ playerNationId: 'nation:arcadia', seed: 'intel-recon' });
  const control = structuredClone(operated);
  let withOperation = advanceMonth({ previous: operated, commands: [{ type: 'launch-intelligence-operation', targetNationId: 'nation:selene', operationType: 'reconnaissance' }] }).next;
  let withoutOperation = advanceMonth({ previous: control, commands: [] }).next;
  const operation = Object.values(withOperation.covertOperations)[0];
  operation.remainingMonths = 1;
  withOperation.intelligence['nation:arcadia'].capability = 100;
  withOperation.intelligence['nation:selene'].counterintelligence = 0;
  withOperation = advanceMonth({ previous: withOperation, commands: [] }).next;
  withoutOperation = advanceMonth({ previous: withoutOperation, commands: [] }).next;
  assert.ok(withOperation.intelligence['nation:arcadia'].intelligenceConfidence['nation:selene'] > 0);
  assert.equal(withOperation.nations['nation:selene'].treasury, withoutOperation.nations['nation:selene'].treasury);
  const targetCompanyIds = Object.values(withOperation.companies).filter((company) => company.nationId === 'nation:selene').map((company) => company.id);
  for (const companyId of targetCompanyIds) assert.equal(withOperation.companies[companyId].cash, withoutOperation.companies[companyId].cash);
});
