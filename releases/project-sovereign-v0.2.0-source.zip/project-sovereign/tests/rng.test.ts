import test from 'node:test';
import assert from 'node:assert/strict';
import { createRng, deriveSeed } from '../dist/src/simulation/rng.js';

test('seeded RNG replays the same sequence', () => {
  const a = createRng('world-1');
  const b = createRng('world-1');
  assert.deepEqual([a.next(), a.next(), a.next()], [b.next(), b.next(), b.next()]);
});

test('derived seeds are stable and namespaced', () => {
  assert.equal(deriveSeed('world', 12, 'company', '1'), deriveSeed('world', 12, 'company', '1'));
  assert.notEqual(deriveSeed('world', 12, 'company', '1'), deriveSeed('world', 12, 'nation', '1'));
});
