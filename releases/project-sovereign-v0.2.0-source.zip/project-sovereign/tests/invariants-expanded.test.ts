import test from 'node:test';
import assert from 'node:assert/strict';
import { createInitialWorld } from '../dist/src/content/create-world.js';
import { assertWorldInvariants } from '../dist/src/simulation/invariants.js';

test('expanded invariants reject invalid parliament, military, and intelligence state', () => {
  const parliament = createInitialWorld({ playerNationId: 'nation:arcadia', seed: 'bad-parliament' });
  parliament.parliaments['nation:arcadia'].politicalCapital = 150;
  assert.throws(() => assertWorldInvariants(parliament), /politicalCapital|政治|不変条件/);

  const military = createInitialWorld({ playerNationId: 'nation:arcadia', seed: 'bad-military' });
  military.militaries['nation:arcadia'].readiness = -1;
  assert.throws(() => assertWorldInvariants(military), /readiness|不変条件/);

  const intelligence = createInitialWorld({ playerNationId: 'nation:arcadia', seed: 'bad-intelligence' });
  intelligence.intelligence['nation:arcadia'].intelligenceConfidence['nation:dorn'] = 130;
  assert.throws(() => assertWorldInvariants(intelligence), /intelligence|confidence|不変条件/);
});
