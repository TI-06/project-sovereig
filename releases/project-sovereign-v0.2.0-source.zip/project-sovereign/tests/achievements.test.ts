import test from 'node:test';
import assert from 'node:assert/strict';
import { createInitialWorld } from '../dist/src/content/create-world.js';
import { advanceMonth } from '../dist/src/simulation/engine.js';

test('long administration achievement unlocks deterministically and only once', () => {
  const world = createInitialWorld({ playerNationId: 'nation:arcadia', seed: 'achievement-120' });
  world.turn = 119;
  world.date = { year: 2044, month: 12 };
  const first = advanceMonth({ previous: world, commands: [] });
  assert.ok(first.next.achievements['century-administration']);
  assert.ok(first.report.events.some((event) => event.title.includes('実績')));
  const second = advanceMonth({ previous: first.next, commands: [] });
  assert.equal(Object.keys(second.next.achievements).filter((id) => id === 'century-administration').length, 1);
  assert.equal(second.report.events.filter((event) => event.entityId === 'century-administration').length, 0);
});
