import test from 'node:test';
import assert from 'node:assert/strict';
import { createInitialWorld } from '../dist/src/content/create-world.js';

test('creates the complete vertical-slice world', () => {
  const world = createInitialWorld({ playerNationId: 'nation:arcadia', seed: 'demo' });
  assert.equal(Object.keys(world.nations).length, 4);
  assert.equal(Object.keys(world.regions).length, 12);
  assert.equal(Object.keys(world.companies).length, 24);
  assert.equal(Object.keys(world.commodities).length, 8);
  assert.equal(world.populationCohorts.length, 36);
});
