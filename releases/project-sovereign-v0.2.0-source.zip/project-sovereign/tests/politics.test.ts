import test from 'node:test';
import assert from 'node:assert/strict';
import { createInitialWorld } from '../dist/src/content/create-world.js';
import { advanceMonth } from '../dist/src/simulation/engine.js';

test('each nation starts with four parties and a 200-seat parliament', () => {
  const world = createInitialWorld({ playerNationId: 'nation:arcadia', seed: 'politics' });
  assert.equal(Object.keys(world.parties).length, 16);
  for (const nationId of Object.keys(world.nations)) {
    const parliament = world.parliaments[nationId];
    assert.equal(parliament.totalSeats, 200);
    const seats = Object.values(world.parties).filter((party) => party.nationId === nationId).reduce((sum, party) => sum + party.seats, 0);
    assert.equal(seats, 200);
    assert.ok(parliament.governmentPartyIds.length >= 1);
  }
});

test('a supported law consumes political capital and becomes active', () => {
  const world = createInitialWorld({ playerNationId: 'nation:arcadia', seed: 'law' });
  const before = world.parliaments[world.playerNationId].politicalCapital;
  const output = advanceMonth({ previous: world, commands: [{ type: 'propose-law', lawId: 'universal-healthcare' }] });
  const law = output.next.laws['law:nation:arcadia:universal-healthcare'];
  assert.equal(law?.active, true);
  assert.ok(output.next.parliaments[world.playerNationId].politicalCapital < before);
  assert.ok(output.report.events.some((event) => event.title.includes('法案')));
});

test('scheduled elections are deterministic and preserve seat totals', () => {
  const left = createInitialWorld({ playerNationId: 'nation:arcadia', seed: 'election' });
  const right = structuredClone(left);
  left.turn = 47;
  right.turn = 47;
  left.date = { year: 2038, month: 12 };
  right.date = { year: 2038, month: 12 };
  for (const parliament of Object.values(left.parliaments)) parliament.nextElectionTurn = 48;
  for (const parliament of Object.values(right.parliaments)) parliament.nextElectionTurn = 48;
  const a = advanceMonth({ previous: left, commands: [] }).next;
  const b = advanceMonth({ previous: right, commands: [] }).next;
  assert.deepEqual(a.parties, b.parties);
  for (const nationId of Object.keys(a.nations)) {
    const seats = Object.values(a.parties).filter((party) => party.nationId === nationId).reduce((sum, party) => sum + party.seats, 0);
    assert.equal(seats, 200);
    assert.equal(a.parliaments[nationId].lastElectionTurn, 48);
  }
});
