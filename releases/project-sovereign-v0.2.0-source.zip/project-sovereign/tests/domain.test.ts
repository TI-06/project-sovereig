import test from 'node:test';
import assert from 'node:assert/strict';
import { validateCommands } from '../dist/src/domain/commands.js';
import { createInitialWorld } from '../dist/src/content/create-world.js';

test('rejects invalid tax and rate commands', () => {
  const world = createInitialWorld({ playerNationId: 'nation:arcadia', seed: 'domain' });
  const result = validateCommands([
    { type: 'set-tax-rate', tax: 'income', value: 1.2 },
    { type: 'set-policy-rate', value: -0.2 },
  ], world);
  assert.equal(result.ok, false);
  if (!result.ok) assert.equal(result.errors.length, 2);
});

test('accepts legal policy commands', () => {
  const world = createInitialWorld({ playerNationId: 'nation:arcadia', seed: 'domain' });
  const result = validateCommands([
    { type: 'set-tax-rate', tax: 'income', value: 0.24 },
    { type: 'set-budget-share', category: 'education', value: 0.065 },
  ], world);
  assert.equal(result.ok, true);
});
