import test from 'node:test';
import assert from 'node:assert/strict';
import { existsSync, readFileSync } from 'node:fs';

const read = (path: string): string => readFileSync(path, 'utf8');

test('repository includes reproducible verification and static deployment contracts', () => {
  assert.equal(existsSync('README.md'), true, 'README.md must exist');
  assert.equal(existsSync('public/_headers'), true, 'Cloudflare Pages headers must exist');
  assert.equal(existsSync('public/_redirects'), true, 'SPA fallback must exist');
  assert.equal(existsSync('.github/workflows/ci.yml'), true, 'GitHub Actions workflow must exist');
  const packageJson = JSON.parse(read('package.json'));
  assert.equal(packageJson.version, '0.2.0');

  const gitignore = read('.gitignore');
  assert.match(gitignore, /node_modules\//);
  assert.match(gitignore, /dist\//);

  const headers = read('public/_headers');
  assert.match(headers, /Content-Security-Policy/);
  assert.match(headers, /X-Content-Type-Options: nosniff/);

  const redirects = read('public/_redirects');
  assert.match(redirects, /\/index\.html\s+200/);

  const readme = read('README.md');
  assert.match(readme, /政治・議会/);
  assert.match(readme, /軍事・戦争/);
  assert.match(readme, /情報・諜報/);

  const workflow = read('.github/workflows/ci.yml');
  assert.match(workflow, /npm run verify/);
});
