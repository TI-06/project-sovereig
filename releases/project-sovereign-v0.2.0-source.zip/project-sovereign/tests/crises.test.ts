import test from 'node:test';
import assert from 'node:assert/strict';
import { createInitialWorld } from '../dist/src/content/create-world.js';
import { advanceMonth, advanceMonths } from '../dist/src/simulation/engine.js';
import { createCrisis, triggerCrises } from '../dist/src/crises/system.js';

test('crisis triggering is deterministic for the same seed and turn', () => {
  const left = createInitialWorld({ playerNationId: 'nation:arcadia', seed: 'crisis-determinism' });
  const right = structuredClone(left);
  let found = false;
  for (let turn = 1; turn <= 360 && !found; turn += 1) {
    left.turn = turn;
    right.turn = turn;
    const leftEvents = [];
    const rightEvents = [];
    triggerCrises(left, leftEvents);
    triggerCrises(right, rightEvents);
    assert.deepEqual(left.activeCrises, right.activeCrises);
    assert.deepEqual(leftEvents, rightEvents);
    found = Object.keys(left.activeCrises).length > 0;
  }
  assert.equal(found, true);
});

test('national response spends treasury and reduces crisis impact', () => {
  const world = createInitialWorld({ playerNationId: 'nation:arcadia', seed: 'crisis-response' });
  const crisis = createCrisis(world, 'nation:arcadia', 'epidemic', 0.8);
  const beforeTreasury = world.nations['nation:arcadia'].treasury;
  const beforeSeverity = crisis.severity;
  const beforeDuration = crisis.remainingMonths;
  const output = advanceMonth({ previous: world, commands: [{ type: 'respond-to-crisis', crisisId: crisis.id, response: 'emergency' }] });
  const updated = output.next.activeCrises[crisis.id];
  assert.ok(output.next.nations['nation:arcadia'].treasury < beforeTreasury);
  assert.ok(!updated || updated.severity < beforeSeverity);
  assert.ok(!updated || updated.remainingMonths < beforeDuration);
  assert.ok(output.report.events.some((event) => event.title.includes('緊急対応')));
});

test('a severe active crisis stops multi-month advancement', () => {
  const world = createInitialWorld({ playerNationId: 'nation:arcadia', seed: 'crisis-stop' });
  createCrisis(world, 'nation:arcadia', 'earthquake', 0.95);
  const result = advanceMonths(world, [], 12);
  assert.equal(result.monthsProcessed, 1);
  assert.match(result.stoppedBy ?? '', /危機|災害|地震/);
});
