import test from 'node:test';
import assert from 'node:assert/strict';
import { createInitialWorld } from '../dist/src/content/create-world.js';
import { advanceMonth, advanceMonths } from '../dist/src/simulation/engine.js';
import { assertWorldInvariants } from '../dist/src/simulation/invariants.js';

test('the same seed and command log produce byte-equivalent results', () => {
  const a = createInitialWorld({ playerNationId: 'nation:arcadia', seed: 'replay' });
  const b = createInitialWorld({ playerNationId: 'nation:arcadia', seed: 'replay' });
  const commands = [{ type: 'set-tax-rate', tax: 'income', value: 0.24 }] as const;
  const outputA = advanceMonth({ previous: a, commands: [...commands] });
  const outputB = advanceMonth({ previous: b, commands: [...commands] });
  assert.deepEqual(outputA, outputB);
});

test('policy changes are applied and explained', () => {
  const world = createInitialWorld({ playerNationId: 'nation:arcadia', seed: 'policy' });
  const output = advanceMonth({ previous: world, commands: [
    { type: 'set-tax-rate', tax: 'income', value: 0.26 },
    { type: 'set-budget-share', category: 'education', value: 0.07 },
  ] });
  const nation = output.next.nations['nation:arcadia'];
  assert.equal(nation.taxPolicy.income, 0.26);
  assert.equal(nation.budget.education, 0.07);
  assert.ok(output.report.explanations.some((item) => item.metric === 'approval'));
});

test('twelve-month advance can stop on a crisis', () => {
  const world = createInitialWorld({ playerNationId: 'nation:arcadia', seed: 'crisis' });
  world.nations['nation:arcadia']!.debt = world.nations['nation:arcadia']!.gdp * 1.8;
  const output = advanceMonths(world, [], 12);
  assert.ok(output.monthsProcessed < 12);
  assert.ok(output.stoppedBy);
});

test('1,200 turns preserve simulation invariants', () => {
  let world = createInitialWorld({ playerNationId: 'nation:arcadia', seed: 'endurance' });
  for (let i = 0; i < 1200; i += 1) {
    world = advanceMonth({ previous: world, commands: [] }).next;
    assertWorldInvariants(world);
  }
  assert.equal(world.turn, 1200);
});
