import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

test('built app exposes the playable government console', () => {
  const html = readFileSync('dist/index.html', 'utf8');
  assert.match(html, /PROJECT SOVEREIGN/);
  assert.match(html, /国家を選択/);
  assert.match(html, /src\/ui\/main\.js/);
  const script = readFileSync('dist/src/ui/main.js', 'utf8');
  assert.match(script, /政治・議会/);
  assert.match(script, /研究・公共事業/);
  assert.match(script, /国防・戦争/);
  assert.match(script, /情報・諜報/);
  assert.match(script, /危機管理/);
  assert.match(script, /国家実績/);
  assert.match(script, /data-law-action/);
  assert.match(script, /data-intel-operation/);
  const css = readFileSync('dist/styles.css', 'utf8');
  assert.match(css, /--accent/);
});
