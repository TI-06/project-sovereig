# PROJECT SOVEREIGN Foundation Vertical Slice Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a deterministic, browser-playable vertical slice with four nations, monthly turns, basic economy, companies, population, politics, diplomacy, explanations, local saves, and automated tests.

**Architecture:** Use a pnpm TypeScript monorepo. The simulation is a pure deterministic package graph executed inside a Web Worker; React only renders state and submits commands. IndexedDB persistence is isolated behind a versioned save repository.

**Tech Stack:** Node.js 24 LTS, pnpm, TypeScript strict mode, React 19.2, Vite 8.1, Tailwind CSS 4.3, Zustand, Zod, Dexie, Web Worker, Vitest, Playwright.

## Global Constraints

- PC browser first; Japanese UI only for the vertical slice.
- One turn equals one game month.
- No paid API, paid asset, or server dependency is required to play.
- The same initial state, command log, and random seed must produce the same output.
- `Math.random()` is prohibited in simulation packages.
- React components must not contain simulation formulas.
- TypeScript must use `strict: true`.
- All domain state must be serializable as JSON.
- Every task ends with tests and a commit.

---

## File Map

```text
apps/web/
├─ src/app/App.tsx                     application shell
├─ src/app/store.ts                    UI state and worker bridge state
├─ src/features/dashboard/             main national dashboard
├─ src/features/turn-controls/         month advance controls
├─ src/features/report/                monthly report and explanations
├─ src/features/policies/              policy editing UI
├─ src/worker/simulation.worker.ts     simulation worker endpoint
├─ src/worker/client.ts                typed worker client
└─ e2e/game-flow.spec.ts               browser acceptance test

packages/domain/src/                   IDs, state, commands, reports
packages/simulation-core/src/          deterministic engine and pipeline
packages/economy/src/                  budget, production, market, indicators
packages/companies/src/                company decisions and accounting
packages/population/src/               cohorts, employment, happiness
packages/politics/src/                 support and government stability
packages/diplomacy/src/                relations and basic nation AI
packages/content/src/                  four-nation seed content
packages/save-schema/src/              validation, checksum, migration
packages/test-fixtures/src/             reusable deterministic fixtures
```

---

### Task 1: Monorepo and Quality Gate

**Files:**
- Create: `package.json`
- Create: `pnpm-workspace.yaml`
- Create: `tsconfig.base.json`
- Create: `eslint.config.js`
- Create: `.prettierrc.json`
- Create: `.gitignore`
- Create: `vitest.workspace.ts`
- Create: `.github/workflows/ci.yml`
- Test: `tooling/tests/repository.test.ts`

**Interfaces:**
- Consumes: none
- Produces: workspace commands `pnpm lint`, `pnpm typecheck`, `pnpm test`, `pnpm build`

- [ ] **Step 1: Write the repository contract test**

```ts
// tooling/tests/repository.test.ts
import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';

const readJson = (path: string) => JSON.parse(readFileSync(path, 'utf8'));

describe('repository contract', () => {
  it('enables strict TypeScript and exposes quality commands', () => {
    const tsconfig = readJson('tsconfig.base.json');
    const pkg = readJson('package.json');
    expect(tsconfig.compilerOptions.strict).toBe(true);
    expect(pkg.scripts).toMatchObject({
      lint: expect.any(String),
      typecheck: expect.any(String),
      test: expect.any(String),
      build: expect.any(String),
    });
  });
});
```

- [ ] **Step 2: Run the test and verify failure**

Run: `pnpm vitest run tooling/tests/repository.test.ts`
Expected: FAIL because root configuration files do not exist.

- [ ] **Step 3: Create the root workspace files**

```json
// package.json
{
  "name": "project-sovereign",
  "private": true,
  "packageManager": "pnpm@10.15.1",
  "scripts": {
    "dev": "pnpm --filter @sovereign/web dev",
    "build": "pnpm -r build",
    "lint": "eslint .",
    "typecheck": "pnpm -r typecheck",
    "test": "vitest run --workspace vitest.workspace.ts",
    "test:watch": "vitest --workspace vitest.workspace.ts",
    "test:e2e": "pnpm --filter @sovereign/web test:e2e"
  },
  "devDependencies": {
    "@eslint/js": "10.7.0",
    "eslint": "10.7.0",
    "prettier": "3.9.6",
    "typescript": "7.0.2",
    "typescript-eslint": "8.65.0",
    "vitest": "4.1.10"
  }
}
```

```yaml
# pnpm-workspace.yaml
packages:
  - apps/*
  - packages/*
  - tooling
```

```json
// tsconfig.base.json
{
  "compilerOptions": {
    "target": "ES2023",
    "lib": ["ES2023", "DOM", "WebWorker"],
    "module": "ESNext",
    "moduleResolution": "Bundler",
    "strict": true,
    "noUncheckedIndexedAccess": true,
    "exactOptionalPropertyTypes": true,
    "verbatimModuleSyntax": true,
    "isolatedModules": true,
    "skipLibCheck": true,
    "resolveJsonModule": true
  }
}
```

- [ ] **Step 4: Install dependencies and run all quality commands**

Run: `corepack enable && pnpm install && pnpm test && pnpm typecheck && pnpm lint`
Expected: repository contract PASS; no type or lint errors.

- [ ] **Step 5: Commit**

```bash
git add package.json pnpm-workspace.yaml tsconfig.base.json eslint.config.js .prettierrc.json .gitignore vitest.workspace.ts .github tooling
git commit -m "chore: initialize sovereign monorepo quality gates"
```

---

### Task 2: Domain Types and Command Validation

**Files:**
- Create: `packages/domain/package.json`
- Create: `packages/domain/tsconfig.json`
- Create: `packages/domain/src/ids.ts`
- Create: `packages/domain/src/state.ts`
- Create: `packages/domain/src/commands.ts`
- Create: `packages/domain/src/report.ts`
- Create: `packages/domain/src/index.ts`
- Test: `packages/domain/src/commands.test.ts`

**Interfaces:**
- Consumes: root TypeScript config
- Produces: `WorldState`, `NationState`, `PlayerCommand`, `MonthlyReport`, `validateCommands(commands, state)`

- [ ] **Step 1: Write failing command validation tests**

```ts
import { describe, expect, it } from 'vitest';
import { validateCommands } from './commands';
import type { WorldState } from './state';

const state = {
  turn: 0,
  date: { year: 2035, month: 1 },
  playerNationId: 'nation:a',
  nations: {
    'nation:a': {
      id: 'nation:a',
      name: 'アルカディア共和国',
      treasury: 1000,
      debt: 500,
      taxPolicy: { income: 0.2, corporate: 0.25, consumption: 0.1 },
      policyRate: 0.02,
    },
  },
} as unknown as WorldState;

describe('validateCommands', () => {
  it('rejects tax rates outside zero to one', () => {
    const result = validateCommands([
      { type: 'set-tax-rate', tax: 'income', value: 1.2 },
    ], state);
    expect(result.ok).toBe(false);
  });

  it('accepts a legal rate for the player nation', () => {
    const result = validateCommands([
      { type: 'set-tax-rate', tax: 'income', value: 0.24 },
    ], state);
    expect(result).toEqual({ ok: true, commands: expect.any(Array) });
  });
});
```

- [ ] **Step 2: Run test and verify failure**

Run: `pnpm --filter @sovereign/domain test`
Expected: FAIL because the domain package and validator do not exist.

- [ ] **Step 3: Implement branded IDs, serializable state, commands, and validation**

```ts
// packages/domain/src/commands.ts
import type { WorldState } from './state';

export type TaxKind = 'income' | 'corporate' | 'consumption';

export type PlayerCommand =
  | { type: 'set-tax-rate'; tax: TaxKind; value: number }
  | { type: 'set-policy-rate'; value: number }
  | { type: 'set-budget-share'; category: 'education' | 'healthcare' | 'industry'; value: number }
  | { type: 'propose-trade-agreement'; targetNationId: string };

export type ValidationResult =
  | { ok: true; commands: PlayerCommand[] }
  | { ok: false; errors: Array<{ index: number; message: string }> };

export function validateCommands(commands: PlayerCommand[], state: WorldState): ValidationResult {
  const errors: Array<{ index: number; message: string }> = [];
  commands.forEach((command, index) => {
    if (command.type === 'set-tax-rate' && (command.value < 0 || command.value > 1)) {
      errors.push({ index, message: '税率は0%以上1以下で指定してください。' });
    }
    if (command.type === 'set-policy-rate' && (command.value < -0.05 || command.value > 0.5)) {
      errors.push({ index, message: '政策金利は-5%以上50%以下で指定してください。' });
    }
  });
  return errors.length === 0 ? { ok: true, commands } : { ok: false, errors };
}
```

- [ ] **Step 4: Run domain tests and typecheck**

Run: `pnpm --filter @sovereign/domain test && pnpm --filter @sovereign/domain typecheck`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add packages/domain
git commit -m "feat: define sovereign domain state and commands"
```

---

### Task 3: Deterministic Random Generator and Monthly Pipeline

**Files:**
- Create: `packages/simulation-core/package.json`
- Create: `packages/simulation-core/src/rng.ts`
- Create: `packages/simulation-core/src/pipeline.ts`
- Create: `packages/simulation-core/src/invariants.ts`
- Create: `packages/simulation-core/src/index.ts`
- Test: `packages/simulation-core/src/rng.test.ts`
- Test: `packages/simulation-core/src/pipeline.test.ts`

**Interfaces:**
- Consumes: `WorldState`, `PlayerCommand`, `MonthlyReport`
- Produces: `SeededRng`, `deriveSeed`, `advanceMonth`, `SimulationStage`

- [ ] **Step 1: Write deterministic RNG tests**

```ts
import { describe, expect, it } from 'vitest';
import { createRng, deriveSeed } from './rng';

describe('seeded random', () => {
  it('replays the same sequence', () => {
    const a = createRng('world-1');
    const b = createRng('world-1');
    expect([a.next(), a.next(), a.next()]).toEqual([b.next(), b.next(), b.next()]);
  });

  it('derives stable entity seeds', () => {
    expect(deriveSeed('world-1', 12, 'company', 'company:1'))
      .toBe(deriveSeed('world-1', 12, 'company', 'company:1'));
  });
});
```

- [ ] **Step 2: Run and verify failure**

Run: `pnpm --filter @sovereign/simulation-core test`
Expected: FAIL because RNG exports do not exist.

- [ ] **Step 3: Implement RNG and stage pipeline**

```ts
// packages/simulation-core/src/rng.ts
function hash(text: string): number {
  let value = 2166136261;
  for (let i = 0; i < text.length; i += 1) {
    value ^= text.charCodeAt(i);
    value = Math.imul(value, 16777619);
  }
  return value >>> 0;
}

export function deriveSeed(...parts: Array<string | number>): string {
  return parts.join('|');
}

export function createRng(seed: string) {
  let state = hash(seed) || 1;
  return {
    next(): number {
      state ^= state << 13;
      state ^= state >>> 17;
      state ^= state << 5;
      return (state >>> 0) / 4294967296;
    },
  };
}
```

```ts
// packages/simulation-core/src/pipeline.ts
export interface SimulationStage {
  readonly name: string;
  run(context: SimulationContext): SimulationContext;
}

export function advanceMonth(input: SimulationInput, stages: readonly SimulationStage[]): SimulationOutput {
  const validation = validateCommands(input.commands, input.previous);
  if (!validation.ok) throw new InvalidCommandError(validation.errors);
  const initial = createContext(input);
  const completed = stages.reduce((context, stage) => stage.run(context), initial);
  assertWorldInvariants(completed.state);
  return finalizeMonth(completed);
}
```

- [ ] **Step 4: Run deterministic and pipeline tests**

Run: `pnpm --filter @sovereign/simulation-core test`
Expected: PASS and two identical runs produce byte-equivalent state and report.

- [ ] **Step 5: Commit**

```bash
git add packages/simulation-core
git commit -m "feat: add deterministic monthly simulation pipeline"
```

---

### Task 4: Seed World Content

**Files:**
- Create: `packages/content/package.json`
- Create: `packages/content/src/nations.ts`
- Create: `packages/content/src/regions.ts`
- Create: `packages/content/src/industries.ts`
- Create: `packages/content/src/create-world.ts`
- Create: `packages/content/src/index.ts`
- Test: `packages/content/src/create-world.test.ts`

**Interfaces:**
- Consumes: domain state types
- Produces: `createInitialWorld({ playerNationId, seed })`

- [ ] **Step 1: Write the seed world test**

```ts
import { describe, expect, it } from 'vitest';
import { createInitialWorld } from './create-world';

describe('createInitialWorld', () => {
  it('creates four nations, twelve regions, twenty-four companies and eight commodities', () => {
    const world = createInitialWorld({ playerNationId: 'nation:arcadia', seed: 'demo' });
    expect(Object.keys(world.nations)).toHaveLength(4);
    expect(Object.keys(world.regions)).toHaveLength(12);
    expect(Object.keys(world.companies)).toHaveLength(24);
    expect(Object.keys(world.commodities)).toHaveLength(8);
  });
});
```

- [ ] **Step 2: Run and verify failure**

Run: `pnpm --filter @sovereign/content test`
Expected: FAIL because world content does not exist.

- [ ] **Step 3: Implement four differentiated nations and normalized seed data**

Implement these nation archetypes exactly:

| ID | Name | Strength | Structural weakness |
|---|---|---|---|
| nation:arcadia | アルカディア共和国 | 教育・サービス | エネルギー輸入依存 |
| nation:valen | ヴァレン連邦 | 工業・資源 | 格差・地方不満 |
| nation:selene | セレネ共同体 | 金融・貿易 | 食料自給率不足 |
| nation:dorn | ドーン人民国 | 人口・国営企業 | 生産性・外交孤立 |

- [ ] **Step 4: Validate seed data and run tests**

Run: `pnpm --filter @sovereign/content test && pnpm --filter @sovereign/content typecheck`
Expected: PASS; all foreign keys resolve and all numeric values are finite.

- [ ] **Step 5: Commit**

```bash
git add packages/content
git commit -m "feat: add four-nation vertical slice world"
```

---

### Task 5: Economy Stage

**Files:**
- Create: `packages/economy/package.json`
- Create: `packages/economy/src/apply-policy.ts`
- Create: `packages/economy/src/budget.ts`
- Create: `packages/economy/src/market.ts`
- Create: `packages/economy/src/indicators.ts`
- Create: `packages/economy/src/stage.ts`
- Create: `packages/economy/src/index.ts`
- Test: `packages/economy/src/stage.test.ts`

**Interfaces:**
- Consumes: `SimulationContext`, validated tax/rate/budget commands
- Produces: `economyStage`, metric contributions for GDP, CPI, treasury, debt

- [ ] **Step 1: Write failing policy and accounting tests**

```ts
it('raises expected tax revenue after an income-tax increase without creating money', () => {
  const output = runEconomyMonth(world, [
    { type: 'set-tax-rate', tax: 'income', value: 0.24 },
  ]);
  const nation = output.state.nations['nation:arcadia'];
  expect(nation.taxPolicy.income).toBe(0.24);
  expect(nation.monthlyRevenue).toBeGreaterThan(world.nations['nation:arcadia'].monthlyRevenue);
  expect(Number.isFinite(nation.treasury)).toBe(true);
});
```

- [ ] **Step 2: Run and verify failure**

Run: `pnpm --filter @sovereign/economy test`
Expected: FAIL because the economy stage does not exist.

- [ ] **Step 3: Implement bounded fiscal, demand, market, and indicator calculations**

Use named constants for all clamps:

```ts
export const ECONOMY_LIMITS = {
  monthlyPriceChange: 0.15,
  monthlyWageChange: 0.08,
  minimumPrice: 0.01,
  maximumDebtToGdp: 20,
} as const;
```

Every aggregate update must emit a `MetricExplanation` contribution.

- [ ] **Step 4: Run tests including invariant checks**

Run: `pnpm --filter @sovereign/economy test && pnpm --filter @sovereign/simulation-core test`
Expected: PASS; prices and fiscal values remain finite and bounded.

- [ ] **Step 5: Commit**

```bash
git add packages/economy
git commit -m "feat: simulate fiscal policy markets and national indicators"
```

---

### Task 6: Company Stage

**Files:**
- Create: `packages/companies/package.json`
- Create: `packages/companies/src/forecast.ts`
- Create: `packages/companies/src/production.ts`
- Create: `packages/companies/src/employment.ts`
- Create: `packages/companies/src/accounting.ts`
- Create: `packages/companies/src/distress.ts`
- Create: `packages/companies/src/stage.ts`
- Test: `packages/companies/src/stage.test.ts`

**Interfaces:**
- Consumes: market demand, prices, rates, company state
- Produces: `companyStage`, production, employment, investment, distress events

- [ ] **Step 1: Write failing accounting and distress tests**

```ts
it('preserves the company cash-flow identity', () => {
  const result = runCompanyMonth(companyFixture());
  expect(result.closingCash).toBeCloseTo(
    result.openingCash + result.revenue + result.financing - result.operatingCosts - result.taxes - result.investment,
    8,
  );
});

it('does not bankrupt a viable company after one bad month', () => {
  const result = runCompanyMonth(companyFixture({ cash: -10, distressMonths: 0 }));
  expect(result.status).not.toBe('bankrupt');
  expect(result.distressMonths).toBe(1);
});
```

- [ ] **Step 2: Run and verify failure**

Run: `pnpm --filter @sovereign/companies test`
Expected: FAIL because company simulation does not exist.

- [ ] **Step 3: Implement the monthly company decision sequence**

Implement in this exact order: forecast, labor adjustment, input purchase, production, sales, accounting, investment, financing, distress.

- [ ] **Step 4: Run company and economy integration tests**

Run: `pnpm --filter @sovereign/companies test && pnpm test`
Expected: PASS; no company inventory or employee count becomes negative.

- [ ] **Step 5: Commit**

```bash
git add packages/companies
git commit -m "feat: simulate company production employment and distress"
```

---

### Task 7: Population and Political Support Stages

**Files:**
- Create: `packages/population/package.json`
- Create: `packages/population/src/employment.ts`
- Create: `packages/population/src/welfare.ts`
- Create: `packages/population/src/demography.ts`
- Create: `packages/population/src/stage.ts`
- Create: `packages/politics/package.json`
- Create: `packages/politics/src/support.ts`
- Create: `packages/politics/src/stability.ts`
- Create: `packages/politics/src/stage.ts`
- Test: `packages/population/src/stage.test.ts`
- Test: `packages/politics/src/stage.test.ts`

**Interfaces:**
- Consumes: jobs, wages, prices, public services, tax burden, events
- Produces: cohort income/happiness/anger; national support and stability

- [ ] **Step 1: Write failing differentiated-impact tests**

```ts
it('hurts low-income cohorts more when consumption tax rises', () => {
  const output = runPopulationAndPolitics(world, {
    consumptionTaxBefore: 0.1,
    consumptionTaxAfter: 0.15,
  });
  const low = output.cohorts.find((c) => c.incomeBand === 'low')!;
  const high = output.cohorts.find((c) => c.incomeBand === 'high')!;
  expect(low.happinessDelta).toBeLessThan(high.happinessDelta);
});
```

- [ ] **Step 2: Run and verify failure**

Run: `pnpm --filter @sovereign/population test && pnpm --filter @sovereign/politics test`
Expected: FAIL because stages do not exist.

- [ ] **Step 3: Implement cohort welfare and support models**

Support must combine living standards, employment, ideological fit, promise delivery, crisis handling, corruption, inequality, and policy fatigue. Clamp every score to 0..100.

- [ ] **Step 4: Run integration and conservation tests**

Run: `pnpm test`
Expected: PASS; population is conserved except explicit birth, death, and migration events.

- [ ] **Step 5: Commit**

```bash
git add packages/population packages/politics
git commit -m "feat: model population welfare and political support"
```

---

### Task 8: Diplomacy and Basic Nation AI

**Files:**
- Create: `packages/diplomacy/package.json`
- Create: `packages/diplomacy/src/relations.ts`
- Create: `packages/diplomacy/src/actions.ts`
- Create: `packages/diplomacy/src/ai/candidates.ts`
- Create: `packages/diplomacy/src/ai/score.ts`
- Create: `packages/diplomacy/src/stage.ts`
- Test: `packages/diplomacy/src/ai/score.test.ts`
- Test: `packages/diplomacy/src/stage.test.ts`

**Interfaces:**
- Consumes: nation strategy, fiscal state, trade dependence, bilateral relations
- Produces: AI commands, relation changes, trade-agreement events

- [ ] **Step 1: Write failing AI preference tests**

```ts
it('makes a trade-focused nation prefer a beneficial agreement over sanctions', () => {
  const actions = scoreCandidates(tradeNationContext());
  expect(actions[0]?.type).toBe('propose-trade-agreement');
});

it('penalizes actions the nation cannot finance', () => {
  const scored = scoreCandidate(aidAction(), poorNationContext());
  expect(scored.components.fiscalFeasibility).toBeLessThan(0);
});
```

- [ ] **Step 2: Run and verify failure**

Run: `pnpm --filter @sovereign/diplomacy test`
Expected: FAIL because candidate generation and scoring do not exist.

- [ ] **Step 3: Implement explainable candidate scoring**

```ts
export interface ActionScore {
  action: AiDiplomaticAction;
  total: number;
  components: {
    goalAlignment: number;
    economicBenefit: number;
    securityBenefit: number;
    domesticSupport: number;
    fiscalFeasibility: number;
    retaliationRisk: number;
  };
}
```

Tie-breaking must use the deterministic RNG derived from nation ID and turn.

- [ ] **Step 4: Run diplomacy and full-pipeline tests**

Run: `pnpm test`
Expected: PASS; identical seeds choose identical AI actions.

- [ ] **Step 5: Commit**

```bash
git add packages/diplomacy
git commit -m "feat: add explainable diplomacy and nation ai"
```

---

### Task 9: Explanation Aggregator and Monthly Report

**Files:**
- Create: `packages/simulation-core/src/explanations.ts`
- Create: `packages/simulation-core/src/report.ts`
- Test: `packages/simulation-core/src/report.test.ts`

**Interfaces:**
- Consumes: stage contributions and domain events
- Produces: `buildMonthlyReport(context): MonthlyReport`

- [ ] **Step 1: Write failing explanation aggregation tests**

```ts
it('returns the five largest causes and groups the remainder', () => {
  const result = aggregateContributions([
    { source: 'a', amount: 10 },
    { source: 'b', amount: -9 },
    { source: 'c', amount: 8 },
    { source: 'd', amount: 7 },
    { source: 'e', amount: 6 },
    { source: 'f', amount: 5 },
  ]);
  expect(result).toHaveLength(6);
  expect(result.at(-1)?.source).toBe('other');
});
```

- [ ] **Step 2: Run and verify failure**

Run: `pnpm --filter @sovereign/simulation-core test`
Expected: FAIL because aggregation does not exist.

- [ ] **Step 3: Implement stable sorting and report construction**

Sort by absolute contribution descending, then source ID ascending to guarantee deterministic output.

- [ ] **Step 4: Run report snapshot and replay tests**

Run: `pnpm --filter @sovereign/simulation-core test`
Expected: PASS; report snapshots are identical across replay.

- [ ] **Step 5: Commit**

```bash
git add packages/simulation-core
git commit -m "feat: explain monthly metric changes"
```

---

### Task 10: Versioned Local Save Repository

**Files:**
- Create: `packages/save-schema/package.json`
- Create: `packages/save-schema/src/schema.ts`
- Create: `packages/save-schema/src/checksum.ts`
- Create: `packages/save-schema/src/migrations.ts`
- Create: `packages/save-schema/src/repository.ts`
- Create: `packages/save-schema/src/index.ts`
- Test: `packages/save-schema/src/repository.test.ts`
- Test: `packages/save-schema/src/migrations.test.ts`

**Interfaces:**
- Consumes: serializable `WorldState`, command log, RNG state
- Produces: `SaveRepository`, `createSaveEnvelope`, `loadNewestValidSave`

- [ ] **Step 1: Write failing corruption-recovery test**

```ts
it('loads the previous generation when the newest checksum is invalid', async () => {
  const repository = createMemorySaveRepository();
  await repository.write(validEnvelope({ updatedAt: '2035-01-01T00:00:00Z' }));
  await repository.write(corruptEnvelope({ updatedAt: '2035-01-02T00:00:00Z' }));
  const loaded = await repository.loadNewestValid('slot-1');
  expect(loaded?.updatedAt).toBe('2035-01-01T00:00:00Z');
});
```

- [ ] **Step 2: Run and verify failure**

Run: `pnpm --filter @sovereign/save-schema test`
Expected: FAIL because save repository does not exist.

- [ ] **Step 3: Implement Zod validation, SHA-256 checksum, migrations, and ten-generation retention**

Browser checksum must use `crypto.subtle.digest('SHA-256', bytes)`. Tests may use the Node Web Crypto implementation.

- [ ] **Step 4: Run save tests**

Run: `pnpm --filter @sovereign/save-schema test`
Expected: PASS for round-trip, corruption fallback, and v1-to-v2 migration.

- [ ] **Step 5: Commit**

```bash
git add packages/save-schema
git commit -m "feat: add versioned resilient local saves"
```

---

### Task 11: Worker API and React Application Shell

**Files:**
- Create: `apps/web/package.json`
- Create: `apps/web/vite.config.ts`
- Create: `apps/web/index.html`
- Create: `apps/web/src/main.tsx`
- Create: `apps/web/src/app/App.tsx`
- Create: `apps/web/src/app/store.ts`
- Create: `apps/web/src/worker/protocol.ts`
- Create: `apps/web/src/worker/simulation.worker.ts`
- Create: `apps/web/src/worker/client.ts`
- Test: `apps/web/src/worker/client.test.ts`

**Interfaces:**
- Consumes: `createInitialWorld`, `advanceMonth`, `SaveRepository`
- Produces: typed messages `new-game`, `advance`, `save`, `load`; React application state

- [ ] **Step 1: Write failing worker protocol test**

```ts
it('returns a monthly result for a valid advance request', async () => {
  const worker = createInProcessWorkerHarness();
  const created = await worker.request({ type: 'new-game', playerNationId: 'nation:arcadia', seed: 'demo' });
  const advanced = await worker.request({ type: 'advance', gameId: created.gameId, months: 1, commands: [] });
  expect(advanced.type).toBe('advance-complete');
  expect(advanced.world.turn).toBe(1);
});
```

- [ ] **Step 2: Run and verify failure**

Run: `pnpm --filter @sovereign/web test`
Expected: FAIL because the worker protocol does not exist.

- [ ] **Step 3: Implement a discriminated-union protocol and worker client**

Every request includes `requestId`; every response echoes it. Worker errors return `{ type: 'error', requestId, code, message }` and never leak raw stack traces to UI.

- [ ] **Step 4: Run worker tests and production build**

Run: `pnpm --filter @sovereign/web test && pnpm --filter @sovereign/web build`
Expected: PASS; Vite emits separate worker and app bundles.

- [ ] **Step 5: Commit**

```bash
git add apps/web
git commit -m "feat: connect react shell to simulation worker"
```

---

### Task 12: Playable Dashboard, Policies, Turn Controls, and Report

**Files:**
- Create: `apps/web/src/features/dashboard/DashboardPage.tsx`
- Create: `apps/web/src/features/dashboard/MetricCard.tsx`
- Create: `apps/web/src/features/policies/PolicyPanel.tsx`
- Create: `apps/web/src/features/turn-controls/TurnControls.tsx`
- Create: `apps/web/src/features/report/MonthlyReportPanel.tsx`
- Create: `apps/web/src/features/report/ExplanationList.tsx`
- Create: `apps/web/src/styles.css`
- Test: `apps/web/src/features/turn-controls/TurnControls.test.tsx`
- Test: `apps/web/src/features/policies/PolicyPanel.test.tsx`

**Interfaces:**
- Consumes: application store and worker client
- Produces: playable dashboard for policy edits and 1/3/6/12 month advancement

- [ ] **Step 1: Write failing interaction tests**

```tsx
it('queues a tax command and advances one month', async () => {
  render(<App />);
  await userEvent.selectOptions(screen.getByLabelText('所得税率'), '0.24');
  await userEvent.click(screen.getByRole('button', { name: '1か月進める' }));
  expect(await screen.findByText('2035年2月')).toBeInTheDocument();
  expect(screen.getByText(/所得税率の変更/)).toBeInTheDocument();
});
```

- [ ] **Step 2: Run and verify failure**

Run: `pnpm --filter @sovereign/web test`
Expected: FAIL because feature components do not exist.

- [ ] **Step 3: Implement the dashboard**

Display exactly these primary metrics: GDP, GDP growth, CPI inflation, unemployment, treasury, debt/GDP, support, stability, trade balance, exchange rate. Policy controls: income tax, corporate tax, consumption tax, policy rate, education, healthcare, industrial subsidy.

- [ ] **Step 4: Run component tests and accessibility checks**

Run: `pnpm --filter @sovereign/web test && pnpm --filter @sovereign/web build`
Expected: PASS; all controls have visible labels and keyboard focus.

- [ ] **Step 5: Commit**

```bash
git add apps/web/src
git commit -m "feat: deliver playable national dashboard"
```

---

### Task 13: Multi-Month Advance and Crisis Auto-Stop

**Files:**
- Create: `packages/simulation-core/src/advance-many.ts`
- Create: `packages/simulation-core/src/alerts.ts`
- Modify: `apps/web/src/worker/simulation.worker.ts`
- Modify: `apps/web/src/features/turn-controls/TurnControls.tsx`
- Test: `packages/simulation-core/src/advance-many.test.ts`

**Interfaces:**
- Consumes: `advanceMonth`, alert rules
- Produces: `advanceMonths(input, count, stopRules)` with partial completion result

- [ ] **Step 1: Write failing auto-stop test**

```ts
it('stops a twelve-month run when inflation jumps by two points', () => {
  const result = advanceMonths(crisisFixture(), 12, defaultStopRules);
  expect(result.completedMonths).toBeLessThan(12);
  expect(result.stopReason?.code).toBe('inflation-shock');
});
```

- [ ] **Step 2: Run and verify failure**

Run: `pnpm --filter @sovereign/simulation-core test`
Expected: FAIL because multi-month advancement does not exist.

- [ ] **Step 3: Implement one-month iteration with checks after every report**

Never skip intermediate months. Return all monthly summaries but retain full state only for the last completed month.

- [ ] **Step 4: Run simulation and UI tests**

Run: `pnpm test`
Expected: PASS; UI displays the exact month and reason where advancement stopped.

- [ ] **Step 5: Commit**

```bash
git add packages/simulation-core apps/web
git commit -m "feat: add safe multi-month advancement"
```

---

### Task 14: Long-Run Simulation Harness

**Files:**
- Create: `tooling/package.json`
- Create: `tooling/src/run-long-simulation.ts`
- Create: `tooling/src/write-balance-csv.ts`
- Test: `tooling/src/run-long-simulation.test.ts`

**Interfaces:**
- Consumes: seed world, full pipeline, deterministic AI
- Produces: CLI `pnpm balance --turns 1200 --seeds 100 --out artifacts/balance.csv`

- [ ] **Step 1: Write failing 1,200-turn test**

```ts
it('runs 1,200 turns without violating invariants', () => {
  const result = runLongSimulation({ turns: 1200, seed: 'long-run-1' });
  expect(result.completedTurns).toBe(1200);
  expect(result.invariantFailures).toEqual([]);
});
```

- [ ] **Step 2: Run and verify failure**

Run: `pnpm --filter @sovereign/tooling test`
Expected: FAIL because the harness does not exist.

- [ ] **Step 3: Implement CLI and aggregate statistics**

Output per seed: final GDP, inflation, unemployment, debt/GDP, support, bankruptcies, trade agreements, crisis stops, and runtime milliseconds.

- [ ] **Step 4: Run 1,200-turn and 100-seed smoke tests**

Run: `pnpm balance --turns 1200 --seeds 10 --out artifacts/balance-smoke.csv`
Expected: exit code 0, no invariant failures, CSV exists.

- [ ] **Step 5: Commit**

```bash
git add tooling artifacts/.gitkeep
git commit -m "test: add deterministic long-run balance harness"
```

---

### Task 15: End-to-End Acceptance and Static Deployment

**Files:**
- Create: `apps/web/playwright.config.ts`
- Create: `apps/web/e2e/game-flow.spec.ts`
- Create: `apps/web/public/_headers`
- Create: `docs/deployment.md`
- Modify: `.github/workflows/ci.yml`

**Interfaces:**
- Consumes: built web application
- Produces: verified static artifact `apps/web/dist`

- [ ] **Step 1: Write the end-to-end acceptance test**

```ts
import { expect, test } from '@playwright/test';

test('starts a nation, changes policy, advances, saves and reloads', async ({ page }) => {
  await page.goto('/');
  await page.getByRole('button', { name: 'アルカディア共和国で開始' }).click();
  await page.getByLabel('所得税率').selectOption('0.24');
  await page.getByRole('button', { name: '1か月進める' }).click();
  await expect(page.getByText('2035年2月')).toBeVisible();
  await page.getByRole('button', { name: '保存' }).click();
  await page.reload();
  await page.getByRole('button', { name: '続きから' }).click();
  await expect(page.getByText('2035年2月')).toBeVisible();
});
```

- [ ] **Step 2: Run and verify failure**

Run: `pnpm --filter @sovereign/web test:e2e`
Expected: FAIL until the complete vertical slice is wired.

- [ ] **Step 3: Complete missing UI wiring and static-host headers**

Set security headers for static hosting: CSP without remote script execution, `X-Content-Type-Options: nosniff`, `Referrer-Policy: strict-origin-when-cross-origin`, and deny framing.

- [ ] **Step 4: Run the complete release gate**

Run: `pnpm lint && pnpm typecheck && pnpm test && pnpm build && pnpm test:e2e`
Expected: all commands exit 0.

- [ ] **Step 5: Commit**

```bash
git add apps/web .github docs/deployment.md
git commit -m "release: complete sovereign vertical slice acceptance"
```

---

## Plan Self-Review

### Spec coverage

- Deterministic monthly progression: Tasks 2–3
- Four-nation playable content: Task 4
- Economy, companies, population, politics, diplomacy: Tasks 5–8
- Explainable metric changes: Task 9
- Local save and recovery: Task 10
- Browser worker and UI: Tasks 11–12
- Multi-month progression and crisis stopping: Task 13
- Long-run testing: Task 14
- Public static artifact: Task 15

### Deferred to dedicated follow-up plans

These are part of the approved final scope but intentionally excluded from the first vertical slice:

1. Full 24-commodity supply chain and logistics network
2. Banking, securities, mergers, nationalization, corruption, lobbying
3. Full demographic aging, migration, religion, culture, crime, healthcare
4. Elections, parliament, legislation, constitutions, courts, bureaucracy
5. International organizations, sanctions networks, espionage
6. Military units, logistics, fronts, occupation, peace negotiations
7. Research trees, education institutions, disasters, epidemics
8. Full map, tutorial, achievements, cloud save, localization

Each deferred group receives its own spec and implementation plan after the vertical slice passes its acceptance gate.
