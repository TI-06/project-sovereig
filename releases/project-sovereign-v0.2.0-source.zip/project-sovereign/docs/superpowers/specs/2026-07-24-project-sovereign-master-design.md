# PROJECT SOVEREIGN 詳細設計書

- 作成日: 2026-07-24
- 対象: PCブラウザ向け高難度国家運営シミュレーション
- 公開方針: 基本無料、初期は有料API・有料素材を使わない
- 時間進行: 1ターン = 1か月
- 優先順位: 経済 > 政治 > 外交 > 企業 > 国民

## 1. 目的

PROJECT SOVEREIGNは、国家の経済、政治、外交、企業、国民が相互に影響し、単独の最適解ではなく複数のトレードオフを管理する国家運営ゲームである。

プレイヤーは一人の元首ではなく「国家運営主体」として、政権交代後も継続して国家を運営する。戦争や征服だけを勝利条件とせず、国家存続、経済力、国民生活、外交的影響力、技術力、制度的安定性など複数の国家目標を選択できる。

## 2. 成功条件

### 2.1 プレイ体験

1. 1ターンの判断に明確な意味がある。
2. 数値が変化した理由をプレイヤーが追跡できる。
3. どの政策にも短期的利益と中長期的副作用がある。
4. 平時は複数月を高速に進め、危機時は1か月単位で介入できる。
5. 30年以上プレイしても経済・政治・外交が固定化しない。
6. 敗北しても、国家が存続する限り政権交代後の運営を継続できる。

### 2.2 品質

- 同じ初期状態、命令履歴、乱数シードから同じ結果を再現できる。
- 1,200ターンの自動シミュレーションでNaN、無限値、負人口、負在庫を発生させない。
- 主要指標の変化理由を最大5件まで表示できる。
- 一般的なPCで1ターン処理を300ms以内、12か月高速進行を3秒以内の目標とする。
- セーブデータ破損時に直前の世代へ復旧できる。

## 3. スコープ分割

完成形は以下の独立サブシステムに分割する。各サブシステムは別計画で実装し、単独でテスト可能にする。

| フェーズ | サブシステム | 完成時の状態 |
|---:|---|---|
| 0 | 基盤・縦切り版 | 4国家、12地域で月次進行できるプレイ可能版 |
| 1 | 経済・産業・物流 | 商品市場、生産、在庫、輸送、価格形成 |
| 2 | 企業・金融 | 個別企業、投資、雇用、融資、倒産、国有化 |
| 3 | 国民・人口・社会 | 人口構成、所得層、教育、移民、幸福、不満 |
| 4 | 政治・制度 | 政党、選挙、議会、法律、官僚、司法、汚職 |
| 5 | 外交・国際AI | 条約、制裁、貿易交渉、国際機関、国家AI |
| 6 | 軍事・戦争 | 部隊、兵站、戦線、占領、講和、戦争疲弊 |
| 7 | 研究・諜報・危機 | 技術、教育、諜報、サイバー、災害、疫病 |
| 8 | UX・運用・公開 | チュートリアル、実績、クラウドセーブ、公開 |

## 4. ゲームループ

### 4.1 月次進行

1. 前月結果の確認
2. 政策・予算・税率・金利の変更
3. 法案・人事・外交・産業命令の入力
4. ターン確定
5. 命令検証
6. 国内経済処理
7. 企業活動処理
8. 国民・人口処理
9. 政治処理
10. 外交・国家AI処理
11. 軍事・危機処理
12. 指標集計、因果関係記録
13. 月次報告生成
14. 自動保存

### 4.2 高速進行

- 1、3、6、12か月を選択可能。
- 警戒条件に一致した場合は途中停止する。
- 初期停止条件:
  - 財政破綻リスクが閾値超過
  - インフレ率が前月比2ポイント以上悪化
  - 支持率が5ポイント以上低下
  - 主要企業が倒産
  - 戦争・制裁・政変・大災害が発生
  - 重要法案が否決

## 5. 世界モデル

### 5.1 完成形

- 36国家
- 約144地域
- 約100主要都市
- 約20海域
- 約24商品・サービス
- 150〜300企業
- 主要人物100〜250名

### 5.2 縦切り版

- 4国家
- 12地域
- 8商品
- 24企業
- 4政党/国家
- 主要人物3名/国家

### 5.3 地域

```ts
export interface RegionState {
  id: RegionId;
  ownerNationId: NationId;
  name: string;
  population: number;
  urbanization: number;
  infrastructure: number;
  education: number;
  healthcare: number;
  stability: number;
  resourceDeposits: Partial<Record<CommodityId, number>>;
  transportCapacity: number;
  disasterRisk: number;
}
```

## 6. シミュレーション共通設計

### 6.1 不変性

各月の処理は前月状態を直接書き換えず、命令と乱数を入力して新しい状態を返す。

```ts
export interface SimulationInput {
  previous: WorldState;
  commands: PlayerCommand[];
  rngSeed: string;
}

export interface SimulationOutput {
  next: WorldState;
  report: MonthlyReport;
  events: DomainEvent[];
}

export function advanceMonth(input: SimulationInput): SimulationOutput;
```

### 6.2 処理順序

処理順序は固定し、モジュール間の循環依存を禁止する。

```text
commands
  -> budget-and-tax
  -> production
  -> market-clearing
  -> companies
  -> population
  -> politics
  -> diplomacy
  -> crises
  -> aggregation
  -> explanations
```

### 6.3 決定論的乱数

- `Math.random()`は禁止。
- 乱数はシード付き生成器のみ使用する。
- イベントごとに `worldSeed + turn + eventNamespace + entityId` から派生シードを生成する。
- UIや描画はシミュレーション乱数を消費しない。

## 7. 経済設計

### 7.1 主要指標

- 名目GDP、実質GDP
- GDP成長率
- 消費者物価指数、インフレ率
- 政策金利、市中金利
- 為替レート
- 失業率、労働参加率
- 平均賃金、可処分所得、所得格差
- 税収、政府支出、基礎的財政収支
- 国債残高、利払い、信用格付け
- 貿易収支、経常収支、外貨準備
- 消費者信頼感、企業景況感

### 7.2 財政

```text
税収 = 所得税 + 法人税 + 消費税 + 関税 + 資源税 + その他
歳出 = 行政 + 教育 + 医療 + 福祉 + 防衛 + インフラ + 補助金 + 国債利払い
財政収支 = 税収 - 歳出
債務残高(t+1) = 債務残高(t) - 財政収支
```

税率を変えた月に税収が完全反映されるのではなく、徴税効率、景気、脱税、行政能力を通じて段階的に反映する。

### 7.3 需要

家計需要は所得、物価、信頼感、金利、人口構成から算出する。

```text
実質消費余力 = 可処分所得 / 物価指数
商品需要 = 基礎需要 × 人口 × 所得弾力性 × 価格弾力性 × 信頼感補正
```

### 7.4 供給・価格

```text
生産可能量 = min(設備能力, 労働制約, 原料制約, 電力制約, 物流制約)
需給率 = 需要 / max(供給 + 在庫放出, epsilon)
価格変化率 = clamp((需給率 - 1) × 調整速度 + 輸入価格影響, -上限, 上限)
```

急激な発散を避けるため、価格変化には商品別の上限を設定する。

### 7.5 縦切り版の商品

- 食料
- エネルギー
- 鉄鋼
- 機械
- 生活用品
- 医薬品
- 輸送サービス
- 金融サービス

## 8. 企業設計

### 8.1 企業状態

```ts
export interface CompanyState {
  id: CompanyId;
  nationId: NationId;
  regionId: RegionId;
  name: string;
  industryId: IndustryId;
  ownership: 'private' | 'state' | 'foreign' | 'mixed';
  cash: number;
  debt: number;
  capitalStock: number;
  employees: number;
  wageOffer: number;
  productivity: number;
  capacityUtilization: number;
  inventory: Partial<Record<CommodityId, number>>;
  reputation: number;
  politicalInfluence: number;
  distressMonths: number;
}
```

### 8.2 月次行動

1. 需要予測
2. 生産計画
3. 採用・解雇
4. 原料購入
5. 生産
6. 販売・輸出
7. 賃金・利息・税金支払い
8. 設備投資判断
9. 配当・内部留保
10. 資金繰り判定
11. 救済・倒産・買収判定

### 8.3 倒産

- 現金不足だけでは即倒産させない。
- 銀行融資、増資、政府救済、資産売却を順に判定する。
- `distressMonths >= 3` かつ債務超過、資金調達不能で倒産する。
- 倒産時は失業、供給減、債権損失、政権支持への影響を発生させる。

## 9. 国民・人口設計

### 9.1 コホート方式

個人単位ではなく、地域・年齢・所得・職業・教育・文化の組合せで人口集団を保持する。

```ts
export interface PopulationCohort {
  regionId: RegionId;
  ageBand: 'child' | 'young' | 'working' | 'senior';
  incomeBand: 'low' | 'middle' | 'high';
  employment: EmploymentType;
  education: 'basic' | 'secondary' | 'higher' | 'specialist';
  cultureId: string;
  size: number;
  disposableIncome: number;
  happiness: number;
  anger: number;
  politicalInterest: number;
  ideology: IdeologyVector;
}
```

### 9.2 変化要因

- 出生、死亡、加齢
- 国内移動、移民、難民
- 教育水準
- 雇用、賃金、物価
- 住宅、医療、治安
- 戦争、災害、差別
- 税と社会保障

### 9.3 支持率

支持率は単純なGDP連動にしない。

```text
支持変化 =
  生活実感
  + 雇用安定
  + 公約達成
  + 政策との思想的一致
  + 危機対応評価
  - 汚職
  - 不平等感
  - 政策変更疲れ
```

## 10. 政治設計

### 10.1 国家制度

- 政体
- 選挙制度
- 議院構成
- 大統領/首相権限
- 司法独立度
- 報道自由度
- 地方自治度
- 官僚能力
- 汚職耐性

### 10.2 政策実行制約

プレイヤーは以下を消費する。

- 行政力: 省庁が処理できる変更量
- 政治資本: 反対を押し切る力
- 議会時間: 法案審議枠
- 予算余力: 実施財源
- 官僚適合度: 制度と行政能力の整合性

### 10.3 法案

```ts
export interface Bill {
  id: BillId;
  title: string;
  policyChanges: PolicyPatch[];
  proposerPartyId: PartyId;
  requiredMajority: number;
  debateMonths: number;
  lobbyingPressure: number;
  publicSupport: number;
  status: 'draft' | 'committee' | 'vote' | 'passed' | 'rejected' | 'enacted';
}
```

### 10.4 選挙

- 政党支持
- 候補者人気
- 景気評価
- 地域別争点
- メディア影響
- 投票率
- 選挙制度

を用いて地域別に議席を配分する。

## 11. 外交設計

### 11.1 二国間関係

```ts
export interface BilateralRelation {
  fromNationId: NationId;
  toNationId: NationId;
  trust: number;
  threat: number;
  dependence: number;
  affinity: number;
  grievance: number;
  influence: number;
  treaties: TreatyId[];
  sanctions: SanctionId[];
}
```

### 11.2 外交行動

- 貿易協定
- 関税交渉
- 資源長期契約
- 投資協定
- 技術協定
- 不可侵条約
- 防衛協定
- 経済制裁
- 援助
- 債務再編
- 国際機関投票

### 11.3 国家AI

AIは効用関数の単純最大化だけでなく、国家目標と許容リスクを持つ。

```ts
export interface NationStrategy {
  primaryGoal: 'growth' | 'security' | 'influence' | 'welfare' | 'ideology';
  riskTolerance: number;
  planningHorizonMonths: number;
  preferredPartners: NationId[];
  rivals: NationId[];
  policyWeights: Record<string, number>;
}
```

AIは候補行動を生成し、期待利益、財政費用、国内支持、外交報復、長期目標との整合性で採点する。

## 12. 因果関係・説明システム

すべての主要指標は値だけでなく寄与要因を保持する。

```ts
export interface MetricExplanation {
  metric: MetricId;
  previousValue: number;
  currentValue: number;
  contributions: Array<{
    source: string;
    amount: number;
    descriptionKey: string;
    entityId?: string;
  }>;
}
```

表示時は絶対寄与の大きい順に最大5件を表示し、残りは「その他」に集約する。

## 13. イベントシステム

### 13.1 種類

- 条件発火型
- 確率発火型
- 連鎖型
- プレイヤー選択型
- 世界共通型
- 国家固有型

### 13.2 データ駆動

イベント本文、条件、選択肢、効果はJSONデータとして管理し、コード変更なしで追加できるようにする。

```ts
export interface EventDefinition {
  id: string;
  trigger: ConditionExpression;
  cooldownMonths: number;
  weight: number;
  choices: Array<{
    id: string;
    labelKey: string;
    requirements: ConditionExpression;
    effects: EffectExpression[];
  }>;
}
```

## 14. UI設計

### 14.1 デザイン方針

- 政府統合管理システムと作戦司令室の中間
- 派手な3Dより、情報密度と可読性を優先
- 重要警告は色だけに依存せずアイコンと文言を併用
- 主要画面は1920×1080で縦スクロールを最小化
- 1366×768でも主要操作を可能にする

### 14.2 主要画面

1. 国家ダッシュボード
2. 世界地図
3. 月次報告
4. 経済省
5. 財務省
6. 中央銀行
7. 産業・企業
8. 国民・社会
9. 国会・政党
10. 外務省
11. 国防省
12. 情報局
13. 研究・教育
14. 国家記録
15. 設定・セーブ

### 14.3 ダッシュボード

- 上部: 年月、ターン進行、速度、警戒状態
- 左: 国家主要指標
- 中央: 重要ニュース、政策課題、世界地図概要
- 右: 警告、期限、法案、外交提案
- 下部: 指標推移、最近の因果関係

## 15. セーブ・互換性

### 15.1 ローカル

- IndexedDB
- 3分ごとの自動保存
- ターン確定前スナップショット
- 最新10世代
- 手動セーブ
- JSONエクスポート/インポート

### 15.2 セーブ形式

```ts
export interface SaveEnvelope {
  schemaVersion: number;
  gameVersion: string;
  createdAt: string;
  updatedAt: string;
  checksum: string;
  snapshot: WorldState;
  commandLog: PlayerCommand[];
  rngState: string;
}
```

### 15.3 マイグレーション

`schemaVersion` ごとに純粋関数のマイグレーションを実装する。古い形式を上書きせず、新形式へ変換後に別世代として保存する。

## 16. 技術構成

### 16.1 採用技術

- Node.js 24 LTS
- pnpm workspace
- TypeScript strict mode
- React 19.2
- Vite 8.1
- Tailwind CSS 4.3
- Zustand
- Zod
- Dexie
- Web Worker
- Vitest
- Playwright
- ESLint
- Prettier

### 16.2 リポジトリ構成

```text
project-sovereign/
├─ apps/
│  └─ web/
│     ├─ src/app/
│     ├─ src/features/
│     ├─ src/routes/
│     ├─ src/worker/
│     └─ e2e/
├─ packages/
│  ├─ domain/
│  ├─ simulation-core/
│  ├─ economy/
│  ├─ companies/
│  ├─ population/
│  ├─ politics/
│  ├─ diplomacy/
│  ├─ military/
│  ├─ content/
│  ├─ save-schema/
│  └─ test-fixtures/
├─ docs/
└─ tooling/
```

### 16.3 境界

- Reactコンポーネントはシミュレーション計算を持たない。
- シミュレーションパッケージはDOM、React、IndexedDBに依存しない。
- 保存処理は `save-schema` に集約する。
- 各ドメインは公開APIを `index.ts` からのみ公開する。
- パッケージ間の循環依存をCIで検出する。

## 17. エラー処理

| エラー | 処理 |
|---|---|
| 不正な命令 | ターン実行前に拒否し、対象項目を表示 |
| シミュレーション例外 | 前月状態を保持し、エラーレポートを生成 |
| Web Worker停止 | Workerを再生成し、未確定命令を復元 |
| セーブ破損 | チェックサム検証後、直前世代へ復旧 |
| マイグレーション失敗 | 元データを保持し、読み取り専用で開く |
| 表示エラー | Error Boundaryで画面単位に隔離 |

## 18. テスト戦略

### 18.1 単体

- 計算式
- 命令検証
- 乱数再現性
- 価格上限
- 人口・資金・在庫の不変条件
- セーブマイグレーション

### 18.2 プロパティベース

- 人口合計が不正に増減しない
- 企業の会計恒等式が崩れない
- 商品在庫が負にならない
- 税収と企業・家計支出が二重計上されない

### 18.3 長期シミュレーション

- 1,200ターン × 100シード
- 5,000ターンの耐久試験
- AI国家のみで進行
- 高税率、ゼロ金利、全面制裁など極端条件

### 18.4 E2E

- 新規ゲーム開始
- 政策変更
- 1ターン進行
- 月次報告確認
- セーブ・ロード
- 12か月高速進行と危機停止

## 19. バランス調整

- 重要な係数はコードへ直書きせず設定データ化する。
- 初期値と調整履歴をバージョン管理する。
- 自動シミュレーション結果をCSVへ出力する。
- 成長率、破綻率、政権交代頻度、戦争頻度を統計で監視する。
- 難易度はAIの不正補正ではなく、情報量、危機頻度、行政余力、猶予期間を中心に調整する。

## 20. 無料公開方針

### 初期

- 静的Webアプリとして公開
- シミュレーションはブラウザ内で実行
- ローカルセーブを標準
- アカウントなしでも全機能をプレイ可能

### 将来

- クラウドセーブは無料枠内で追加
- サーバー依存を最小化
- 有料APIをゲーム進行の必須条件にしない
- 利用者増加時は運用費を計測してから移行判断する

## 21. 縦切り版の受入条件

1. 4国家と12地域から国家を選べる。
2. 税率、政策金利、教育費、医療費、産業補助金を変更できる。
3. 8商品、24企業、人口コホートが月次で更新される。
4. 4国家のAIが毎月、財政・貿易・外交行動を決定する。
5. GDP、物価、失業率、財政、支持率、外交関係が変化する。
6. 主要指標の変化理由を表示できる。
7. 1、3、6、12か月進行と危機時自動停止が動作する。
8. セーブ・ロード・自動保存・世代復旧が動作する。
9. 同一シードで結果を再現できる。
10. 1,200ターンの自動テストを通過する。

## 22. 非機能要件

- 日本語UI
- PC Chrome、Edge、Firefoxの現行安定版
- TypeScript `strict: true`
- WCAG 2.2 AAを目標
- キーボード操作可能
- 主要操作に確認・取り消し導線
- 数値表示は単位と期間を明記
- ゲーム内年月と現実時刻を混同しない
- 保存データに秘密情報を含めない

## 23. 今後の設計書

以下は個別計画と同時に詳細化する。

- 経済計算式仕様書
- 商品・産業マスタ仕様書
- 企業AI仕様書
- 人口・支持率モデル仕様書
- 政治・選挙仕様書
- 外交AI仕様書
- 軍事・兵站仕様書
- イベント記述言語仕様書
- UI画面遷移・ワイヤーフレーム
- セーブ互換性ポリシー
